"""Train a single randomly initialized Zenbot policy from motion clips and MuJoCo rollouts."""

import argparse
import dataclasses
import hashlib
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

from . import amp, env, optim, zenbot
from .train_g1_getup_amp import normalized_input, train
from .train_zenbot_getup_stand_amp import RiseStandAMP, Settings, standing_pose_match
from .zenbot_gait_demos import gait_command_index


@dataclasses.dataclass
class ScratchSettings(Settings):
    log_dir: str = "runs/zenbot_scratch_10k"
    gait_dir: str = "data/zenbot23_walk_run_recovery/walk_run"
    directional_gait: int = 1
    short_amp_window: bool = False
    source_gait: bool = False
    zero_motor_delay_probability: float = 0.
    staged_side_and_turn_commands: bool = False
    motion_train_obs: int = 1
    floor_reset_fraction: float = .5
    phase_reset_fraction: float = .5
    assist_curriculum: bool = False
    fixed_std: bool = False
    linear_command_tracking: bool = False
    reference_guide_path: str = ""
    online_ground_bank: str = ""
    guide_weight: float = 6.
    guide_final_weight: float = 0.
    guide_end_iteration: int = 3500
    guide_batch: int = 256
    reference_fit_steps: int = 0
    reference_weight: float = 12.
    gait_speed_weight: float = 14.
    num_envs: int = 768
    rollout: int = 48
    epochs: int = 5
    disc_batch: int = 384
    init_std: float = 1.
    init_lr: float = .0001
    critic_warmup: int = 0
    save_every: int = 250
    log_every: int = 25
    scratch_ppo = True


class CommandWindows:
    """Sample a clip for the observed command, then a valid window within that clip."""

    def __init__(self, rise, stand, walk, run, frames=RiseStandAMP.amp_frames):
        self.frame_indices = jnp.arange(frames)
        banks = (rise, stand, walk, run)
        self.frames = jnp.concatenate([b.frames for b in banks])
        starts, labels, lengths, probabilities = [], [], [], []
        offset = 0
        for group, bank in enumerate(banks):
            if group < 2:
                counts = np.asarray(bank.clip_lengths)
                tags = [group] * len(counts)
            else:
                counts = np.asarray(bank.clip_counts)
                tags = [1 + gait_command_index(name) for name in bank.clip_names]
            weights = bank.clip_probabilities
            probabilities.extend(np.asarray(weights) if weights is not None else np.ones(len(tags)))
            labels.extend(tags)
            starts.append(bank.starts + offset)
            lengths.extend(counts)
            offset += len(bank.frames)
        self.starts = jnp.concatenate(starts)
        self.counts = jnp.asarray(lengths)
        self.offsets = jnp.cumsum(self.counts) - self.counts
        mass = np.equal.outer(np.arange(9), labels) * np.asarray(probabilities)
        if np.any(mass.sum(axis=1) == 0):
            raise ValueError("Every recovery and locomotion command needs at least one reference clip")
        self.logits = jnp.where(mass > 0, jnp.log(jnp.maximum(mass, 1e-30)), -jnp.inf)

    def sample(self, key, label, stride):
        kc, kt = jax.random.split(key)
        clip = jax.random.categorical(kc, self.logits[label])
        offsets = jax.random.randint(kt, label.shape, 0, self.counts[clip])
        start = self.starts[self.offsets[clip] + offsets]
        return self.frames[start[:, None] + stride * self.frame_indices]


def commanded_velocity_score(command, velocity_error):
    axis_scale = jnp.array([.4, .3, .4])
    command_size = jnp.linalg.norm(command / axis_scale, axis=-1)
    error_size = jnp.linalg.norm(velocity_error / axis_scale, axis=-1)
    return jnp.clip(1. - error_size / jnp.maximum(1., command_size), -1., 1.)


class ScratchAMP(RiseStandAMP):
    physical_gait_windows = True
    reference_skill_count = 9
    max_lr = .001
    disc_lr = .0001
    gamma = .995
    gae_lambda = .95

    def simulation_options(self, cfg):
        return dict(zenbot_scratch_resets=True, zenbot_scratch_curriculum=cfg.assist_curriculum,
                    zenbot_source_gait=cfg.source_gait,
                    zero_motor_delay_probability=cfg.zero_motor_delay_probability,
                    zenbot_phase_resets=cfg.phase_reset_fraction,
                    reference_weight=cfg.reference_weight, reference_hold_scale=0.)

    def __init__(self, cfg):
        if cfg.short_amp_window or cfg.source_gait:
            self.amp_frames, self.amp_stride = 3, 1
        if any((cfg.init_policy, cfg.policy_anchor, cfg.ground_actor_anchor, cfg.rise_teacher, cfg.gait_teacher)):
            raise ValueError("Scratch training accepts motion clips and random network initialization only")
        if not (cfg.directional_gait and cfg.motion_train_obs and cfg.standing_amp and cfg.stand_reference_weight):
            raise ValueError("Scratch training requires directional commands, standing AMP and Motion Train observations")
        if cfg.reference_guide_path:
            if (cfg.guide_end_iteration < 2 or cfg.guide_batch < 1
                    or not 0 <= cfg.guide_final_weight <= cfg.guide_weight < float("inf")):
                raise ValueError("Expected finite guide weights with 0 <= final <= initial, positive batch and end iteration >= 2")
            with np.load(cfg.reference_guide_path, allow_pickle=False) as pairs:
                obs, raw = (np.asarray(pairs[k], dtype=np.float32) for k in ("obs", "q_target_raw"))
                skill = pairs["skill"]
                opening_tick = pairs["opening_tick"] if "opening_tick" in pairs else None
            if obs.ndim != 2 or not len(obs) or obs.shape[1] != 234 or raw.shape != (len(obs), 23):
                raise ValueError("Reference pairs require matching 234-wide observations and 23 motor targets")
            if not np.isfinite(obs).all() or not np.isfinite(raw).all():
                raise ValueError("Non-finite observation or PD target in reference pairs")
            if (skill.shape != (len(obs),) or not np.issubdtype(skill.dtype, np.integer)
                    or np.any((skill < 0) | (skill >= self.reference_skill_count))):
                raise ValueError("Physical reference pairs have invalid skill IDs")
            rows = [np.flatnonzero(skill == s) for s in range(self.reference_skill_count)]
            counts = np.asarray([len(r) for r in rows], dtype=np.int32)
            if np.any(counts == 0):
                raise ValueError("Physical reference pairs are missing a required skill")
            table = np.zeros((self.reference_skill_count, counts.max()), dtype=np.int32)
            for s, indices in enumerate(rows):
                table[s, :len(indices)] = indices
            self.guide_rows, self.guide_counts = jnp.asarray(table), jnp.asarray(counts)
            self.guide_obs, self.guide_targets = jnp.asarray(obs), jnp.asarray(raw)
            if opening_tick is not None and cfg.online_ground_bank:
                from .zenbot_motion_train_obs import LAB_ORDER
                if (opening_tick.shape != skill.shape or np.any((opening_tick < -1) | (opening_tick > 2))
                        or np.any((opening_tick >= 0) & (skill != 0))):
                    raise ValueError("Invalid cold opening ticks in the physical reference pairs")
                cold_rows = np.flatnonzero(opening_tick >= 0)
                if len(cold_rows) == 0:
                    raise ValueError("Physical reference pairs contain no cold openings")
                self.opening_rows = jnp.asarray(cold_rows, dtype=jnp.int32)
                prior = obs[rows[0], -23:][:, np.argsort(LAB_ORDER)]
                change = np.mean(np.abs(raw[rows[0]] - prior), axis=1)
                moving = rows[0][change >= np.quantile(change, .75)]
                self.changing_rows = jnp.asarray(moving, dtype=jnp.int32)
        if cfg.online_ground_bank:
            if not cfg.reference_guide_path:
                raise ValueError("Online ground feedback requires guided scratch PPO")
            from .zenbot_online_ground import load_bank
            self.online_bank = load_bank(cfg.online_ground_bank, cfg.floor_dir)
        super().__init__(cfg)
        if cfg.assist_curriculum:
            self.extra_rollout_stats += ("applied_lift_n", "failed_floor_resets")
        if cfg.online_ground_bank:
            from .zenbot_physical_starts import PhysicalFloorStarts
            self.sim.physical_floor_starts = PhysicalFloorStarts(self.sim, self.online_bank)
            if cfg.source_gait and self.physical_gait_windows:
                from .zenbot_physical_gait_starts import PhysicalGaitStarts
                self.sim.physical_gait_starts = PhysicalGaitStarts(self.sim)
                self.extra_rollout_stats += ("physical_gait_window_fraction",)
        if cfg.source_gait:
            self.condition_dim = 3
            self.source_gait_demos = amp.Demos(cfg.gait_dir, self.sim, self.amp_span, per_clip=True,
                                               frame_fn=self.sim.amp_frame)
            self.extra_rollout_stats += ("source_speed_stage", "source_completed_episodes",
                                         "source_tracking_error", "source_fall_rate")
        else:
            self.windows = CommandWindows(self.demos, self.stand_demos, self.walk_demos, self.run_demos, self.amp_frames)
            self.condition_dim = 1 + len(zenbot.DIRECTIONAL_COMMANDS)
        self.motion_metric_names = ("rise_amp", "stand_amp", "gait_amp", "velocity_reward", "stand_pose_reward")

        if cfg.online_ground_bank:
            self.motion_metric_names += ("online_recovery_label_fraction", "online_stance_label_fraction", "physical_action_mix")

        if cfg.source_gait:
            self.motion_metric_names += ("floor_advantage_std", "gait_advantage_std")
        if cfg.reference_guide_path and not cfg.source_gait:
            from .zenbot_gait_demos import guided_gait_reset_bank
            motion_rows = np.asarray(self.sim.walk["counts"]).copy()
            motion_rows[0] = 0
            self.sim.walk = guided_gait_reset_bank(self.sim.walk, cfg.stand_dir)
            counts = np.asarray(self.sim.walk["counts"])
            cold_rows = counts - motion_rows
            self.gait_reset_summary = dict(stationary_rows=cold_rows.tolist(), moving_rows=motion_rows.tolist(),
                                           stationary_fractions=(cold_rows / counts).tolist(),
                                           command_order=zenbot.DIRECTIONAL_COMMANDS.tolist())

    def sample_reference_rows(self, key, count):
        samples = super().sample_reference_rows(key, count)
        if not hasattr(self, "opening_rows"):
            return samples
        # Half the batch is ground. Reserve examples for the initial push and motor
        # targets changing quickly enough that repeating the last request would fail.
        n_opening = count // 16
        n_changing = (count // 2 - n_opening) // 2
        opening_key, changing_key = jax.random.split(jax.random.fold_in(key, 192))
        opening = jax.random.choice(opening_key, self.opening_rows, (n_opening,))
        changing = jax.random.choice(changing_key, self.changing_rows, (n_changing,))
        return jnp.concatenate((opening, changing, samples[n_opening + n_changing:]))

    def fit_reference(self, actor, moments, norm, key):
        """Fit source motor requests before sampling the next on-policy rollout."""
        mask = self.mask["pi"]
        def step(carry, k):
            pi, state = carry
            idx = self.sample_reference_rows(k, self.c.guide_batch)
            x = normalized_input(norm, self.guide_obs[idx])
            y = self.guide_targets[idx]
            def objective(p):
                error = jnp.abs(self.actor_mean(p, x) - y)
                return jnp.where(error < 1., .5 * error**2, error - .5).mean()
            gradient, _ = optim.clip_by_global_norm(jax.grad(objective)(pi), 1.)
            return optim.step(pi, gradient, state, mask, 1e-4), None
        result, _ = jax.lax.scan(step, (actor, moments), jax.random.split(key, self.c.reference_fit_steps))
        return result

    def measured_ground_target(self, state):
        from .zenbot_online_ground import labels, measured_floor_loads
        # The Motion Train sensor noise vector is exactly zero for raw action channels.
        history = state.motion_train_sensors.frames
        previous, older = history[:, -1, 55:], history[:, -2, 55:]
        cold = (state.reference_start == 0) & (state.t < 3)
        # The neutral opening lag belongs to the randomized 3–7-substep hardware.
        label_lag = jnp.where(cold[:, None] & (state.delay_steps > 0), 5, state.delay_steps)
        return labels(self.online_bank, state.data.qpos, state.data.qvel, previous, older,
                      state.reference_clip, state.reference_start, state.t, state.c_obs, state.gait_ready,
                      measured_floor_loads(self.sim, state), label_lag, physical_reset_phase=True)

    def online_ground_targets(self, state):
        target, kind, _ = self.measured_ground_target(state)
        if self.sim.physical_gait_starts is not None:
            gait_target, active = self.sim.physical_gait_starts.target(state)
            target = jnp.where(active[:, None], gait_target, target)
            kind = jnp.where(active, 3, kind)
        return target, kind

    def collect(self, live, ac, disc, key, norms=None, *, ppo_iteration=None):
        online = bool(getattr(self.c, "online_ground_bank", ""))
        if self.c.assist_curriculum:
            if ppo_iteration is None:
                raise ValueError("Assisted rollouts require the current PPO iteration")
            state, *tail = live
            lift = (jnp.zeros_like(state.assist) if online
                    else zenbot.scratch_assist(ppo_iteration, state.reference_clip))
            live = (state._replace(assist=lift), *tail)
        if online:
            return super().collect(live, ac, disc, key, norms, ppo_iteration=ppo_iteration)
        return super().collect(live, ac, disc, key, norms)

    def blend_reward(self, transition, motion_reward):
        original = super().blend_reward(transition, motion_reward)
        if not self.c.source_gait:
            return original
        return jnp.where(transition.stats["source_gait_active"], .3 * transition.reward + motion_reward, original)

    def motion_features(self, window):
        # Source locomotion uses measured joint velocities. Defer feature selection until
        # the rollout identifies the task, since get-up windows use finite differences.
        if self.c.source_gait:
            return window
        return super().motion_features(window)

    def source_style_features(self, window, label):
        floor = super().motion_features(window)
        # Motion Train's gait discriminator observes body gyro, absolute joint angles,
        # joint velocities and six body-frame landmarks at each of three control ticks.
        channel = jnp.arange(window.shape[-1])
        gait = window * ((channel >= 6) & (channel < 9 + 2 * self.sim.J + 3 * len(zenbot.KEY_BODIES)))
        return jnp.where((label == 2)[:, None, None], gait, floor)

    def source_motion(self, disc, motion, transition):
        stats = transition.stats
        active, standing = stats["source_gait_active"], stats["source_standing"]
        motion = jnp.where(transition.diverged[:, None, None], 0., motion)
        label = jnp.where(active, jnp.where(standing, 1, 2), (stats["stand_blend"] >= .5).astype(jnp.int32))
        replay = self.conditioned(self.source_style_features(motion, label), jax.nn.one_hot(label, self.condition_dim))
        unit = amp.recovery_style(disc, replay, scale=1., leggedlab=True)
        # A gait fall contributes its actual pre-reset transition. Floor failures retain the recovery reward.
        gait_style = env.DT * 1.5 * unit
        floor_style = jnp.where(transition.terminated, 0., env.DT * 10. * unit)
        velocity = env.DT * stats["source_velocity_score"]
        bilateral = jnp.clip(2. * stats["min_foot_load_bw"], 0., 1.)
        pose = env.DT * self.c.stand_reference_weight * stats["stand_blend"] * bilateral * standing_pose_match(
            motion[:, -1], self.standing_target)
        # The source orientation term gives feedback before tilt reaches the gait failure threshold.
        posture = -1.2 * env.DT * stats["source_tilt_l2"]
        contribution = jnp.where(active, .3 * (velocity + posture) + .7 * gait_style, floor_style + pose)
        contribution = jnp.where(transition.diverged, 0., contribution)
        style = jnp.where(active, gait_style, floor_style)
        metrics = ((style * (label == 0)).mean(), (style * (label == 1)).mean(),
                   (style * (label == 2)).mean(), jnp.where(active, velocity, 0.).mean(),
                   jnp.where(active, 0., pose).mean())
        return contribution, replay, metrics

    def rollout_motion(self, disc, motion, transition):
        if self.c.source_gait:
            return self.source_motion(disc, motion, transition)
        stats = transition.stats
        cmd = stats["gait_command"]
        ready = stats["gait_ready"]
        command_id = jnp.argmin(jnp.square(cmd[:, None] - zenbot.DIRECTIONAL_COMMANDS).sum(-1), axis=1)
        standing = (command_id == 0) & (stats["stand_blend"] >= .5)
        # A gait fall is a negative example for its actual command, including the terminal frame.
        gait_terminal = transition.terminated & jnp.logical_not(stats.get("failed_floor_recovery", False))
        label = jnp.where(ready | gait_terminal, 1 + command_id, standing.astype(jnp.int32))
        replay = self.conditioned(motion, jax.nn.one_hot(label, self.condition_dim))
        style = env.DT * amp.recovery_style(disc, replay, scale=10., leggedlab=True)
        style = jnp.where(transition.terminated, 0., style)

        if self.c.linear_command_tracking:
            speed_score = commanded_velocity_score(cmd, stats["gait_velocity_error"])
            velocity = env.DT * self.c.gait_speed_weight * ready * speed_score
        else:
            error = stats["gait_velocity_error"] / jnp.array([.4, .3, .4])
            distance = jnp.sqrt(.01 + jnp.square(error).sum(axis=-1)) - .1
            velocity = env.DT * self.c.gait_speed_weight * ready / (1. + distance)
        bilateral = jnp.clip(2. * stats["min_foot_load_bw"], 0., 1.)
        match = standing_pose_match(motion[:, -1], self.standing_target)
        pose = env.DT * self.c.stand_reference_weight * (command_id == 0) * stats["stand_blend"] * bilateral * match
        metrics = ((style * (label == 0)).mean(), (style * (label == 1)).mean(),
                   (style * (label > 1)).mean(), velocity.mean(), pose.mean())
        return style + velocity + pose, replay, metrics

    def discriminator_examples(self, key, policy):
        condition = policy[:, -1, -self.condition_dim:]
        labels = condition.argmax(axis=-1)
        if self.c.source_gait:
            keys = jax.random.split(key, 3)
            rise, stand, gait = [bank.sample(k, len(labels)) for k, bank in
                                 zip(keys, (self.demos, self.stand_demos, self.source_gait_demos), strict=True)]
            expert = jnp.where(labels[:, None, None] == 0, rise,
                               jnp.where(labels[:, None, None] == 1, stand, gait))
            return self.conditioned(self.source_style_features(expert, labels), condition), policy
        else:
            expert = self.windows.sample(key, labels, self.amp_stride)
        return self.conditioned(self.motion_features(expert), condition), policy


def main():
    defaults = ScratchSettings()
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("log_dir", "seed", "iterations", "num_envs", "rollout", "save_every", "log_every"):
        default = getattr(defaults, name)
        parser.add_argument("--" + name.replace("_", "-"), default=argparse.SUPPRESS, type=type(default))
    parser.add_argument("--short-amp-window", action="store_true",
                        help="Use three consecutive 50 Hz frames for both AMP sources")
    parser.add_argument("--source-gait", action="store_true",
                        help="Train supported locomotion with Motion Train resets, commands, short AMP and task mixing")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--reference-pairs", type=Path,
                      help="Training NPZ with physical observations and raw PD targets (default: RUN/reference_pairs/train.npz)")
    mode.add_argument("--pure-ppo", action="store_true",
                      help="Reproduce the 768-environment PPO/AMP baseline without action guidance or training lift")
    parser.add_argument("--online-ground-bank", default=argparse.SUPPRESS,
                        help="Prepared physical recovery feedback bank for labels on the states sampled by PPO")
    parser.add_argument("--guide-final-weight", type=float, default=argparse.SUPPRESS,
                        help="Reference loss weight from PPO iteration 3500 onward (guided default 0.3)")
    parser.add_argument("--reference-fit-steps", type=int, default=argparse.SUPPRESS,
                        help="Physical-reference minibatches before early PPO rollouts")
    args = vars(parser.parse_args())
    if args.get("reference_fit_steps", 0) < 0 or (args.get("reference_fit_steps") and not args.get("online_ground_bank")):
        parser.error("Physical reference fitting requires an online ground bank and a nonnegative step count")
    reference_pairs = args.pop("reference_pairs")
    if args.pop("pure_ppo"):
        if "online_ground_bank" in args:
            parser.error("--online-ground-bank requires guided PPO")
        if "guide_final_weight" in args:
            parser.error("--guide-final-weight requires the guided recipe")
    else:
        args.setdefault("log_dir", "runs/zenbot_scratch_guided_10k")
        pair_file = reference_pairs or Path(args["log_dir"]) / "reference_pairs" / "train.npz"
        if not pair_file.is_file():
            parser.error(f"Reference-pair archive missing: {pair_file}. Use tools/recipes/train_zenbot_scratch.sh or --reference-pairs.")
        args.update(assist_curriculum=True, fixed_std=True, init_std=.5, reference_guide_path=str(pair_file),
                    linear_command_tracking=True, gait_speed_weight=8.)
        args.setdefault("num_envs", 2048)
        args.setdefault("guide_final_weight", 1. if args.get("online_ground_bank") else .3)
    if args.get("online_ground_bank"):
        args.setdefault("reference_fit_steps", 4)
        args.update(reference_weight=0., floor_reset_fraction=.30, phase_reset_fraction=.70,
                    guide_weight=12., short_amp_window=True)
    cfg = ScratchSettings(**args)
    if not 1 <= cfg.iterations <= 10000:
        parser.error("Use 1 through 10,000 PPO iterations")
    inputs = [file for directory in (cfg.floor_dir, cfg.stand_dir, cfg.gait_dir)
              for file in sorted(Path(directory).glob("*")) if file.suffix in (".json", ".npz")]
    metadata = dict(task="zenbot_scratch", learner="on_policy_ppo_amp", initialization="seeded_random",
                    actor_observation="Motion Train 234, three term-major frames", policies=1, discriminators=1,
                    action_rate_l2_weight=3. * zenbot.WEIGHTS["action_rate_l2"], assist_newtons=0.,
                    max_lr=ScratchAMP.max_lr, disc_lr=ScratchAMP.disc_lr, gamma=ScratchAMP.gamma,
                    gae_lambda=ScratchAMP.gae_lambda, command_order=zenbot.DIRECTIONAL_COMMANDS.tolist(),
                    reference_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
                    training_source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                            for p in sorted(Path(__file__).parent.glob("*.py"))})
    if cfg.source_gait:
        metadata.update(gait_reset="source standing pose and randomized root speed", gait_command_seconds=10.,
                        amp_conditions=["recovery", "stand", "locomotion"], gait_expert="source sampling.json",
                        gait_critic_velocity="body frame", gait_flat_orientation_l2=-1.2,
                        gait_amp_features="body gyro, joint angle, measured joint velocity, six body-frame key positions",
                        gait_amp_frames=3, gait_amp_stride=1, gait_amp_scale=1.5, gait_task_mix=.3, gait_style_mix=.7,
                        advantage_normalization="separately over ground recovery and supported locomotion")
    if cfg.online_ground_bank:
        if cfg.source_gait:
            from .zenbot_physical_gait_starts import PhysicalGaitStarts
            manifest = json.loads((PhysicalGaitStarts.default_directory / "manifest.json").read_text())
            metadata.update(gait_reset="75% source standing births; 25% measured finite gait windows",
                            gait_window_sha256=manifest["windows_sha256"], gait_window_count=manifest["accepted"],
                            gait_window_mix="0.5 to zero by iteration 2500; same command continues after the last label")
        bank_file = Path(cfg.online_ground_bank)
        metadata.update(assist_newtons=0., assist_zero_from_iteration=1,
                        recovery_resets="physical source trajectories with true motor and sensor histories at intermediate phases",
                        recovery_nominal_dynamics_fraction=.75,
                        eval_assist_newtons=0., physical_control_mix="0.98 to zero by iteration 2500 on eligible zero-command states",
                        physical_control_likelihood="same interpolated Gaussian in rollout and PPO; std 0.12 for zero commands")
        metadata.update(online_ground_bank_sha256=hashlib.sha256(bank_file.read_bytes()).hexdigest(),
                        online_recovery_clock="source_start + episode_tick, nearest within 8 control frames including an opening retry",
                        online_huber_fraction_if_eligible=.5,
                        reference_fit="same actor before collection at iterations 2 through 2500; Adam 1e-4",
                        physical_reference_sampling="per 256 rows: 16 cold, 56 changing and 56 random ground; 16 per other skill")
    if cfg.assist_curriculum and not cfg.online_ground_bank:
        metadata.update(assist_newtons=zenbot.INITIAL_ASSIST, assist_zero_from_iteration=3000,
                        eval_assist_newtons=0., failed_recovery_grace_seconds=1.)
    if cfg.reference_guide_path:
        train_file = Path(cfg.reference_guide_path)
        pair_dir = train_file.parent
        manifest = pair_dir / "checks_v2.json"
        checks = json.loads(manifest.read_text()) if manifest.is_file() else {}
        source_root = Path(__file__).resolve().parents[1]
        source_hashes = {"instantamp/" + name: digest for name, digest in metadata["training_source_sha256"].items()}
        for name in ("tools/prepare_zenbot_scratch_pairs.py", "tools/prepare_zenbot_standing_amp.py", "tools/convert_motions.py"):
            path = source_root / name
            if path.is_file():
                source_hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        datasets = {}
        for split, path in (("train", train_file), ("valid", pair_dir / "valid.npz")):
            if not path.is_file() and split == "valid" and split not in checks.get("bytes_sha256", {}):
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            expected = checks.get("bytes_sha256", {}).get(split)
            if expected is not None and digest != expected:
                raise ValueError(f"{split} reference-pair hash differs from checks_v2.json")
            with np.load(path, allow_pickle=False) as data:
                counts = np.bincount(data["skill"], minlength=9)
            datasets[split] = dict(sha256=digest, rows=int(counts.sum()), rows_per_skill=counts.tolist())
        metadata.update(reference_pair_sha256=datasets["train"]["sha256"],
                        reference_pair_datasets=datasets, reference_pair_source_sha256=source_hashes,
                        reference_pair_generation_source_sha256=checks.get("generator_source_sha256", {}),
                        reference_pair_checks_sha256={n: hashlib.sha256((pair_dir/n).read_bytes()).hexdigest()
                                                      for n in ("checks_v2.json", "coverage.json") if (pair_dir/n).is_file()},
                        guide_schedule="linear to guide_final_weight at guide_end_iteration, then constant", guide_huber_delta_raw=1.,
                        guide_sampling="half rise, remainder equally divided between standing and seven gait commands")
    train(cfg, ScratchAMP, metadata)


if __name__ == "__main__":
    main()
