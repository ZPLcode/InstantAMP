"""Train the Zenbot actor for 10,000 PPO updates from random initialization."""
import argparse
import hashlib
import json
from pathlib import Path

from .zenbot_staged_ppo import StagePlan, continue_staged, train_staged
from .zenbot_staged_recovery import make_recovery, recovery_configuration


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    phase = parser.add_mutually_exclusive_group()
    phase.add_argument("--stop-at-boundary", action="store_true", help="Publish the full stage-one learner, then exit")
    phase.add_argument("--continue-at-boundary", action="store_true", help="Resume this run before its first stage-two update")
    parser.add_argument("--floor-reward-scale", type=float, metavar="K",
                        help="Joint-stage recovery reward scale in [0,1], excluding action rate (default 1)")
    args = parser.parse_args()
    run = args.run_dir
    scale = args.floor_reward_scale
    if scale is None and args.continue_at_boundary:
        with (run / "config.json").open() as stream:
            scale = json.load(stream)["second"].get("floor_reward_scale", 1.)
    try:
        settings = recovery_configuration(run, floor_reward_scale=1. if scale is None else scale)
    except ValueError as error:
        parser.error(str(error))
    plan = StagePlan.standard(run, settings)
    if args.continue_at_boundary:
        continue_staged(plan, make_recovery)
        return
    if (run / "ckpt").exists():
        parser.error("Choose a fresh run directory or continue its complete boundary")
    inputs = [run / "ground_bank.npz", run / "support_frames.json", Path(settings.reference_guide_path)]
    for directory in (settings.floor_dir, settings.stand_dir, settings.gait_dir):
        inputs.extend(sorted(p for p in Path(directory).glob("*") if p.suffix in (".npz", ".json")))
    hashes = {}
    for path in inputs:
        with path.open("rb") as stream:
            hashes[str(path)] = hashlib.file_digest(stream, "sha256").hexdigest()
    metadata = dict(
        initialization="seeded_random", seed=plan.first.seed, ppo_iterations=plan.stop_after,
        gait_iterations=plan.switch_after, joint_iterations=plan.stop_after - plan.switch_after,
        environment_steps=983040000, actor_observation="Motion Train 234", action_rate_l2=-.015,
        assistance_newtons=0, physical_ground_action_fades_at_global_iteration=plan.switch_after + 2500,
        locomotion_pretraining="on-policy AMP in this run",
        initial_motor_delays="five independent actuator group delays from 3 to 7 physics steps",
        joint_zero_delay_probability=settings.zero_motor_delay_probability,
        joint_side_and_turn_commands=settings.staged_side_and_turn_commands,
        floor_reward_scale=settings.floor_reward_scale,
        joint_command_sampling="Keep all source stops and half of moving draws. Replace the other moving draws equally "
                               "with fixed left/right 0.4 m/s and positive/negative 0.6 rad/s commands for 10 seconds.",
        joint_motor_delays="each episode uses the deployment's immediate motors or the original five delays",
        gait_retention="actions of this same actor after 4500 PPO iterations",
        physical_supervision="floor motion before first sustained support plus 25 control ticks",
        inputs_sha256=hashes,
    )
    (run / "recipe.json").write_text(json.dumps(metadata, indent=2) + "\n")
    train_staged(plan, make_recovery, stop_at_boundary=args.stop_at_boundary)


if __name__ == "__main__":
    main()
