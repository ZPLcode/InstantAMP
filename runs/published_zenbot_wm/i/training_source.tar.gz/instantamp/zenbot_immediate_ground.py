"""Training-only native-ground teacher for immediate motors, with its own two requests in flight."""
import jax.numpy as jnp

from . import zenbot
from .zenbot_online_ground import labels

COMMON_LAUNCH_TICKS = 3


def request_at(bank, clip, phase):
    """A request at a recorded physical phase, zero before the opening or for a non-ground world."""
    c = jnp.maximum(clip, 0)
    raw = bank.raw[c, jnp.clip(phase, 0, bank.lengths[c] - 1)]
    return jnp.where(((clip >= 0) & (phase >= 0))[:, None], raw, 0.)


def initial_queue(bank, clip, start):
    """Return [previous, older] unfiltered requests per world at an asynchronous physical reset."""
    return jnp.stack((request_at(bank, clip, start - 1), request_at(bank, clip, start - 2)), axis=1)


def delivered(current, queue, delay_groups):
    """Four-substep mean demand at each joint; exactly one such raw action is sent at 50 Hz."""
    delay = delay_groups[:, zenbot.GROUP]
    now = jnp.clip(4 - delay, 0, 4)
    late = jnp.clip(delay - 4, 0, 4)
    prior = 4 - now - late
    return .25 * (now * current + prior * queue[:, 0] + late * queue[:, 1])


def delivered_prefix(bank, clip, phase):
    """Raw requests the immediate actuator would have received before each restored state."""
    c = jnp.maximum(clip, 0)
    t = jnp.maximum(phase[:, None] + jnp.arange(-4, 1), 0) - 1
    n, history = t.shape
    clip_ids = jnp.repeat(clip, history)
    t = t.reshape(-1)
    raw = request_at(bank, clip_ids, t)
    queue = initial_queue(bank, clip_ids, t)
    lag = jnp.repeat(bank.delay_groups[c], history, axis=0)
    actual = jnp.where((t < COMMON_LAUNCH_TICKS)[:, None], raw, delivered(raw, queue, lag))
    return actual.reshape(n, history, -1)


def ground_target(bank, q, v, actual_prev, actual_older, clip, start, elapsed, command, ready,
                  loads, actual_delay, queue, first_support):
    immediate = (clip >= 0) & jnp.all(actual_delay == 0, axis=-1)
    queue = jnp.where((elapsed == 0)[:, None, None], initial_queue(bank, clip, start), queue)
    previous = jnp.where(immediate[:, None], queue[:, 0], actual_prev)
    older = jnp.where(immediate[:, None], queue[:, 1], actual_older)
    nominal_delay = bank.delay_groups[jnp.maximum(clip, 0)]
    source_delay = jnp.where(immediate[:, None], nominal_delay, actual_delay)
    cold = (start == 0) & (elapsed < COMMON_LAUNCH_TICKS)
    label_delay = jnp.where(cold[:, None] & (source_delay > 0), 5, source_delay)
    raw, kind, phase = labels(bank, q, v, previous, older, clip, start, elapsed, command, ready, loads,
                              label_delay, physical_reset_phase=True)
    active = (kind == 1) & (phase < first_support[jnp.maximum(clip, 0)] + 25)
    # A cold, identical sensor observation has one launch target for both actuator domains.
    immediate_target = jnp.where(cold[:, None], raw, delivered(raw, queue, nominal_delay))
    target = jnp.where(immediate[:, None], jnp.where(active[:, None], immediate_target, 0.), raw)
    # These are this physical controller's virtual requests, even when the sampled actor drove the robot.
    # The caller puts only the actually executed mixed/noisy action into the real actuator/sensor history.
    shifted = jnp.stack((raw, queue[:, 0]), axis=1)
    return target, jnp.where(active, 1, 0), jnp.where((immediate & active)[:, None, None], shifted, 0.)
