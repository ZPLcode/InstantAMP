"""Start a minority of gait episodes inside measured, finite MuJoCo motion windows."""
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

import jax
import jax.numpy as jnp
import numpy as np

from . import env, zenbot
from .zenbot_motion_train_obs import SENSOR_NOISE, interpolate_delayed_imu


class PhysicalGaitStarts:
    probability = .25
    default_directory = Path(__file__).resolve().parents[1] / "data/zenbot23_physical_gait"

    def __init__(self, sim, directory=None):
        from .sim import unflatten

        directory = Path(directory or self.default_directory)
        archive = directory / "windows.zip"
        manifest = json.loads((directory / "manifest.json").read_text())
        self.archive_sha256 = hashlib.sha256(archive.read_bytes()).hexdigest()
        if self.archive_sha256 != manifest["windows_sha256"] or manifest["control_dt"] != env.DT:
            raise ValueError("Physical locomotion archive or control period differs from its manifest")

        q, v, sensor, actions, delays, starts, ends = [], [], [], [], [], [], []
        count = 0
        with ZipFile(archive) as src:
            for row in manifest["windows"]:
                payload = src.read(row["file"])
                if hashlib.sha256(payload).hexdigest() != row["sha256"]:
                    raise ValueError(f"Invalid physical gait window {row['file']}")
                with np.load(io.BytesIO(payload), allow_pickle=False) as w:
                    n = int(row["steps"])
                    expected = zenbot.DIRECTIONAL_COMMANDS[row["skill"] - 1]
                    if n < round(.4 / env.DT) or len(w["raw_action"]) != n or not np.array_equal(w["command"], expected):
                        raise ValueError(f"Invalid physical gait command or duration in {row['file']}")
                    starts.append(count + 4)
                    count += 4 + n
                    ends.append(count)
                    q.append(np.concatenate((w["prefix_qpos"], w["qpos"][:-1])))
                    v.append(np.concatenate((w["prefix_qvel"], w["qvel"][:-1])))
                    sensor.append(np.concatenate((w["prefix_raw_frames"], w["raw_frames"])))
                    actions.append(np.pad(w["raw_action"], ((4, 0), (0, 0))))
                    delays.append(w["delays"])

        self.starts, self.ends = jnp.asarray(starts), jnp.asarray(ends)
        self.q, self.v, self.sensor, self.actions = (
            jnp.asarray(np.concatenate(arrays), jnp.float32) for arrays in (q, v, sensor, actions)
        )
        self.delays = jnp.asarray(np.asarray(delays), jnp.int32)
        # A full frame carries delayed PD requests in the simulator's actuator order.
        self.full_frame = sim.obs_frame(unflatten(self.q, self.v), self.sensor[:, 55:], self.sensor[:, 6:9], None)

    def reset(self, state, key, done, gait, q, v, cmd):
        choose_key, clip_key, frame_key = jax.random.split(key, 3)
        n = len(done)
        idx = jax.random.randint(clip_key, (n,), 0, len(self.starts))
        first, end = self.starts[idx], self.ends[idx]
        # Retain at least the final 0.4 s over which the native velocity/support gate was checked.
        start = jax.random.randint(frame_key, (n,), first, end - round(.4 / env.DT) + 1)
        use = gait & jax.random.bernoulli(choose_key, self.probability, (n,))
        new_window = jnp.stack((start, end), axis=-1)
        window = jnp.where(done[:, None], jnp.where(use[:, None], new_window, -1), state.gait_window)
        cmd = env.where_cmd(use, cmd._replace(vel=self.sensor[start, 6:9], is_standing=jnp.zeros_like(use),
                                               is_heading=jnp.zeros_like(use)), cmd)
        return (window, jnp.where(use[:, None], self.q[start], q), jnp.where(use[:, None], self.v[start], v),
                cmd, jnp.where(use[:, None], self.delays[idx], -1))

    def target(self, state):
        start, end = state.gait_window.T
        index = start + state.t
        active = (start >= 0) & (index < end)
        index = jnp.clip(index, 0, len(self.actions) - 1)
        matching_command = jnp.all(jnp.abs(self.sensor[index, 6:9] - state.c_obs) < 1e-5, axis=-1)
        # Recorded gait windows contain only the original, delayed hardware.
        matching_timing = jnp.all(state.delay_steps > 0, axis=1)
        return self.actions[index], active & matching_command & matching_timing

    def restore(self, sim, state, done, key):
        start = state.gait_window[:, 0]
        use = done & (start >= 0)

        def prefix(s):
            history = jnp.maximum(start, 4)[:, None] + jnp.arange(-4, 1)
            frames = self.full_frame[history]
            sensors = s.motion_train_sensors
            raw = self.sensor[history]
            imu = raw[:, :, :6]
            delayed = interpolate_delayed_imu(imu[:, 2:], imu[:, 1:-1], imu[:, :-2], sensors.delay_s[:, None])
            motor = raw[:, -3:].at[:, :, :6].set(delayed)
            if sim.noisy_obs:
                fk, mk = jax.random.split(key)
                frames += sim.obs_noise * jax.random.uniform(fk, frames.shape, minval=-1., maxval=1.)
                motor += SENSOR_NOISE * jax.random.uniform(mk, motor.shape, minval=-1., maxval=1.)
            # The last motor request predates the reset state. The current label is still unobserved.
            previous = raw[:, -1, 55:]
            sensors = sensors._replace(current_imu=jnp.where(use[:, None], imu[:, -1], sensors.current_imu),
                                       previous_imu=jnp.where(use[:, None], imu[:, -2], sensors.previous_imu),
                                       frames=jnp.where(use[:, None, None], motor, sensors.frames))
            return s._replace(obs=jnp.where(use[:, None], frames.reshape(s.obs.shape), s.obs),
                              a_last=jnp.where(use[:, None], previous, s.a_last),
                              a_ode=jnp.where(use[:, None], previous, s.a_ode), motion_train_sensors=sensors)

        return jax.lax.cond(jnp.any(use), prefix, lambda s: s, state)
