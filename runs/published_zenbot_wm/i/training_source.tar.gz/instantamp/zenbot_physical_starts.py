"""Restore physically visited recovery states and the motor requests already in flight."""
import jax
import jax.numpy as jnp

from . import zenbot
from .rot import mv3, quat_to_mat
from .zenbot_motion_train_obs import MotionTrainSensors, SENSOR_NOISE, interpolate_delayed_imu


class PhysicalFloorStarts:
    immediate_ground_bank = None

    def __init__(self, sim, bank):
        from .sim import unflatten

        self.q, self.v = q, v = bank.q, bank.v
        self.past_action = jnp.concatenate((jnp.zeros_like(bank.raw[:, :1]), bank.raw[:, :-1]), axis=1)
        state = unflatten(q.reshape(-1, 30), v.reshape(-1, 29))
        zero_command = jnp.zeros((state[0].shape[0], 3), q.dtype)
        frame = sim.obs_frame(state, self.past_action.reshape(-1, 23), zero_command, None)
        self.full_frame = frame.reshape(*q.shape[:2], sim.frame_dim)
        self.imu = jnp.concatenate((v[..., 3:6], -quat_to_mat(q[..., 3:7])[..., 2, :]), axis=-1)

        # Phase zero uses the same opening pose and velocity as a cold deployment reset.
        old = sim.floor
        phase_offsets = old["offsets"]
        n, steps = q.shape[:2]
        source = {
            "z": q[..., 2] - zenbot.RESET_LIFT, "quat": q[..., 3:7], "q": q[..., 7:],
            "v": v[..., :3], "w": mv3(quat_to_mat(q[..., 3:7]), v[..., 3:6]), "qd": v[..., 6:],
        }
        for name, values in source.items():
            source[name] = values.at[:, 0].set(old[name][phase_offsets]).reshape(n * steps, *values.shape[2:])
        # This same physical clock bounds failed reset retries. A later RSI may start after first support.
        lengths = jnp.minimum(bank.lengths, bank.settled + 51)
        sim.floor = dict(**source, offsets=steps * jnp.arange(n), lengths=lengths, down_counts=lengths)

    def restore(self, sim, state, fresh, key):
        clip, phase = state.reference_clip, state.reference_start
        use = fresh & (clip >= 0) & (phase > 0)

        def prefix(s):
            c = jnp.maximum(clip, 0)[:, None]
            index = jnp.maximum(phase[:, None] + jnp.arange(-4, 1), 0)
            actions = self.past_action[c, index]
            frames = self.full_frame[c, index]
            motor = 9 + 2 * sim.J
            if self.immediate_ground_bank is not None:
                from .zenbot_immediate_ground import delivered_prefix

                immediate = jnp.all(s.delay_steps == 0, axis=1)
                delivered = delivered_prefix(self.immediate_ground_bank, clip, phase)
                actions = jnp.where(immediate[:, None, None], delivered, actions)
                frames = frames.at[:, :, motor:motor+sim.J].set(actions)
            last_action = actions[:, -1]
            if sim.noisy_obs:
                frames += sim.obs_noise * jax.random.uniform(key, frames.shape, minval=-1., maxval=1.)
            # Preserve the actual current state after the reset pose/velocity perturbation.
            current = s.obs.reshape(sim.N, sim.history, sim.frame_dim)[:, -1]
            frames = frames.at[:, -1].set(current.at[:, motor:motor+sim.J].set(last_action))

            sensor = s.motion_train_sensors
            imu = self.imu[c, index].at[:, -1].set(sensor.current_imu)
            imu_frame = interpolate_delayed_imu(imu[:, 2:], imu[:, 1:-1], imu[:, :-2], sensor.delay_s[:, None])
            angle = self.q[c, index[:, -3:], 7:].at[:, -1].set(s.data.qpos[:, 7:])
            speed = self.v[c, index[:, -3:], 6:].at[:, -1].set(s.data.qvel[:, 6:])
            command = jnp.broadcast_to(s.c_obs[:, None], (sim.N, 3, 3))
            motor_frame = jnp.concatenate((imu_frame, command, angle - zenbot.DEFAULT_Q, speed, actions[:, -3:]), -1)
            if sim.noisy_obs:
                motor_frame += SENSOR_NOISE * jax.random.uniform(jax.random.fold_in(key, 234), motor_frame.shape,
                                                                minval=-1., maxval=1.)
            sensors = MotionTrainSensors(sensor.delay_s, sensor.current_imu,
                                         jnp.where(use[:, None], imu[:, -2], sensor.previous_imu),
                                         jnp.where(use[:, None, None], motor_frame, sensor.frames))
            return s._replace(obs=jnp.where(use[:, None], frames.reshape(s.obs.shape), s.obs),
                              a_last=jnp.where(use[:, None], last_action, s.a_last),
                              a_ode=jnp.where(use[:, None], last_action, s.a_ode), motion_train_sensors=sensors)

        return jax.lax.cond(jnp.any(use), prefix, lambda s: s, state)
