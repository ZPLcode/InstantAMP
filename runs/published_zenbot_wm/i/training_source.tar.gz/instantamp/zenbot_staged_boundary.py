"""Read a complete phase-one learner from this run and exclude competing writers."""
import dataclasses
import fcntl
import hashlib
import json
from contextlib import contextmanager
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

from .zenbot_source_gait import Curriculum


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


@contextmanager
def writer_lock(run, *, check_legacy=False):
    """New drivers flock the run. The pre-lock driver holds a writable log fd throughout training."""
    with (run/".staged_writer.lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another trainer already owns this run") from exc
        if check_legacy:
            # A Linux read lease can only be acquired if nobody has the log open for writing.
            # The old driver opens it once, exclusively, before stage one and keeps that fd through stage two.
            with (run/"log.jsonl").open("rb") as probe:
                try:
                    fcntl.fcntl(probe,fcntl.F_SETLEASE,fcntl.F_RDLCK)
                except BlockingIOError as exc:
                    raise RuntimeError("A trainer already has the training log open for writing") from exc
                fcntl.fcntl(probe,fcntl.F_SETLEASE,fcntl.F_UNLCK)
        yield


def _branches(leaves):
    tree={}
    for path,array in leaves.items():
        node=tree
        for name in path.split("/")[:-1]:
            node=node.setdefault(name,{})
        node[path.split("/")[-1]]=jnp.asarray(array)
    def decode(node):
        if not isinstance(node,dict): return node
        if all(k.isdecimal() for k in node):
            if sorted(map(int,node))!=list(range(len(node))):
                raise ValueError("Nonconsecutive stage archive indices")
            return [decode(node[str(i)]) for i in range(len(node))]
        return {k:decode(v) for k,v in node.items()}
    return decode(tree)


def _equal_arrays(a,b):
    return a.dtype==b.dtype and a.shape==b.shape and np.array_equal(a,b)


def _verify_adam(parameters, adam):
    if set(adam)!={"t","leaves"} or np.asarray(adam["t"]).shape!=() or int(adam["t"])<0:
        raise ValueError("Invalid boundary Adam state")
    for name in ("m","v"):
        values=jax.tree.map(lambda p,m:m[name],parameters,adam["leaves"])
        if not all(a.shape==b.shape and a.dtype==b.dtype for a,b in
                   zip(jax.tree.leaves(parameters),jax.tree.leaves(values),strict=True)):
            raise ValueError("A boundary Adam moment has the wrong parameter shape")


def read_learner(run, plan):
    """Validate provenance, counters, both policy exports and all archived named learner arrays."""
    from .zenbot_staged_ppo import PhaseBoundary
    it=plan.switch_after
    prefix=f"transition_{it:06}"
    archive=run/(prefix+".npz")
    actor=run/"ckpt"/f"{it:06}.npz"
    read=lambda p:json.loads(p.read_text())
    record=read(archive.with_suffix(".json"))
    config=read(run/"config.json")
    first=json.loads(json.dumps(dataclasses.asdict(plan.first),default=str))
    # Relative and absolute spellings of this run directory refer to the same source.
    stored_first={**config["first"], "log_dir":str(Path(config["first"]["log_dir"]).resolve())}
    first["log_dir"]=str(Path(first["log_dir"]).resolve())
    # Compatible newer settings can add options with their historical default.
    # A non-default stage-one override still rejects the continuation.
    for field in dataclasses.fields(plan.first):
        if field.name not in stored_first:
            if field.default is not dataclasses.MISSING:
                stored_first[field.name]=field.default
            elif field.default_factory is not dataclasses.MISSING:
                stored_first[field.name]=field.default_factory()
    if (config["seed"]!=plan.first.seed or config["switch_after"]!=it or config["iterations"]!=plan.stop_after
            or first!=stored_first or record["source_sha256"]!=config["training_source_sha256"]
            or record["it"]!=it or record["archive"]!=archive.name or digest(archive)!=record["sha256"]):
        raise ValueError("The stage-one config, SHA or boundary identity does not match this run")
    seed_info=read(run/"initialization.json")
    if (seed_info["seed"]!=plan.first.seed or seed_info["it"]!=0 or seed_info["initialization"]!="seeded_random"
            or digest(run/"ckpt/000000.npz")!=seed_info["sha256"]):
        raise ValueError("Initial random actor identity failed")
    log_path=run/"log.jsonl"
    rows=[]
    with log_path.open() as log:
        for line in log:
            if not line.endswith("\n"): raise ValueError("The staged log has an incomplete line")
            row=json.loads(line)
            if row["stage"]!=1 or not 0<row["it"]<=it or row["it"]!=row["stage_it"] or (rows and row["it"]<=rows[-1]["it"]):
                raise ValueError("The staged log already contains stage two or has invalid ordering")
            rows.append(row)
    steps=it*plan.first.num_envs*plan.first.rollout
    meta=read(actor.with_suffix(".json"))
    if (not rows or rows[-1]["it"]!=it or record["env_steps"]!=steps or
            any(meta[k]!=rows[-1][k] for k in ("it","stage","stage_it","env_steps","train_s")) or meta["env_steps"]!=steps
            or any(p.stem.isdigit() and int(p.stem)>it for p in (run/"ckpt").iterdir())):
        raise ValueError("A complete stage-one checkpoint and final log row are required")
    with np.load(archive,allow_pickle=False) as data:
        arrays={k:data[k] for k in data.files}
    if len(arrays)!=record["arrays"] or not all(np.isfinite(x).all() for x in arrays.values()):
        raise ValueError("Invalid stage-one array count or nonfinite values")
    with np.load(actor,allow_pickle=False) as policy:
        expected={prefix+k.removeprefix("optimizer/0/pi/"):x for k,x in arrays.items()
                  if k.startswith("optimizer/0/pi/") for prefix in ("avg/","live/")}
        expected.update({"obs_norm/"+k:arrays["optimizer/3/actor/"+k] for k in ("mean","var")})
        if "optimizer/3/actor/raw" in arrays: expected["obs_norm/raw"]=np.bool_(True)
        if set(expected)!=set(policy.files) or not all(_equal_arrays(x,policy[k]) for k,x in expected.items()):
            raise ValueError("The boundary actor/normalization differs from the archived learner")
    tree=_branches(arrays)
    if set(tree)!={"optimizer","discriminator","curriculum","key"} or len(tree["optimizer"])!=4:
        raise ValueError("Unexpected staged learner layout")
    opt=tuple(tree["optimizer"]); disc=tree["discriminator"]; key=tree["key"]; curriculum=Curriculum(**tree["curriculum"])
    _verify_adam(opt[0],opt[1]); _verify_adam(disc["net"],disc["opt"])
    if (int(opt[1]["t"])!=record["actor_adam_steps"] or int(disc["opt"]["t"])!=record["discriminator_adam_steps"]
            or int(curriculum.stage)!=record["curriculum_stage"] or key.shape!=(2,) or key.dtype!=jnp.uint32
            or not np.array_equal(key,record["prng_key"])):
        raise ValueError("The boundary optimizer, curriculum or random clock differs from its manifest")
    return PhaseBoundary(run,it,actor,archive),opt,disc,key,curriculum,steps,float(meta["train_s"])
