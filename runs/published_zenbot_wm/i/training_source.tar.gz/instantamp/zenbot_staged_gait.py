"""Stage one of a single from-scratch Zenbot policy: ordinary source locomotion PPO."""
from pathlib import Path

import jax.numpy as jnp

from . import amp, env
from .train_zenbot_getup_stand_amp import RiseStandAMP
from .train_zenbot_scratch import ScratchAMP, ScratchSettings


def source_configuration(run):
    return ScratchSettings(log_dir=str(Path(run)), source_gait=True, assist_curriculum=False,
                           phase_reset_fraction=0., reference_weight=0., floor_reset_fraction=0.,
                           stand_reference_weight=0., fixed_std=True, init_std=.4, init_lr=.0001,
                           epochs=5, minibatches=4, disc_batch=0, iterations=10000,
                           num_envs=2048, rollout=48, save_every=250, log_every=25, seed=42)


class LocomotionPPO(ScratchAMP):
    gamma, gae_lambda, max_lr, disc_lr = .99, .95, .01, .0001
    amp_frames, amp_stride = 3, 1

    def __init__(self, cfg):
        if cfg.floor_reset_fraction or cfg.reference_guide_path or cfg.online_ground_bank or cfg.assist_curriculum:
            raise ValueError("The locomotion phase uses only source standing resets and PPO/AMP")
        # Reuse the joint simulator and critic without constructing physical labels or a mixed discriminator.
        RiseStandAMP.__init__(self, cfg)
        self.condition_dim = 0
        self.extra_rollout_stats += ("source_speed_stage", "source_completed_episodes",
                                     "source_tracking_error", "source_fall_rate")
        self.motion_metric_names = ("amp_unmixed", "velocity_unmixed", "tilt_unmixed",
                                    "floor_advantage_std", "gait_advantage_std")
        full_frame = self.sim.amp_frame
        self.sim.amp_frame = lambda state: full_frame(state)[..., 6:73]
        self.sim.amp_dim = 67
        self.expert = amp.Demos(cfg.gait_dir, self.sim, self.amp_span, per_clip=True, frame_fn=self.sim.amp_frame)
        if len(self.expert.clip_offsets) != 17 or self.expert.frames.shape[-1] != 67:
            raise ValueError("The physical locomotion discriminator requires the 17 matching 67-channel source clips")

    def rollout_motion(self, disc, motion, transition):
        safe = jnp.where(transition.diverged[:, None, None], 0., motion)
        style = env.DT * amp.recovery_style(disc, safe, scale=1.5, leggedlab=True)
        velocity = env.DT * transition.stats["source_velocity_score"]
        tilt = -1.2 * env.DT * transition.stats["source_tilt_l2"]
        extra = jnp.where(transition.diverged, 0., .3 * (velocity + tilt) + .7 * style)
        return extra, safe, (style.mean(), velocity.mean(), tilt.mean())

    def discriminator_examples(self, key, policy):
        return self.expert.sample(key, len(policy)), policy
