"""Continue one random PPO actor through a locomotion phase and a joint training phase."""
import dataclasses
import hashlib
import inspect
import json
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

from .sim import unflatten
from .train_g1_getup_amp import initial_live
from .zenbot_staged_boundary import digest, read_learner, writer_lock
from .train import save_policy, set_jax
from .zenbot_staged_gait import LocomotionPPO, source_configuration
from .train_zenbot_scratch import ScratchAMP


@dataclasses.dataclass
class StagePlan:
    first: object
    second: object
    switch_after: int = 4500
    stop_after: int = 10000

    @classmethod
    def standard(cls, run, second):
        return cls(source_configuration(run), second)

    def validate(self):
        if not 0 < self.switch_after < self.stop_after:
            raise ValueError("Provide a locomotion phase boundary strictly before the end")
        if self.first.seed != self.second.seed or Path(self.first.log_dir).resolve() != Path(self.second.log_dir).resolve():
            raise ValueError("The two phases must share a run directory and seed")
        for cfg in (self.first, self.second):
            if any(getattr(cfg, field, None) for field in ("init_policy","ground_actor_anchor","policy_anchor",
                                                            "rise_teacher","gait_teacher","rise_anchor")):
                raise ValueError("A staged random policy cannot use a previous policy or policy anchors")


def source_digests(factory):
    paths = list(Path(inspect.getfile(ScratchAMP)).parent.glob("*.py"))
    paths.extend([Path(__file__),Path(inspect.getfile(LocomotionPPO)),Path(inspect.getfile(factory))])
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


@dataclasses.dataclass(frozen=True)
class PhaseBoundary:
    run: Path
    iteration: int
    actor_checkpoint: Path
    learner_archive: Path


def archive_boundary(run, iteration, steps, opt, disc, key, curriculum, hashes):
    """Save the whole transferable learner and verify every array before starting phase two."""
    tree = dict(optimizer=opt, discriminator=disc, key=key, curriculum=curriculum)
    def field(k):
        return str(next(getattr(k, s) for s in ("key","idx","name") if hasattr(k,s)))
    arrays = {"/".join(map(field, path)): np.asarray(x)
              for path,x in jax.tree_util.tree_flatten_with_path(jax.device_get(tree))[0]}
    name = f"transition_{iteration:06}"
    tmp = run / (name+".pending")
    with tmp.open("wb") as stream:
        np.savez(stream, **arrays)
    with np.load(tmp,allow_pickle=False) as check:
        if set(check.files)!=set(arrays) or not all(np.array_equal(check[k],x,equal_nan=False) for k,x in arrays.items()):
            raise ValueError("The phase-boundary archive did not reproduce its learner state")
    archive = run / (name+".npz")
    tmp.replace(archive)
    record = dict(it=iteration, env_steps=steps, archive=archive.name,
                  sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), source_sha256=hashes,
                  arrays=len(arrays), actor_adam_steps=int(opt[1]["t"]), discriminator_adam_steps=int(disc["opt"]["t"]),
                  curriculum_stage=int(curriculum.stage), prng_key=np.asarray(key).tolist())
    tmp.write_text(json.dumps(record, indent=2)+"\n"); tmp.replace(run/(name+".json"))
    return PhaseBoundary(run, iteration, run/"ckpt"/f"{iteration:06}.npz", archive)


def expand_gait_discriminator(disc, width, frames=3):
    """Embed each old gait channel in full frame columns 6..72, zero-initializing additional weights."""
    old = disc["norm"]["mean"].shape[0]
    if width == old:
        return disc
    if old != 67 or width < 73 or disc["net"][0]["w"].shape[0] != frames * old:
        raise ValueError("Expected three source 67-channel frames followed by the joint AMP layout")
    def expand(w):
        per_frame=w.reshape(frames,old,-1)
        return jnp.zeros((frames,width,per_frame.shape[-1]),w.dtype).at[:,6:73].set(per_frame).reshape(frames*width,-1)
    original = disc["net"][0]
    net = [{**original,"w":expand(original["w"])},*disc["net"][1:]]
    first,*other = disc["opt"]["leaves"]
    moments = {**first,"w":jax.tree.map(expand,first["w"])}
    norm = dict(disc["norm"])
    norm["mean"] = jnp.zeros(width,norm["mean"].dtype).at[6:73].set(norm["mean"])
    norm["var"] = jnp.ones(width,norm["var"].dtype).at[6:73].set(norm["var"])
    return {**disc,"net":net,"norm":norm,"opt":{**disc["opt"],"leaves":[moments,*other]}}


def start_second(trainer, opt, disc, environment_key, curriculum):
    """Initialize fresh environments and replay without creating or loading an actor, critic or discriminator."""
    sim=trainer.sim
    # Stage two's initial gait commands use the difficulty attained in stage one.
    sample=sim.sample_command
    sim.sample_command=lambda key,stage=0: sample(key,curriculum.stage)
    try:
        s=sim.init(environment_key)
    finally:
        sim.sample_command=sample
    # The new envs have fresh episodes; old partial-episode errors cannot carry across the reset.
    inherited=curriculum._replace(partial=jnp.zeros_like(s.gait_curriculum.partial))
    s=s._replace(gait_curriculum=inherited)
    actor_width,critic_width=trainer.actor_input(s).shape[-1],trainer.critic_input(s).shape[-1]
    if (actor_width,critic_width)!=(opt[0]["pi"][0]["w"].shape[0],opt[0]["v"][0]["w"].shape[0]):
        raise ValueError("Staged actor and critic observation sizes must stay identical")
    trainer.mask=jax.tree.map(lambda _:False,opt[0])
    trainer.obs_norm={"raw":True,**opt[3]["actor"]}
    frame=sim.amp_frame(unflatten(s.data.qpos,s.data.qvel))
    hist=jnp.repeat(frame[:,None],trainer.amp_span,axis=1)
    width=frame.shape[-1]+trainer.condition_dim
    disc=trainer.fix_condition_norm(expand_gait_discriminator(disc,width,trainer.amp_frames))
    replay=jnp.zeros((244,len(frame),trainer.amp_frames,width),frame.dtype)
    return initial_live(trainer, s, hist, replay), disc


def iteration_kwargs(trainer, absolute, local):
    if hasattr(trainer,"stage_iteration_kwargs"):
        return trainer.stage_iteration_kwargs(absolute,local)
    it=jnp.int32(local)
    collect={"ppo_iteration":it} if getattr(trainer.c,"assist_curriculum",False) else {}
    learn={"ppo_iteration":it} if getattr(trainer.c,"reference_guide_path","") else {}
    return collect,learn


def metric_names(trainer):
    keys=("task_reward","style_reward","assist_n","height","down_done","down_up","diverged",
          *trainer.extra_rollout_stats,*trainer.motion_metric_names,"kl","lr","policy_loss","value_loss",
          "disc_expert","disc_robot")
    if getattr(trainer.c,"reference_guide_path",""):
        keys+=("reference_huber","reference_guide_weight")
    return keys


def _train_phase(trainer, stage, lo, hi, live, opt, disc, key, steps, boundary, run, log, started):
    cfg=trainer.c
    collect=jax.jit(trainer.collect)
    learn=jax.jit(trainer.learn,donate_argnums=(0,1))
    aux=trainer.init_stage_aux(opt,boundary) if hasattr(trainer,"init_stage_aux") else None
    previous_rollout=None
    for it in range(lo+1,hi+1):
        local=it-lo
        key,kc,kl=jax.random.split(key,3)
        if hasattr(trainer,"before_stage_collect"):
            opt,aux=trainer.before_stage_collect(opt,aux,previous_rollout,jax.random.fold_in(kc,419),it,local)
        ck,lk=iteration_kwargs(trainer,it,local)
        live,batch,rollout=collect(live,opt[0],disc,kc,*opt[3:],**ck)
        opt,disc,metrics=learn(opt,disc,batch,live[2],live[3],kl,local>cfg.critic_warmup,**lk)
        if hasattr(trainer,"before_stage_collect"):
            previous_rollout=(trainer.retain_stage_rollout(batch,live,jax.random.fold_in(kl,34),it,local)
                              if hasattr(trainer,"retain_stage_rollout") else batch)
        steps+=cfg.num_envs*cfg.rollout
        save=it%cfg.save_every==0 or it==hi
        if local==1 or it%cfg.log_every==0 or save:
            vals=np.asarray(jax.device_get(jnp.r_[rollout,metrics]))
            if not np.isfinite(vals).all(): raise FloatingPointError(vals)
            row=dict(zip(metric_names(trainer),map(float,vals),strict=True))
            meta=dict(it=it,stage=stage,stage_it=local,env_steps=steps,train_s=time.monotonic()-started)
            line=json.dumps({**meta,**row})
            print(line,flush=True);log.write(line+"\n")
        if save:
            pi=jax.device_get(opt[0]["pi"])
            save_policy(str(run/"ckpt"/f"{it:06}"),{"pi":pi,"avg":pi,"obs_norm":opt[3]["actor"]},meta)
    return live,opt,disc,key,steps


def _joint_phase(plan, make_stage2, previous, boundary, opt, disc, key, curriculum, steps, log, started):
    trainer=make_stage2(previous,plan.second)
    key,env_key=jax.random.split(key)
    live,disc=start_second(trainer,opt,disc,env_key,curriculum)
    _,opt,disc,key,_=_train_phase(trainer,2,plan.switch_after,plan.stop_after,live,opt,disc,key,steps,
                                  boundary,boundary.run,log,started)
    return opt,disc,key


def train_staged(plan, make_stage2, *, make_stage1=LocomotionPPO, stop_at_boundary=False):
    """Train one random learner. Optionally exit only after the full stage boundary is published."""
    plan.validate()
    set_jax("~/.cache/instantamp/jax")
    run=Path(plan.first.log_dir)
    run.mkdir(parents=True,exist_ok=True)
    with writer_lock(run):
        (run/"ckpt").mkdir(exist_ok=False)
        return _fresh_staged(plan,make_stage2,make_stage1,stop_at_boundary,run)


def _fresh_staged(plan,make_stage2,make_stage1,stop_at_boundary,run):
    hashes=source_digests(make_stage2)
    def config(c): return dataclasses.asdict(c)
    (run/"config.json").write_text(json.dumps(dict(seed=plan.first.seed, switch_after=plan.switch_after,
                                  iterations=plan.stop_after, first=config(plan.first), second=config(plan.second),
                                  training_source_sha256=hashes),indent=2,default=str)+"\n")
    trainer=make_stage1(plan.first)
    live,opt,disc=trainer.init()  # the only policy/discriminator initialization in this run
    pi=jax.device_get(opt[0]["pi"])
    first_policy=run/"ckpt"/"000000"
    save_policy(str(first_policy),{"pi":pi,"avg":pi,"obs_norm":opt[3]["actor"]},{"it":0,"env_steps":0,"train_s":0.0})
    sha=hashlib.sha256(first_policy.with_suffix(".npz").read_bytes()).hexdigest()
    (run/"initialization.json").write_text(json.dumps({"it":0,"seed":plan.first.seed,"sha256":sha,
                                                         "initialization":"seeded_random"},indent=2)+"\n")
    key=jax.random.PRNGKey(plan.first.seed+1)
    started=time.monotonic()
    with (run/"log.jsonl").open("x",buffering=1) as log:
        live,opt,disc,key,steps=_train_phase(trainer,1,0,plan.switch_after,live,opt,disc,key,0,None,run,log,started)
        curriculum=live[0].gait_curriculum
        boundary=archive_boundary(run,plan.switch_after,steps,opt,disc,key,curriculum,hashes)
        del live
        if stop_at_boundary:
            return opt,disc,key
        return _joint_phase(plan,make_stage2,trainer,boundary,opt,disc,key,curriculum,steps,log,started)


def continue_staged(plan, make_stage2):
    """Continue this run from its verified stage-one boundary; make_stage2(None, settings) must not need an old simulator."""
    plan.validate()
    set_jax("~/.cache/instantamp/jax")
    run=Path(plan.first.log_dir)
    with writer_lock(run,check_legacy=True):
        boundary,opt,disc,key,curriculum,steps,elapsed=read_learner(run,plan)
        provenance=dict(iteration=boundary.iteration,seed=plan.first.seed,env_steps=steps,
                        actor_sha256=digest(boundary.actor_checkpoint),archive_sha256=digest(boundary.learner_archive),
                        second=dataclasses.asdict(plan.second),source_sha256=source_digests(make_stage2))
        path=run/f"continuation_{boundary.iteration:06}.json"
        tmp=path.with_suffix(".pending")
        tmp.write_text(json.dumps(provenance,indent=2,default=str)+"\n")
        tmp.replace(path)
        with (run/"log.jsonl").open("a",buffering=1) as log:
            return _joint_phase(plan,make_stage2,None,boundary,opt,disc,key,curriculum,steps,log,time.monotonic()-elapsed)
