"""Add floor recovery to the same locomotion policy using physically visited source states."""
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from functools import partial

import jax
import jax.numpy as jnp
import numpy as np

from . import zenbot
from .train_zenbot_scratch import ScratchAMP, ScratchSettings
from .zenbot_motion_train_obs import motion_train_actor_mean


@dataclasses.dataclass
class RecoverySettings(ScratchSettings):
    floor_reward_scale: float = 1.

    def __post_init__(self):
        super().__post_init__()
        if not 0. <= self.floor_reward_scale <= 1.:
            raise ValueError("floor_reward_scale must be finite and in [0, 1]")


def recovery_configuration(run, *, floor_reward_scale=1.):
    run = Path(run)
    return RecoverySettings(
        log_dir=str(run), seed=42, iterations=10000, num_envs=2048, rollout=48,
        source_gait=True, short_amp_window=True, fixed_std=True, init_std=.4, epochs=5,
        minibatches=4, disc_batch=2048, init_lr=1e-4, reference_weight=0.,
        floor_reset_fraction=.5, phase_reset_fraction=.85, assist_curriculum=True,
        zero_motor_delay_probability=.5, staged_side_and_turn_commands=True, floor_reward_scale=floor_reward_scale,
        online_ground_bank=str(run / "ground_bank.npz"),
        reference_guide_path=str(run / "reference_pairs" / "train.npz"),
        guide_weight=0., guide_final_weight=0., reference_fit_steps=4,
    )


def sample_side_and_turn_commands(source_sampler, key, stage=0):
    """Keep all source stops and half of moving draws. Give each requested side-step or pivot an equal share."""
    command = source_sampler(key, stage)
    # Tickets 0..3 select the existing left, right, left-turn and right-turn commands in that order.
    ticket = jax.random.randint(jax.random.fold_in(key, 761), command.is_standing.shape, 0, 8)
    replace = (ticket < 4) & ~command.is_standing
    directions = jnp.asarray(zenbot.DIRECTIONAL_COMMANDS[4:8])
    velocity = jnp.where(replace[:, None], directions[ticket % 4], command.vel)
    return command._replace(vel=velocity, is_heading=command.is_heading & ~replace)


def minimum_reset_phase(first_support, iteration):
    # Initially reset about half a second after both feet take the body weight.
    remaining = jnp.clip((1500 - iteration) / 1499., 0., 1.)
    return ((first_support + 20) * remaining).astype(jnp.int32)


@jax.jit
def capture_floor_batch(batch, key):
    """Keep actual recovery observations and motor labels for the next actor update."""
    observations, targets, kind = batch[0], batch[7], batch[8]
    counts = jnp.cumsum((kind == 1).astype(jnp.int32))
    tickets = jax.random.randint(key, (512,), 1, jnp.maximum(1, counts[-1]) + 1)
    rows = jnp.minimum(jnp.searchsorted(counts, tickets, side="left"), len(kind) - 1)
    return observations[rows], targets[rows], counts[-1] > 0


def range_adjustment(actor, norm, floor, behavior):
    """Offer a wider input range only when it preserves the measured healthy gait actions."""
    from .zenbot_staged_retention import broaden

    old_mean, old_var = np.asarray(norm["mean"]), np.asarray(norm["var"])
    clipping = np.mean(np.abs((floor - old_mean) / np.sqrt(old_var + 1e-4)) > 10.)
    record = dict(floor_clipped_fraction=float(clipping), applied=False)
    if clipping <= .01:
        return actor, norm, record
    candidate, candidate_norm = broaden(actor, norm, floor)
    predict = jax.jit(motion_train_actor_mean)
    before, after = (predict(p, n, behavior) for p, n in ((actor, norm), (candidate, candidate_norm)))
    drift = float(np.quantile(np.rad2deg(.25 * np.abs(np.asarray(after - before))), .99))
    record["gait_motor_change_p99_deg"] = drift
    if drift < .25:
        record["applied"] = True
        return jax.tree.map(jnp.asarray, candidate), jax.tree.map(jnp.asarray, candidate_norm), record
    return actor, norm, record


class StagedRecovery(ScratchAMP):
    physical_gait_windows = False
    reference_skill_count = 1
    gamma, gae_lambda, max_lr, disc_lr = .99, .95, .001, .0001

    def __init__(self, cfg):
        super().__init__(cfg)
        if cfg.staged_side_and_turn_commands:
            self.sim.sample_command = partial(sample_side_and_turn_commands, self.sim.sample_command)
        bank_path = Path(cfg.online_ground_bank)
        support = json.loads((bank_path.parent / "support_frames.json").read_text())
        with np.load(bank_path, allow_pickle=False) as bank:
            if (support["clip_names"] != bank["clip_names"].tolist() or
                    support["ground_bank_sha256"] != hashlib.sha256(bank_path.read_bytes()).hexdigest()):
                raise ValueError("Support frame indices must use the same physical ground trajectories")
        first = np.asarray(support["first_support"], dtype=np.int32)
        if first.shape != self.online_bank.lengths.shape or np.any(first < 1) or np.any(first + 30 >= self.online_bank.lengths):
            raise ValueError("Every recovery trajectory needs a measured support frame and another 30 recorded ticks")
        self.first_support = jnp.asarray(first)
        self.virtual_ground_queue = cfg.zero_motor_delay_probability > 0.
        if self.virtual_ground_queue:
            self.sim.physical_floor_starts.immediate_ground_bank = self.online_bank
        self.sim.floor["minimum_phase"] = minimum_reset_phase(self.first_support, 1)
        self.sim.floor["down_counts"] = self.first_support + 31

    def blend_reward(self, transition, motion_reward):
        reward = super().blend_reward(transition, motion_reward)
        scale = getattr(self.c, "floor_reward_scale", 1.)
        if scale == 1.:
            return reward
        # The recovery branch averages task and style. parts already includes dt and the threefold rate weight.
        rate = .5 * transition.parts[..., self.sim.terms.index("action_rate_l2")]
        floor_reward = rate + scale * (reward - rate)
        return jnp.where(transition.stats["source_gait_active"], reward, floor_reward)

    def collect(self, live, ac, disc, key, norms=None, *, ppo_iteration=None):
        state, *tail = live
        phases = minimum_reset_phase(self.first_support, ppo_iteration)
        floor = {**state.world.floor, "minimum_phase": phases}
        state = state._replace(world=state.world._replace(floor=floor))
        return super().collect((state, *tail), ac, disc, key, norms, ppo_iteration=ppo_iteration)

    def online_ground_targets(self, state):
        target, kind, phase = self.measured_ground_target(state)
        handoff = self.first_support[jnp.maximum(state.reference_clip, 0)] + 25
        return target, jnp.where((kind == 1) & (phase < handoff), 1, 0)

    def online_ground_with_queue(self, state, queue):
        from .zenbot_immediate_ground import ground_target
        from .zenbot_online_ground import measured_floor_loads

        history = state.motion_train_sensors.frames
        return ground_target(
            self.online_bank, state.data.qpos, state.data.qvel, history[:, -1, 55:], history[:, -2, 55:],
            state.reference_clip, state.reference_start, state.t, state.c_obs, state.gait_ready,
            measured_floor_loads(self.sim, state), state.delay_steps, queue, self.first_support,
        )

    def sample_reference_rows(self, key, count):
        cold, changing, mixed = jax.random.split(key, 3)
        n_cold = count // 8
        n_changing = (count - n_cold) // 2
        return jnp.concatenate((
            jax.random.choice(cold, self.opening_rows, (n_cold,)),
            jax.random.choice(changing, self.changing_rows, (n_changing,)),
            self.guide_rows[0, jax.random.randint(mixed, (count - n_cold - n_changing,), 0, self.guide_counts[0])],
        ))

    def rollout_guidance(self, state, kind, iteration):
        mix, _ = super().rollout_guidance(state, kind, iteration)
        recovering = (state.reference_clip >= 0) & ~state.gait_ready
        # The same scales enter the stored PPO likelihood on every transition.
        return mix, jnp.where(recovering, .3, 1.)

    def init_stage_aux(self, opt, boundary):
        from .zenbot_staged_retention import init_optimizer

        run = Path(self.c.log_dir)
        if boundary.actor_checkpoint.resolve() != (run / "ckpt" / f"{boundary.iteration:06}.npz").resolve():
            raise ValueError("Retention requires the gait checkpoint just saved by this run")
        out = run / "retention.npz"
        subprocess.run([sys.executable, "-m", "tools.collect_zenbot_staged_retention", "--run-dir", str(run),
                        "--iteration", str(boundary.iteration), "--out", str(out)], check=True,
                       env={**os.environ, "JAX_PLATFORMS": "cpu", "CUDA_VISIBLE_DEVICES": "",
                            "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
        with np.load(out, allow_pickle=False) as data:
            x, y, groups = data["obs"], data["q_target_raw"], data["group"]
        self.behavior_obs, self.behavior_targets = jnp.asarray(x), jnp.asarray(y)
        rows = [np.flatnonzero(groups == group) for group in range(8)]
        if min(map(len, rows)) < 16:
            raise ValueError("Expected all eight locomotion commands in the same-run retention samples")
        self.behavior_counts = jnp.asarray([len(g) for g in rows])
        self.behavior_rows = jnp.asarray(np.stack([np.pad(g, (0, max(map(len, rows)) - len(g))) for g in rows]))
        source_rows = np.asarray(self.guide_rows[0, :int(self.guide_counts[0])])
        floor = np.asarray(self.guide_obs[source_rows[::max(1, len(source_rows) // 8192)]])
        pi, norm, report = range_adjustment(opt[0]["pi"], opt[3]["actor"], floor, x[::2])
        (run / "stage2_observation_range.json").write_text(json.dumps(report, indent=2) + "\n")
        self._first_actor = (pi, norm) if report["applied"] else None
        return init_optimizer(pi)

    def retain_stage_rollout(self, batch, live, key, global_it, stage_it):
        return capture_floor_batch(batch, key)

    def before_stage_collect(self, opt, aux, previous_rollout, key, global_it, stage_it):
        ac, adam, rate, norms = opt
        if stage_it == 1 and self._first_actor is not None:
            pi, norm = self._first_actor
            ac, norms = {**ac, "pi": pi}, {**norms, "actor": norm}
            layers = adam["leaves"]["pi"]
            # The first layer uses new units. Its two coordinate-wise Adam moments start fresh.
            adam = {**adam, "leaves": {**adam["leaves"], "pi": [jax.tree.map(jnp.zeros_like, layers[0]), *layers[1:]]}}
            self._first_actor = None
        if previous_rollout is not None:
            pi, aux = self._fit(ac["pi"], aux, norms["actor"], previous_rollout, key)
            ac = {**ac, "pi": pi}
        return (ac, adam, rate, norms), aux

    def _fit(self, actor, adam, norm, previous_rollout, key):
        from .zenbot_staged_retention import fit_step
        if not hasattr(self, "_compiled_fit"):
            def update(actor, adam, norm, previous, key):
                visited_x, visited_y, has_visited = previous
                def step(carry, key):
                    sampled, recent, gait = jax.random.split(key, 3)
                    idx = self.sample_reference_rows(sampled, 128)
                    x, y = self.guide_obs[idx], self.guide_targets[idx]
                    new = jax.random.randint(recent, (32,), 0, len(visited_x))
                    # Always keep cold openings and fast ground transitions in the other 96 rows.
                    x = x.at[-32:].set(jnp.where(has_visited, visited_x[new], x[-32:]))
                    y = y.at[-32:].set(jnp.where(has_visited, visited_y[new], y[-32:]))
                    rows = jax.random.randint(gait, (8, 16), 0, self.behavior_counts[:, None])
                    idx_gait = self.behavior_rows[jnp.arange(8)[:, None], rows].reshape(-1)
                    pi, moments, _ = fit_step(*carry, norm, x, y, self.behavior_obs[idx_gait],
                                              self.behavior_targets[idx_gait])
                    return (pi, moments), None
                return jax.lax.scan(step, (actor, adam), jax.random.split(key, self.c.reference_fit_steps))[0]
            self._compiled_fit = jax.jit(update)
        return self._compiled_fit(actor, adam, norm, previous_rollout, key)


def make_recovery(previous, settings):
    return StagedRecovery(settings)
