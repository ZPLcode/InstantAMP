"""Actor-only supervised update for two equally sized batches. No changes to the PPO optimizer."""

import jax
import jax.numpy as jnp
import numpy as np
from instantamp import optim
from instantamp.zenbot_motion_train_obs import motion_train_actor_mean

BATCH_PER_SOURCE = 128
RETENTION_WEIGHT = 256.0
SUPERVISED_LR = 1e-4


def broaden(actor, norm, floor, fraction=0.25):
    """Mix floor observation moments into the stage normalization and convert the first affine layer.

    For inputs inside both normalization clip ranges, the preactivation is invariant. Saturated coordinates
    can change the action, so the caller tests the retained gait actions before accepting the result.
    The optimizer and all layers except the input layer are untouched. This runs once on the host.
    """
    sample = np.asarray(floor)
    if "raw" in norm or sample.ndim != 2 or sample.shape[1] != len(norm["mean"]) or not len(sample):
        raise ValueError("Expected normalized actor inputs and nonempty floor observations of matching width")
    if not 0 <= fraction <= 1 or not np.isfinite(sample).all():
        raise ValueError("Expected finite floor observations and a fraction between zero and one")
    if fraction == 0:
        return actor, norm
    old_mean = np.asarray(norm["mean"], dtype=np.float64)
    old_var = np.asarray(norm["var"], dtype=np.float64)
    floor_mean = sample.mean(axis=0, dtype=np.float64)
    floor_var = sample.var(axis=0, dtype=np.float64)
    new_mean = (1.0 - fraction) * old_mean + fraction * floor_mean
    new_var = (
        (1.0 - fraction) * old_var
        + fraction * floor_var
        + fraction * (1.0 - fraction) * (old_mean - floor_mean) ** 2
    )
    old_std = np.sqrt(old_var + 0.01**2)
    new_std = np.sqrt(new_var + 0.01**2)
    original = actor[0]
    weights = np.asarray(original["w"], dtype=np.float64)
    bias = np.asarray(original["b"], dtype=np.float64) + ((new_mean - old_mean) / old_std) @ weights
    converted = dict(
        original,
        w=jnp.asarray((new_std / old_std)[:, None] * weights, original["w"].dtype),
        b=jnp.asarray(bias, original["b"].dtype),
    )
    next_norm = dict(
        norm, mean=jnp.asarray(new_mean, norm["mean"].dtype), var=jnp.asarray(new_var, norm["var"].dtype)
    )
    return [converted, *actor[1:]], next_norm


def init_optimizer(actor):
    """Create these moments once at the transition into the recovery stage."""
    return optim.init(actor, jax.tree.map(lambda _: False, actor))


def action_loss(predicted, requested):
    error = jnp.abs(predicted - requested)
    return jnp.where(error < 1.0, 0.5 * error**2, error - 0.5).mean()


@jax.jit
def fit_step(actor, adam, norm, floor_obs, floor_raw, self_obs, self_mean):
    """Take one guide update on raw 23-motor targets and the frozen rollout input normalization.

    Run this outside the PPO minibatch loop, before collecting the next on-policy rollout.
    The retention states and labels stay fixed for the stage. Only the actor and its dedicated
    Adam moments are returned. The caller owns its critic, PPO moments, exploration and step clock.
    """
    if floor_obs.shape != (128, 234) or self_obs.shape != (128, 234):
        raise ValueError("Expected 128 234-channel observations from each source")
    if floor_raw.shape != (128, 23) or self_mean.shape != (128, 23):
        raise ValueError("Expected 128 23-motor requests from each source")

    def objective(weights):
        obs = jnp.concatenate((floor_obs, self_obs))
        raw = motion_train_actor_mean(weights, norm, obs)
        floor = action_loss(raw[:BATCH_PER_SOURCE], floor_raw)
        retained = action_loss(raw[BATCH_PER_SOURCE:], self_mean)
        return (floor + RETENTION_WEIGHT * retained) / (1.0 + RETENTION_WEIGHT), (floor, retained)

    (loss, (floor, retained)), g = jax.value_and_grad(objective, has_aux=True)(actor)
    grad, _ = optim.clip_by_global_norm(g, 1.0)
    mask = jax.tree.map(lambda _: False, actor)
    updated, moments = optim.step(actor, grad, adam, mask, SUPERVISED_LR)
    return updated, moments, {"supervised_loss": loss, "floor_huber": floor, "retention_huber": retained}
