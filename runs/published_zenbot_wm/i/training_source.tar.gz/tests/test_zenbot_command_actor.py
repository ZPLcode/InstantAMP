import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import zenbot
from instantamp.inference import load, policy_output
from instantamp.native_zenbot import ZenbotNative
from instantamp.zenbot_command_actor import initialize_command_actor


def test_gait_teacher_observations_match_the_physical_imu_through_tilt_and_yaw():
    from scipy.spatial.transform import Rotation
    from instantamp.zenbot_command_actor import gait_teacher_observation

    rng = np.random.default_rng(327)
    frames = rng.normal(size=(2, 5, 99)).astype("f")
    rot = Rotation.random(10, random_state=rng).as_matrix().reshape(2, 5, 3, 3)
    yaw = np.arctan2(rot[..., 1, 0], rot[..., 0, 0])
    remove_yaw = Rotation.from_euler("z", -yaw.reshape(-1, 1)).as_matrix().reshape(rot.shape)
    local = remove_yaw @ rot
    frames[..., 3:6], frames[..., 6:9] = local[..., 0], local[..., 2]
    expected = np.concatenate((frames[..., :3], -rot[..., 2, :], frames[..., -3:],
                               frames[..., 9:32] - zenbot.DEFAULT_Q, frames[..., 32:78]), axis=-1)
    np.testing.assert_allclose(gait_teacher_observation(frames), expected.reshape(2, -1), atol=2e-6)


@pytest.mark.parametrize("raw", [True, False])
def test_interleaved_command_warmstart_preserves_all_outputs_and_full_width_resume(tmp_path, raw):
    rng = np.random.default_rng(193)
    old = tmp_path / "old.npz"
    w = rng.normal(0, 0.03, (480, 23)).astype("f")
    mean = rng.normal(size=480).astype("f")
    var = rng.uniform(0.3, 2.0, 480).astype("f")
    params = {"avg/0/w": w, "avg/0/b": np.zeros(23, "f"), "obs_norm/mean": mean, "obs_norm/var": var}
    if raw:
        params["obs_norm/raw"] = True
    np.savez(old, **params)
    template = {
        "pi": [{"w": jnp.zeros((495, 23)), "b": jnp.zeros(23)}],
        "obs_norm": {"mean": jnp.zeros(495), "var": jnp.ones(495)},
    }
    wide = initialize_command_actor(template, old)
    assert len(wide["pi"]) == 1
    source, norm, _ = load(old)
    inputs = rng.normal(size=(11, 5, 99)).astype("f")
    inputs[:, :, -3:] = rng.uniform(-5.0, 5.0, (11, 5, 3))
    np.testing.assert_array_equal(wide["pi"][0]["w"].reshape(5, 99, 23)[:, -3:], 0.0)
    np.testing.assert_array_equal(wide["obs_norm"]["var"].reshape(5, 99)[:, -3:], 1.0)
    expected = policy_output(source, norm, inputs[:, :, :96].reshape(11, 480))
    actual = policy_output(wide["pi"], wide["obs_norm"], inputs.reshape(11, 495))
    np.testing.assert_allclose(actual, expected, atol=3e-6, rtol=3e-6)
    full = tmp_path / "full.npz"
    full_w = rng.normal(size=(495, 23)).astype("f")
    np.savez(
        full,
        **{
            **params,
            "avg/0/w": full_w,
            "obs_norm/mean": wide["obs_norm"]["mean"],
            "obs_norm/var": wide["obs_norm"]["var"],
        },
    )
    np.testing.assert_array_equal(initialize_command_actor(template, full)["pi"][0]["w"], full_w)


def test_native_command_is_observed_and_command_policy_hot_reload_preserves_world(tmp_path):
    bank = tmp_path / "bank"
    bank.mkdir()
    count = 32
    q = np.tile(zenbot.DEFAULT_Q, (count, 1))
    np.savez(
        bank / "stand.npz",
        fps=50.0,
        dof_pos=q,
        dof_vel=np.zeros_like(q),
        root_pos=np.tile([0.0, 0.0, 0.69], (count, 1)),
        root_quat=np.tile([0.0, 0.0, 0.0, 1.0], (count, 1)),
        root_lin_vel=np.zeros((count, 3)),
        root_ang_vel=np.zeros((count, 3)),
    )
    weights = np.zeros((495, 23), "f")
    weights[-3, 0] = 0.25
    path = tmp_path / "cmd.npz"

    def save(weight):
        np.savez(
            path,
            **{
                "avg/0/w": weight,
                "avg/0/b": np.zeros(23, "f"),
                "obs_norm/raw": True,
                "obs_norm/mean": np.zeros(495, "f"),
                "obs_norm/var": np.ones(495, "f"),
            },
        )

    save(weights)
    native = ZenbotNative(bank, path, walk_dir=bank)
    assert native.command_gait and native.sim.obs_dim == 495
    assert native.support_load.shape == (8,)
    pose = np.r_[0.0, 0.0, 0.69, 1.0, 0.0, 0.0, 0.0, zenbot.DEFAULT_Q]
    native.reset(pose, np.zeros(29), np.full(5, 5), command=(2.5, 0.0, 0.0))
    native.step()
    assert native.previous[0] == pytest.approx(0.625)
    qpos, old_history = native.data.qpos.copy(), np.asarray(native.history).copy()
    save(weights * 2)
    native.replace_policy(path)
    np.testing.assert_array_equal(qpos, native.data.qpos)
    np.testing.assert_array_equal(old_history, native.history)
    native.command = jnp.array([[1.0, 0.0, 0.0]])
    native.step()
    assert native.previous[0] == pytest.approx(0.5)
    np.testing.assert_array_equal(np.asarray(native.history)[0, -3:], np.array([1.0, 0.0, 0.0]))
def test_viewer_can_command_trained_gaits_and_ignore_other_keys():
    from types import SimpleNamespace
    from tools.play_zenbot_getup import ZenbotPlayer

    player = SimpleNamespace(native=SimpleNamespace(command=jnp.zeros((1, 3))), speed=0.)
    for key, expected in [("1", 1.), ("2", 2.5), ("Z", 2.5), ("S", 2.4), ("X", 0.)]:
        ZenbotPlayer.handle_key(player, ord(key))
        assert player.speed == expected
        np.testing.assert_allclose(player.native.command, [[expected, 0., 0.]])

    for key, command in [("B", [-.5, 0., 0.]), ("A", [0., .4, 0.]), ("D", [0., -.4, 0.]),
                         ("Q", [0., 0., .6]), ("E", [0., 0., -.6]), ("X", [0., 0., 0.])]:
        ZenbotPlayer.handle_key(player, ord(key))
        np.testing.assert_allclose(player.native.command, [command])


def test_calibrated_command_onset_changes_only_the_requested_axis_and_vanishes_at_constant_speed(tmp_path):
    from tools.calibrate_zenbot_commands import calibrate

    weights = np.random.default_rng(128).normal(size=(234, 6)).astype(np.float32)
    original, adjusted = tmp_path / "original.npz", tmp_path / "adjusted.npz"
    np.savez(original, **{"avg/0/w": weights, "obs_norm/mean": np.zeros(234), "obs_norm/raw": True})
    calibrate(original, adjusted, lateral=(1., 2.), turn=(1., 0.))
    with np.load(adjusted) as archive:
        modified = archive["avg/0/w"]
    lateral = [19, 22, 25]
    other = np.ones(234, dtype=bool)
    other[lateral] = False
    np.testing.assert_array_equal(modified[other], weights[other])
    np.testing.assert_allclose(modified[lateral].sum(0), weights[lateral].sum(0), atol=1e-6)
    np.testing.assert_allclose(modified[25] - weights[25], 2. * weights[lateral].sum(0), atol=1e-6)

