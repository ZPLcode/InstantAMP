import jax
import jax.numpy as jnp
import numpy as np

from instantamp import env, zenbot
from instantamp.sim import Sim, unflatten


def test_directional_command_sampler_keeps_stand_distinct_from_pure_yaw():
    cmd = zenbot.sample_gait_command(jax.random.PRNGKey(23), 256, directional=True)
    expected = np.asarray([[0., 0., 0.], [1., 0., 0.], [2.5, 0., 0.], [-.5, 0., 0.],
                           [0., .4, 0.], [0., -.4, 0.], [0., 0., .6], [0., 0., -.6]], np.float32)
    np.testing.assert_array_equal(np.unique(cmd.vel, axis=0), np.unique(expected, axis=0))
    np.testing.assert_array_equal(cmd.is_standing, np.all(cmd.vel == 0., axis=-1))


def test_command_actor_history_exposes_commands_and_preserves_motors(tmp_path):
    upright = tmp_path / 'upright'
    floor = tmp_path / 'floor'
    for directory, heights in [(upright, [.1, .65, .70]), (floor, [.20, .48, .66])]:
        directory.mkdir()
        q = np.tile(zenbot.DEFAULT_Q, (3, 1))
        q[:, 0] = np.arange(3)
        z = np.zeros((3, 3))
        np.savez(directory / 'motion.npz', root_pos=np.column_stack((z[:, :2], heights)),
                 root_quat=np.tile([0, 0, 0, 1], (3, 1)), root_ang_vel=z, root_lin_vel=z,
                 dof_pos=q, dof_vel=np.zeros_like(q), fps=50)
    opts = dict(robot='zenbot23_getup', floor_dir=str(floor), physics=False, assist_newtons=0.,
                zenbot_getup_stand=True, zenbot_support_weight=8., zenbot_standing_amp=True,
                reset_floor=.5, prob_shove=0., randomize_world=False)
    sim = Sim(96, walk_dir=str(upright), zenbot_command_gait=True, **opts)
    prev = Sim(96, **opts)
    np.testing.assert_allclose(sim.weights["action_rate_l2"], -.015)
    k = jax.random.PRNGKey(19)
    pos, vel, up = sim._fresh(k, sim.world(k))
    assert np.any(up) and not np.all(up)
    np.testing.assert_allclose(pos[~up, 2], .22)
    np.testing.assert_allclose(pos[~up, 7], 0.)
    assert set(np.round(np.asarray(pos[up, 2]), 2).tolist()) == set(np.float32([.65, .70]).tolist())
    action = jnp.zeros((sim.N, sim.J))
    c = sim.sample_command(k)
    assert set(np.asarray(c.vel[:, 0])) == {0., 1., 2.5}
    np.testing.assert_allclose(c.vel[:, 1:], 0.)
    old = prev.obs_frame(unflatten(pos, vel), action, None, None)
    new = sim.obs_frame(unflatten(pos, vel), action, c.vel, None)
    np.testing.assert_allclose(new[:, :96], old)
    np.testing.assert_allclose(new[:, 96:], c.vel)
    np.testing.assert_allclose(sim.obs_frame(unflatten(pos, vel), action, c.vel, k)[:, 96:], c.vel)
    assert sim.push_actor(None, new).shape == (96, 495)
    command2 = env.tick(c._replace(time_left=jnp.zeros(96)), jax.random.fold_in(k, 7), sample=sim.sample_command)
    assert np.any((c.vel[:, 0] > 0.) & (command2.vel[:, 0] == 0.))
    assert np.any((c.vel[:, 0] == 0.) & (command2.vel[:, 0] > 0.))
    c_unchanged = env.tick(command2, jax.random.fold_in(k, 8), sample=sim.sample_command)
    np.testing.assert_equal(np.asarray(c_unchanged.vel), np.asarray(command2.vel))


def test_gait_handoff_requires_getup_and_tolerates_flight_but_not_falls():
    # The readiness latch does not use sole force after takeoff; leaning/floor contact revokes it.
    prior = jnp.array([False, False, True, True, True, True, True])
    hold = jnp.array([.98, 1., 0., 0., 1., 0., 0.])
    height = jnp.array([.67, .69, .80, .43, .64, .70, .66])
    up = jnp.array([1., 1., .96, 1., .8, .5, .99])
    limbs = jnp.array([0., 0., 0., 0., .12, 0., 0.])
    invalid = jnp.array([False] * 6 + [True])
    np.testing.assert_array_equal(zenbot.ready_for_gait(prior, hold, height, up, limbs, invalid),
                                  [False, True, True, False, False, False, False])


def test_scratch_resets_pair_command_and_motion_and_only_score_live_floor_reference(tmp_path):
    gait, floor = tmp_path / "gait", tmp_path / "floor"
    gait.mkdir()
    floor.mkdir()
    n = 48
    zero = np.zeros((n, 3))
    quat = np.tile([0., 0., 0., 1.], (n, 1))
    q = np.tile(zenbot.DEFAULT_Q, (n, 1))
    names = ("stand_4s_120f", "Male1_B1_StandToWalk", "run__C3_-_run_stageii",
             "male_walk__Walk_B4_-_Stand_to_Walk_Back_stageii", "droidupe1_side_left",
             "droidupe1_side_right", "droidupe1_turn_left", "droidupe1_turn_right")
    for group, (name, target) in enumerate(zip(names, zenbot.DIRECTIONAL_COMMANDS)):
        yaw = np.arange(n) * env.DT * target[2]
        rot = np.column_stack((zero[:, :2], np.sin(yaw/2), np.cos(yaw/2)))
        velocity = np.tile([*target[:2], 0.], (n, 1))
        np.savez(gait / (name + ".npz"), root_pos=zero + [0., 0., .69], root_quat=rot,
                 root_ang_vel=zero + [0., 0., target[2]], root_lin_vel=velocity,
                 dof_pos=q + .01 * group, dof_vel=q*0, fps=50)
    pos = zero.copy()
    pos[:, 2] = np.linspace(.2, .7, n)
    np.savez(floor / "rise.npz", root_pos=pos, root_quat=quat, root_ang_vel=zero, root_lin_vel=zero,
             dof_pos=q, dof_vel=q*0, fps=50)
    sim = Sim(128, physics=False, robot="zenbot23_getup", floor_dir=str(floor), walk_dir=str(gait),
              zenbot_getup_stand=True, zenbot_support_weight=8., zenbot_standing_amp=True, zenbot_command_gait=True,
              zenbot_directional_gait=True, zenbot_scratch_resets=True, zenbot_phase_resets=.5, reference_weight=8.,
              reset_floor=.5)
    key = jax.random.PRNGKey(19)
    group = np.arange(sim.N) % len(names)
    cmd = jnp.asarray(zenbot.DIRECTIONAL_COMMANDS[group])
    (qpos, qvel, up), (source, phase) = sim._fresh(key, sim.world(key), return_source=True, command=cmd)
    np.testing.assert_array_equal(up, np.arange(sim.N) >= sim.N//2)
    np.testing.assert_array_equal(source < 0, up)
    np.testing.assert_array_equal(phase[up], 0)
    assert .25 < np.mean(phase[~up] > 0) < .75
    np.testing.assert_allclose(qpos[up, 7:], q[0] + .01 * group[up, None], atol=1e-6)
    state = unflatten(qpos, qvel)
    action = jnp.zeros((sim.N, sim.J))
    for elapsed in (0, n):
        terms = sim.reward_terms(state, state, None, action, action, torque=action, clip=source,
                                 step=elapsed, reference_start=phase)
        score = np.asarray(terms["motion_reference"])
        np.testing.assert_array_equal(score[up], 0.)
        if elapsed == 0:
            assert score[~up].min() > .9
        else:
            np.testing.assert_array_equal(score[~up], 0.)
