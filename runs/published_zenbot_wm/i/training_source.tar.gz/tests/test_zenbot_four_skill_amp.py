from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import amp, env
from instantamp.train_zenbot_getup_stand_amp import RiseStandAMP, Settings, gait_skill_weights


def test_one_discriminator_scores_fallen_standing_walking_and_running_windows(monkeypatch):
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.condition_dim = 4
    trainer.c = Settings()
    stats = {
        "stand_blend": jnp.array([0., .5, 1., 1., 0., 1.]),
        "gait_command": jnp.column_stack((jnp.array([2.5, 1., 0., 1., 2.5, 1.75]), jnp.zeros((6, 2)))),
        "gait_velocity_error": jnp.zeros((6, 3)),
        "gait_ready": jnp.array([False, False, True, True, True, True]),
    }
    identity = object()
    def score(disc, windows, **kwargs):
        assert disc is identity
        return windows[:, -1, -4:] @ jnp.array([1., 3., 5., 9.])

    monkeypatch.setattr(amp, "recovery_style", score)
    motion = jnp.zeros((6, 10, 12))
    reward, replay, terms = trainer.rollout_motion(identity, motion, SimpleNamespace(stats=stats))
    weights = [[1,0,0,0], [.5,.5,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1], [0,0,.5,.5]]
    np.testing.assert_allclose(replay[:, -1, -4:], weights)
    np.testing.assert_allclose(reward / env.DT, [1., 2., 3., 9., 13., 11.], rtol=1e-6)
    assert len(terms) == 5
    stats["gait_velocity_error"] = stats["gait_velocity_error"].at[3, 1].set(.5).at[4, 2].set(.6)
    turning, _, _ = trainer.rollout_motion(identity, motion, SimpleNamespace(stats=stats))
    np.testing.assert_allclose((reward - turning) / env.DT, [0., 0., 0., 2., 2., 0.], atol=1e-6)


def test_directional_travel_shares_the_walk_condition_after_rising():
    commands = jnp.array([[-.5, 0., 0.], [0., .4, 0.], [0., -.4, 0.], [0., 0., .6], [0., 0., -.6]])
    np.testing.assert_array_equal(gait_skill_weights(jnp.ones(5), commands, jnp.ones(5, bool)),
                                  np.tile([0., 0., 1., 0.], (5, 1)))
    np.testing.assert_array_equal(gait_skill_weights(jnp.zeros(5), commands, jnp.zeros(5, bool)),
                                  np.tile([1., 0., 0., 0.], (5, 1)))


def test_equal_labels_on_each_expert_policy_pair_and_ordered_gait_frames():
    class Bank:
        def __init__(self, label):
            self.label = label

        def sample(self, key, count):
            start = jax.random.randint(key, (count,), 0, 500)
            frames = jnp.broadcast_to(jnp.arange(28.)[None, :, None], (count, 28, 20))
            return frames.at[..., 0].set(self.label).at[..., 1].add(start[:, None])

    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.condition_dim = 4
    trainer.sim = SimpleNamespace(J=2)
    trainer.demos, trainer.stand_demos, trainer.walk_demos, trainer.run_demos = [Bank(i) for i in range(4)]
    labels = jnp.eye(4)
    motion = jnp.zeros((4, 10, 20))
    expert, policy = trainer.discriminator_examples(jax.random.PRNGKey(1), trainer.conditioned(motion, labels))
    np.testing.assert_array_equal(expert[..., -4:], policy[..., -4:])
    np.testing.assert_array_equal(expert[:, -1, -4:], labels)
    np.testing.assert_array_equal(expert[:, 0, 0], np.arange(4))
    np.testing.assert_array_equal(np.diff(expert[..., 1], axis=1), 3.)
