import hashlib
import json
from types import SimpleNamespace

import numpy as np
import pytest

from tools.collect_zenbot_recovery_gait import select_stands


def test_selection_requires_single_attempt_and_different_seeds(tmp_path):
    # Two low-drift trials from one seed compete for the same slot. Old reports
    # have no height trace and cannot certify how many elevations preceded standing.
    candidates = [(1, 0, .15), (1, 0, .25), (2, 1, .02), (3, None, .01), (4, 0, .30)]
    directories = []
    for i, (seed, retries, drift) in enumerate(candidates):
        path = tmp_path / str(i)
        path.mkdir()
        row = dict(clip="clip", seed=seed, offset=0., usable=True, command=0., rise_s=1., reference_rise_s=1.,
                   frames=3, sample_episode=0, pelvis_excursion_m=drift, foot_excursion_m=drift)
        if retries is not None:
            row["pre_rise_attempts"] = dict(retries=retries)
        (path / "summary.json").write_text(json.dumps([row]))
        labels = dict(teacher_speed=np.full((3, 5), .7, "f"), gait_blend=np.full(3, .5, "f")) if i == 4 else {}
        np.savez(path / "expert.npz", x=np.full((3, 495), i), u=np.full((3, 23), i), mode=np.zeros(3), **labels)
        directories.append(path)
    out = tmp_path / "selected"
    select_stands(directories, out, 2)
    with np.load(out / "expert.npz") as data:
        np.testing.assert_array_equal(data["x"][:, 0], [0, 0, 0, 4, 4, 4])
        assert np.isnan(data["teacher_speed"][:3]).all() and np.isnan(data["gait_blend"][:3]).all()
        np.testing.assert_allclose(data["teacher_speed"][3:], .7)
        np.testing.assert_allclose(data["gait_blend"][3:], .5)
    assert [r["seed"] for r in json.loads((out / "summary.json").read_text())] == [1, 4]


def test_recorded_teacher_history_reconstructs_actions_with_fixed_student_command(tmp_path, monkeypatch):
    import mujoco
    from instantamp import zenbot
    from instantamp.sim import build_scene
    from tools import collect_zenbot_recovery_gait as collector

    model = build_scene(robot_name="zenbot23_getup")
    pose = np.r_[0., 0., .69, 1., 0., 0., 0., zenbot.DEFAULT_Q]
    np.savez(tmp_path / "test.npz", fps=50., root_pos=np.tile(pose[:3], (32, 1)),
             root_quat=np.tile([0., 0., 0., 1.], (32, 1)))
    bodies = [model.body("robot_" + n).id for n in zenbot.KEY_BODIES]
    scene = model, mujoco.MjData(model), bodies, [], 0, 1.
    # A fixed supported pose isolates input/output timing from the stability of a mock actor.
    monkeypatch.setattr(collector, "motor_step", lambda *args: (np.full(2, .5), np.zeros(4, bool)))
    opts = SimpleNamespace(seed=42, delay=2, blend=6, warm=1, min_height=.58, max_speed=.65, up_cos=.9,
                           weak_load=.05, hold_command=True, command=2.5, steps=120, floor=tmp_path,
                           allow_pre_rise_retries=False)
    rise = lambda history: np.zeros(23)
    gait = lambda history: np.full(23, .25 + history[:, 6].mean())
    _, samples = collector.rollout(opts, scene, (rise, gait), 0, ("test.npz", 0.), pose, np.zeros(29), np.zeros(23))
    inputs, actions, _, speeds, blends = map(np.asarray, samples)
    frames = inputs.reshape(-1, 5, 99)
    assert np.all(frames[:, :, 96] == 2.5) and np.any((speeds[:, -1] > 0.) & (speeds[:, -1] < 2.5))
    assert np.any((blends > 0.) & (blends < 1.))
    np.testing.assert_allclose(speeds[1:, :-1], speeds[:-1, 1:])
    np.testing.assert_allclose(actions[:, 0], blends * (.25 + speeds.mean(1)))
    np.testing.assert_allclose(frames[1:, -1, 55:78], actions[:-1], rtol=1e-6)


def test_saved_gait_layout_checks_archive_hash_and_saved_term_order(tmp_path):
    pytest.importorskip("onnx")
    from tools.pack_zenbot_walk_recovery import saved_gait_layout

    config = tmp_path / "params/env.yaml"
    config.parent.mkdir()
    cfg = ("observations:\n  policy:\n    concatenate_terms: true\n    history_length: 3\n"
           "    history_order: term\n    flatten_history_dim: true\n")
    terms = ("base_ang_vel", "projected_gravity", "velocity_commands", "joint_pos", "joint_vel", "actions")
    config.write_text(cfg + "".join(f"    {term}:\n      history_length: 0\n" for term in terms))
    source = tmp_path / "exported/policy.onnx"
    source.parent.mkdir()
    source.write_bytes(b"hash-only fixture")
    meta = source.with_name("export_info.json")
    meta.write_text(json.dumps({"onnx_sha256": hashlib.sha256(source.read_bytes()).hexdigest()}))
    assert saved_gait_layout(source) == ("3", "term")
    config.write_text(config.read_text().replace("base_ang_vel:", "wrong:"))
    with pytest.raises(ValueError, match="observation layout"):
        saved_gait_layout(source)
    meta.write_text(json.dumps({"onnx_sha256": "invalid"}))
    with pytest.raises(ValueError, match="hashes differ"):
        saved_gait_layout(source)
