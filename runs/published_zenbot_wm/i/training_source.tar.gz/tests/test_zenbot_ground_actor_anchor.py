from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import g1_getup, zenbot
from instantamp.train_zenbot_getup_stand_amp import RiseStandAMP, Settings


def test_anchor_matches_pre_action_floor_states_and_releases_standing():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="getup.npz", ground_actor_anchor=2.)
    trainer.validate(trainer.c)
    assert trainer.action_anchor_strength == 2.
    heights = [zenbot.FULL_FORCE_HEIGHT - .04,
               (zenbot.FULL_FORCE_HEIGHT + zenbot.UP_HEIGHT) / 2,
               zenbot.UP_HEIGHT, zenbot.RISE_HEIGHT]
    qpos = jnp.zeros((len(heights), 30)).at[:, 2].set(jnp.array(heights))
    weights = trainer.action_anchor_weights(SimpleNamespace(data=SimpleNamespace(qpos=qpos)), None)
    np.testing.assert_allclose(weights, [1., .5, 0., 0.], atol=1e-6)
    # This minibatch moves all actions equally far from the frozen actor.
    # Only its ground samples should incur an imitation gradient.
    actions = jnp.ones((len(heights), 23))
    gradients = jax.grad(g1_getup.rise_anchor_loss)(actions, jnp.zeros_like(actions), weights)
    assert np.all(gradients[:2] > 0)
    np.testing.assert_array_equal(gradients[2:], 0.)


@pytest.mark.parametrize("weight, checkpoint", [(1., ""), (-.1, "a.npz"), (float("nan"), "a.npz")])
def test_invalid_ground_teacher(weight, checkpoint):
    with pytest.raises(ValueError, match="ground"):
        RiseStandAMP.validate(Settings(init_policy=checkpoint, ground_actor_anchor=weight))


def test_joint_checkpoint_can_anchor_its_actions_throughout_the_rollout():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="four_skills.npz", policy_anchor=40.)
    trainer.validate(trainer.c)
    qpos = jnp.zeros((3, 30)).at[:, 2].set(jnp.array([.1, .45, .67]))
    state = SimpleNamespace(data=SimpleNamespace(qpos=qpos))
    assert trainer.action_anchor_strength == 40.
    np.testing.assert_array_equal(trainer.action_anchor_weights(state, None), np.ones(3))


def test_optional_floor_teacher_sees_the_original_five_frames():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="joint.npz", policy_anchor=40., rise_teacher="floor.npz", gait_dir="gait")
    trainer.validate(trainer.c)
    trainer.anchor_pi = [{"w": jnp.zeros((495, 1)), "b": jnp.ones(1)}]
    trainer.obs_norm = {"raw": True}
    # Read the last physical sensor immediately before the command at the end of frame four.
    teacher_weights = jnp.zeros((480, 1)).at[4 * 96 - 1, 0].set(1.)
    trainer.floor_teacher = ([{"w": teacher_weights, "b": jnp.ones(1)}], {"raw": True})
    obs = jnp.zeros((3, 5, 99)).at[:, 3, 95].set(8.).at[:, :, 96:].set(3.)
    targets, weights = trainer.action_anchor_examples(obs.reshape(3, -1), jnp.array([0., .5, 1.]))
    np.testing.assert_allclose(targets[:, 0], [1., 5., 9.])
    np.testing.assert_array_equal(weights, np.ones(3))
    trainer.c.rise_teacher_share = .25
    mixed, weights = trainer.action_anchor_examples(obs.reshape(3, -1), jnp.array([0., .5, 1.]))
    np.testing.assert_allclose(mixed[:, 0], [1., 2., 3.])
    np.testing.assert_array_equal(weights, np.ones(3))


def test_delayed_floor_teacher_only_weights_low_unrecovered_states():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="joint", policy_anchor=20., rise_teacher="floor",
                         gait_dir="motions", rise_teacher_after_s=2.)
    trainer.condition_dim = 4
    trainer.validate(trainer.c)
    q = jnp.zeros((5, 30)).at[:, 2].set(jnp.array([.25, .25, .25, .70, .25]))
    state = SimpleNamespace(data=SimpleNamespace(qpos=q), t=jnp.array([50, 125, 185, 185, 185]),
                            gait_ready=jnp.array([False, False, False, False, True]))
    np.testing.assert_allclose(trainer.action_anchor_weights(state, None), [0., .5, 1., 0., 0.])


def test_walking_labels_only_correct_measured_outlying_angles_after_recovery():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="joint", policy_anchor=100., rise_teacher="floor",
                         gait_teacher="gait", gait_dir="motions", walk_teacher_pose_gain=.5)
    trainer.validate(trainer.c)
    def constant(width, action):
        return [{"w": jnp.zeros((width, 23)), "b": jnp.full(23, float(action))}], {"raw": True}
    trainer.anchor_pi, trainer.obs_norm = constant(495, 0.)
    trainer.floor_teacher, trainer.locomotion_teacher = constant(480, -1.), constant(390, 1.)
    trainer.walk_angle_range = jnp.stack((-jnp.ones(23), jnp.ones(23)))
    frames = jnp.zeros((4, 5, 99)).at[:, :, 9].set(-1.5)
    frames = frames.at[:, :, -3].set(jnp.array([1., 2.5, 0., 1.])[:, None])
    context = jnp.array([[0., 1.], [0., 1.], [0., 1.], [1., 0.]])
    targets, mask = trainer.action_anchor_examples(frames.reshape(4, -1), context)
    np.testing.assert_allclose(targets[0, 0], .25 / zenbot.ACTION_SCALE)
    np.testing.assert_allclose(targets[0, 1:], 0.)
    np.testing.assert_allclose(targets[1:3], 1.)
    np.testing.assert_allclose(targets[3], -1.)
    np.testing.assert_allclose(mask, 1.)


def test_motion_train_student_and_privileged_teachers_read_their_own_observations():
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.c = Settings(init_policy="student", policy_anchor=100., rise_teacher="floor", gait_teacher="gait",
                         gait_dir="motions", directional_gait=1, motion_train_obs=1, walk_teacher_pose_gain=.5)
    trainer.validate(trainer.c)
    trainer.obs_norm = {"raw": True}
    # The student's anchor only sees 234 channels. The floor teacher still sees landmark 95.
    trainer.anchor_pi = [{"w": jnp.zeros((234, 23)), "b": jnp.full(23, 3.)}]
    floor_weights = jnp.zeros((480, 23)).at[-1].set(1.)
    trainer.floor_teacher = ([{"w": floor_weights, "b": jnp.zeros(23)}], {"raw": True})
    gait_weights = jnp.zeros((390, 23)).at[-78+7].set(1.)
    trainer.locomotion_teacher = ([{"w": gait_weights, "b": jnp.ones(23)}], {"raw": True})
    trainer.walk_angle_range = (-jnp.ones(23), jnp.ones(23))
    frames = jnp.zeros((4, 5, 99)).at[..., 95].set(17.)
    commands = jnp.array([[0., 0., .6], [0., 0., -.6], [1., 0., 0.], [1., .4, 0.]])
    frames = frames.at[:, -1, -3:].set(commands)
    actor_obs = jnp.zeros((4, 234))  # the actor input retained from the simulated sensor readings
    context = jnp.array([[1., 0.], [0., 0.], [0., 1.], [0., 1.]])
    targets, mask = trainer.action_anchor_examples(frames.reshape(4, -1), context, actor_obs)
    np.testing.assert_allclose(targets, np.tile([17., 3., 3., 1.4], (23, 1)).T, atol=5e-4)
    np.testing.assert_array_equal(mask, np.ones(4))
