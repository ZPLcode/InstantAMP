import jax
import jax.numpy as jnp
import numpy as np

from instantamp.zenbot_immediate_ground import delivered, delivered_prefix, ground_target, initial_queue
from instantamp.zenbot_online_ground import labels
from test_zenbot_online_ground import fake_bank


def test_mixed_actuator_labels_preserve_delayed_domain_and_clear_handoff():
    b = fake_bank()
    c = jnp.array([0, 1, 2, 3, -1])
    start = jnp.array([0, 9, 0, 16, 0])
    age = jnp.array([0, 0, 2, 4, 2])
    idx = jnp.maximum(c, 0)
    q, v = b.q[idx, start + age], b.v[idx, start + age]
    lag = jnp.array([[0]*5, [0]*5, [3,7,6,4,5], [7,4,5,6,3], [0]*5])
    rng = np.random.default_rng(667)
    prev, old = jnp.asarray(rng.normal(size=(2, 5, 23)), jnp.float32)
    queue = jnp.asarray(rng.normal(size=(5, 2, 23)), jnp.float32)
    cmd, ready, support = jnp.zeros((5, 3)), jnp.zeros(5, bool), jnp.full((4,), 30)
    call = jax.jit(ground_target)
    args = (b, q, v, prev, old, c, start, age, cmd, ready, cmd, lag, queue, support)
    target, kind, updated = call(*args)
    # Both normal positive-delay worlds retain the original phase, target and launch convention.
    def normal(bank, q, v, prev, old, c, start, age, cmd, ready, loads, lag, queue, support):
        delay = jnp.where(((start==0) & (age<3))[:,None] & (lag>0), 5, lag)
        return labels(bank, q, v, prev, old, c, start, age, cmd, ready, loads, delay, physical_reset_phase=True)
    expected, original_kind, _ = jax.jit(normal)(*args)
    np.testing.assert_array_equal(target[2:], expected[2:])
    np.testing.assert_array_equal(kind[2:4], original_kind[2:4])
    np.testing.assert_array_equal(updated[2:], 0.)
    reference = initial_queue(b, c, start)
    np.testing.assert_allclose(updated[:2, 1], reference[:2, 0])
    np.testing.assert_allclose(target[0], updated[0, 0])
    np.testing.assert_allclose(target[1], delivered(updated[:,0],reference,b.delay_groups[idx])[1],atol=1e-7)
    # PPO can select any real action; it does not replace a nominal controller request in the queue.
    variant = (*args[:3], prev+13., old-13., *args[5:])
    target2, _, q2 = call(*variant)
    np.testing.assert_array_equal(target[:2],target2[:2])
    np.testing.assert_array_equal(updated[:2],q2[:2])
    # Disqualify by a physical state outside the source, then test an otherwise valid handoff phase.
    rejected = call(b,q.at[1,2].add(5.),*args[2:])[2]
    np.testing.assert_array_equal(rejected[1],0.)
    late = call(*args[:-1], jnp.full_like(support, -25))
    np.testing.assert_array_equal(late[1][:2], 0)
    np.testing.assert_array_equal(late[2][:2], 0.)


def test_source_prefix_restores_delivered_motor_history_and_unfiltered_teacher_requests():
    b = fake_bank()._replace(delay_groups=jnp.array([[3,4,5,6,7]]*4))
    clip, phase = jnp.array([0,1,2,-1]), jnp.array([0,1,12,0])
    records = np.asarray(delivered_prefix(b, clip, phase))
    queue = np.asarray(initial_queue(b, clip, phase))
    for i, (c,t) in enumerate(zip(np.asarray(clip),np.asarray(phase),strict=True)):
        def raw(step):
            return np.asarray(b.raw[c,step]) if c>=0 and step>=0 else np.zeros(23)
        np.testing.assert_array_equal(queue[i],np.stack((raw(t-1),raw(t-2))))
        from instantamp.zenbot import GROUP
        lag=np.asarray(b.delay_groups[max(c,0)])[GROUP]
        for j,k in enumerate(range(t-5,t)):
            expected=np.mean([np.where(s>=lag,raw(k),np.where(s+4>=lag,raw(k-1),raw(k-2))) for s in range(4)],axis=0)
            if 0 <= k < 3:
                expected = raw(k)
            np.testing.assert_allclose(records[i,j],expected,atol=1e-7)


def test_first_three_cold_ground_actions_share_the_launch_target_in_both_actuator_domains():
    bank = fake_bank()
    clip = jnp.arange(4)
    tick = jnp.arange(4)
    queue = initial_queue(bank, clip, tick)
    positive = jnp.array([[3, 4, 5, 6, 7]] * 4)
    duplicated = lambda x: jnp.concatenate((x, x), axis=0)
    clip, tick, queue = map(duplicated, (clip, tick, queue))
    command = jnp.zeros((8, 3))
    target, kind, updated = jax.jit(ground_target)(
        bank, bank.q[clip, tick], bank.v[clip, tick], queue[:, 0], queue[:, 1],
        clip, jnp.zeros_like(tick), tick, command, jnp.zeros(8, bool), command,
        jnp.concatenate((jnp.zeros_like(positive), positive)), queue, jnp.full(4, 30),
    )
    np.testing.assert_array_equal(kind, 1)
    np.testing.assert_array_equal(target[:3], target[4:7])
    np.testing.assert_array_equal(target[:3], updated[:3, 0])
    filtered = delivered(updated[:4, 0], queue[:4], bank.delay_groups[clip[:4]])
    np.testing.assert_allclose(target[3], filtered[3], atol=1e-7)
    assert not np.allclose(target[3], updated[3, 0])


def test_collector_retains_requests_across_rollouts_and_clears_each_ended_world():
    from types import SimpleNamespace
    from test_zenbot_online_ground import Data, State, Transition
    from test_zenbot_scratch_reference_guide import learner

    trainer, optimizer, discriminator = learner("fixed.npz", 6., False)
    trainer.c.online_ground_bank = "synthetic"
    trainer.c.assist_curriculum = False
    trainer.c.rollout = 1
    trainer.virtual_ground_queue = True
    trainer.extra_rollout_stats = ()
    trainer.amp_stride = 1
    trainer.actor_input = lambda state: state.obs
    trainer.critic_input = lambda state: state.obs[:, :6]
    trainer.motion_features = lambda window: window
    trainer.rollout_motion = lambda disc, features, transition: (jnp.zeros(4), features, ())
    trainer.online_ground_with_queue = lambda state, queue: (
        jnp.ones((4, 23)), jnp.ones(4, jnp.int32), queue + 1.,
    )

    def step(state, action):
        return state, Transition(
            state.data.qpos, state.data.qvel, action.mean(axis=1),
            jnp.array([True, False, False, False]), jnp.array([False, True, False, False]),
            dict(down_done=0., down_up=0., diverged=0.),
        )

    trainer.sim = SimpleNamespace(step=step, amp_frame=lambda state: state[0])
    q = jnp.zeros((4, 30)).at[:, 3].set(1.)
    state = State(Data(q, jnp.zeros((4, 29))), jnp.zeros((4, 234)), jnp.zeros(4), jnp.ones((4, 3)))
    live = (state, jnp.zeros((4, 10, 3)), jnp.zeros((4, 4, 10, 3)), jnp.int32(0), jnp.zeros((4, 2, 23)))
    for expected in (1, 2):
        live, _, _ = trainer.collect(live, optimizer[0], discriminator, jax.random.key(expected),
                                     optimizer[3], ppo_iteration=jnp.int32(1))
        np.testing.assert_array_equal(live[4][:2], 0.)
        np.testing.assert_array_equal(live[4][2:], expected)
