from pathlib import Path
from types import SimpleNamespace
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import zenbot
from instantamp.sim import Sim
from instantamp.train_zenbot_scratch import ScratchAMP
from instantamp.zenbot_online_ground import aligned_reference_actions


class CPUData(NamedTuple):
    qpos: object
    qvel: object
    qacc_warmstart: object

    def replace(self, **changes):
        return self._replace(**changes)


def simulator():
    data = Path("data/zenbot23_walk_run_recovery")
    sim = Sim(
        96,
        physics=False,
        robot="zenbot23_getup",
        floor_dir=str(data / "recovery"),
        walk_dir=str(data / "walk_run"),
        zenbot_getup_stand=True,
        zenbot_support_weight=8.0,
        zenbot_standing_amp=True,
        zenbot_command_gait=True,
        zenbot_directional_gait=True,
        zenbot_motion_train_obs=True,
        zenbot_scratch_resets=True,
        zenbot_scratch_curriculum=True,
        zenbot_source_gait=True,
        zenbot_phase_resets=0.8,
        reset_floor=0.5,
        random_start=False,
        obs_noise=False,
        assist_newtons=0.0,
    )
    sim.dx = CPUData(jnp.zeros(30), jnp.zeros(29), jnp.zeros(29))
    return sim


def test_partial_episode_reset_inherits_timing_and_all_four_physics_targets():
    sim = simulator()
    k = jax.random.key(532)
    init_key = jax.random.split(k, 5)[1]
    original = jax.random.randint(jax.random.fold_in(init_key, 9), (sim.N, 5), 3, 8)
    s = sim.init(k)
    np.testing.assert_array_equal(s.delay_steps, original)
    sim.zero_motor_delay_probability = 0.5
    mix = sim.init(k)
    mask = np.asarray(jax.random.bernoulli(jax.random.fold_in(init_key, 760), 0.5, (sim.N, 1)))
    np.testing.assert_array_equal(mix.delay_steps, np.where(mask, 0, original))
    assert mask[:48].any() and mask[48:].any()
    for before, after in zip(
        jax.tree.leaves(s._replace(delay_steps=mix.delay_steps)), jax.tree.leaves(mix), strict=True
    ):
        if jax.dtypes.issubdtype(before.dtype, jax.dtypes.prng_key):
            before, after = jax.random.key_data(before), jax.random.key_data(after)
        np.testing.assert_array_equal(before, after)
    sim.zero_motor_delay_probability = 1.0
    done = np.arange(sim.N) % 3 == 0
    nxt = sim._reset(mix, jnp.asarray(done), jax.random.key(845))
    np.testing.assert_array_equal(nxt.delay_steps, np.where(done[:, None], 0, mix.delay_steps))

    # Three distinct requests make every off-by-one in the four servo ticks observable.
    u = np.linspace(-2, 2, 23, dtype=np.float32)
    a = jnp.broadcast_to(u, (sim.N, 23))
    frames = (
        mix.obs.reshape(sim.N, sim.history, sim.frame_dim)
        .at[:, -1, 55:78]
        .set(a + 4)
        .at[:, -2, 55:78]
        .set(a - 3)
    )
    control = sim.control_targets(a, mix.world.bias, frames.reshape(mix.obs.shape), sim.context(mix))
    expected = np.empty((sim.N, 4, 23), np.float32)
    for w in range(sim.N):
        for tick in range(4):
            delay = np.asarray(mix.delay_steps[w])[zenbot.GROUP]
            raw = np.where(tick >= delay, u, np.where(tick + 4 >= delay, u + 4, u - 3))
            expected[w, tick] = zenbot.DEFAULT_Q + 0.25 * raw - np.asarray(mix.world.bias[w])
    np.testing.assert_array_equal(control.reshape(expected.shape), expected)


def test_physical_labels_use_fractional_delivery_time_and_preserve_old_domain():
    rng = np.random.default_rng(67)
    a = rng.normal(size=(8, 17, 23)).astype(np.float32)
    plan = np.array([[3, 4, 5, 6, 7], [7, 6, 5, 4, 3]] * 4, np.int32)
    bank = SimpleNamespace(raw=jnp.asarray(a), lengths=jnp.full(8, 17), delay_groups=jnp.asarray(plan))
    clip = jnp.arange(8)
    phase = jnp.asarray([0, 1, 2, 3, 7, 12, 16, 19])

    def read(c, k, j):
        return a[c, min(k, 16), j] if k >= 0 else np.float32(0)

    for immediate in (False, True):
        timing = np.zeros((8, 5), np.int32) if immediate else np.array([plan[1], plan[0]] * 4)
        got = aligned_reference_actions(bank, clip, phase, jnp.asarray(timing))
        for prev, raw in enumerate(got):
            expected = np.zeros((8, 23), np.float32)
            for c in range(8):
                t = int(phase[c]) - prev
                if t < 0:
                    continue
                for j, g in enumerate(zenbot.GROUP):
                    delta = (timing[c, g] - plan[c, g]) / 4
                    if immediate:
                        stamp = t + delta
                        ix = int(np.floor(stamp))
                        expected[c, j] = (1 - (stamp - ix)) * read(c, ix, j) + (stamp - ix) * read(
                            c, ix + 1, j
                        )
                    else:
                        base = read(c, t, j)
                        expected[c, j] = base + np.float32(abs(delta)) * (
                            read(c, t + int(np.sign(delta)), j) - base
                        )
            if immediate:
                np.testing.assert_allclose(raw, expected, atol=3e-7, rtol=1e-7)
            else:
                np.testing.assert_array_equal(raw, expected)

    # A zero-latency ground birth keeps its true opening lag at 0. The previous
    # neutral-lag rule is retained for all original hardware until the fourth frame.
    from unittest.mock import patch

    from instantamp import zenbot_online_ground as ground

    ticks = jnp.array([0, 1, 2, 3, 15])
    lags = jnp.asarray([[0] * 5, [7, 5, 4, 3, 6], [0] * 5, [4, 3, 7, 6, 5], [0] * 5])
    s = SimpleNamespace(
        motion_train_sensors=SimpleNamespace(frames=jnp.zeros((5, 3, 78))),
        reference_start=jnp.zeros(5),
        t=ticks,
        delay_steps=lags,
        reference_clip=jnp.zeros(5),
        data=CPUData(None, None, None),
        c_obs=None,
        gait_ready=None,
    )
    with (
        patch.object(ground, "measured_floor_loads", return_value=None),
        patch.object(ground, "labels", side_effect=lambda *args, **kw: args[-1]),
    ):
        actual = ScratchAMP.measured_ground_target(SimpleNamespace(online_bank=None, sim=None), s)
    np.testing.assert_array_equal(
        actual, np.where(np.asarray(ticks[:, None] < 3) & (np.asarray(lags) > 0), 5, lags)
    )


def test_only_recorded_timing_can_supervise_optional_gait_windows():
    from instantamp.zenbot_physical_gait_starts import PhysicalGaitStarts

    command = jnp.ones((2, 3))
    bank = SimpleNamespace(actions=jnp.ones((8, 23)), sensor=jnp.ones((8, 78)))
    state = SimpleNamespace(
        gait_window=jnp.array([[0, 6], [0, 6]]),
        t=jnp.ones(2, jnp.int32),
        c_obs=command,
        delay_steps=jnp.array([[3, 4, 5, 6, 7], [0, 0, 0, 0, 0]]),
    )
    target, use = PhysicalGaitStarts.target(bank, state)
    np.testing.assert_array_equal(use, [True, False])
    np.testing.assert_array_equal(target, 1.0)


@pytest.mark.parametrize("p", [-0.01, 1.01, float("nan")])
def test_fraction_range(p):
    with pytest.raises(ValueError, match="probability"):
        Sim(1, physics=False, robot="zenbot23_getup", zero_motor_delay_probability=p)
