from types import SimpleNamespace
from typing import NamedTuple

import jax
import jax.numpy as jnp
import mujoco as mj
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp import nets, zenbot as z
from instantamp.sim import Sim
from instantamp.zenbot_online_ground import (
    GroundBank,
    labels,
    measured_floor_loads,
    quaternion_tangent,
    stance_target,
)
from instantamp.train_g1_getup_amp import normalized_input
from test_zenbot_scratch_reference_guide import assert_tree_equal, learner


def test_native_quaternion_and_gravity_feedback_global_heading():
    rng = np.random.default_rng(762)
    dst = Rotation.random(256, random_state=rng)
    ref = Rotation.random(256, random_state=rng)
    qw = dst.as_quat(scalar_first=True)
    rw = ref.as_quat(scalar_first=True)
    actual = np.asarray(quaternion_tangent(rw, qw))
    expected = []
    for a, b in zip(qw, rw):
        vec = np.empty(3)
        mj.mju_subQuat(vec, a, b)
        expected.append(vec)
    np.testing.assert_allclose(actual, expected, atol=6e-6)
    np.testing.assert_allclose(quaternion_tangent(-rw, qw), expected, atol=6e-6)
    eq = Rotation.from_euler("ZYX", [0.4, -0.06, 0.02])
    yaw = Rotation.from_euler("Z", rng.uniform(-np.pi, np.pi, (256, 1)))
    robot = yaw * eq * Rotation.from_euler("xy", rng.uniform(-0.1, 0.1, (256, 2)))
    qr = robot.as_quat(scalar_first=True)
    q = np.c_[np.zeros((256, 3)), qr, np.zeros((256, 23))]
    v = rng.normal(0, 0.2, (256, 29))
    tau = rng.normal(size=23)
    measured = stance_target(q, v, eq.as_quat(scalar_first=True), tau)
    aligned = Rotation.from_euler("Z", (robot.as_euler("ZYX")[:, 0] - eq.as_euler("ZYX")[0])[:, None]) * eq
    rot = (aligned.inv() * robot).as_rotvec()
    truth = np.tile(tau, (256, 1))
    for joint, axis in ((4, 1), (10, 1), (5, 0), (11, 0)):
        truth[:, joint] += 100 * rot[:, axis] + 20 * v[:, 3 + axis]
    np.testing.assert_allclose(measured, truth / (z.KP * z.ACTION_SCALE), atol=8e-6)


def fake_bank():
    rng = np.random.default_rng(77)
    n = 4
    f = 30
    q = rng.normal(0, 0.015, (n, f, 30))
    q[:, :, 2] = 0.34 + np.arange(f) * 0.004
    q[:, :, 3:7] = [1, 0, 0, 0]
    v = rng.normal(0, 0.05, (n, f, 29))
    raw = rng.normal(0, 0.2, (n, f, 23))
    gain = rng.normal(0, 0.06, (n, f, 23, 104))
    return GroundBank(
        *[jnp.asarray(x, dtype=jnp.float32) for x in (q, v, raw, gain)],
        jnp.full(n, f),
        jnp.zeros(n, jnp.int32),
        jnp.full((n, 5), 5),
        jnp.array([1.0, 0.0, 0.0, 0.0]),
        jnp.arange(23) * 0.2,
        jnp.zeros(n, jnp.int32),
    )


def test_local_feedback_units_phase_offset_trust_commands_and_support():
    bank = fake_bank()
    c = np.arange(4)
    step = np.array([0, 1, 12, 23])
    start = np.array([0, 0, 5, 12])
    q = np.asarray(bank.q)[c, step].copy()
    q[:, :2] -= np.asarray(bank.q)[c, start, :2]
    v = np.asarray(bank.v)[c, step].copy()
    prev = np.full((4, 23), 0.3)
    older = np.full((4, 23), -0.2)
    age = step - start
    args = (
        prev,
        older,
        c,
        start,
        age,
        np.tile([1.0, 0, 0], (4, 1)),
        np.zeros(4, bool),
        np.zeros((4, 3)),
    )
    target, kind, k = jax.jit(labels)(bank, q, v, *args)
    np.testing.assert_array_equal(k, step)
    np.testing.assert_array_equal(kind, 1)
    for j in c:
        last = np.asarray(bank.raw[j, step[j] - 1]) if step[j] >= 1 else np.zeros(23)
        old = np.asarray(bank.raw[j, step[j] - 2]) if step[j] >= 2 else np.zeros(23)
        dx = np.r_[np.zeros(58), 0.25 * (prev[j] - last), 0.25 * (older[j] - old)]
        expected = bank.raw[j, step[j]] + np.clip(np.asarray(bank.gain[j, step[j]]) @ dx, -0.65, 0.65) / 0.25
        np.testing.assert_allclose(target[j], expected, atol=8e-6)
    q[:, 2] = 0.68
    q[:, 7:] = z.DEFAULT_Q
    cmd = np.zeros((4, 3))
    cmd[2, 0] = 1.0
    force = np.array([[0.4, 0.4, 0], [0.4, 0.4, 0], [0.4, 0.4, 0], [0.4, 0.4, 0.4]])
    a, kind, _ = labels(
        bank, q, v, prev, older, c - 1, start, np.ones(4, int), cmd, np.zeros(4, bool), force
    )
    np.testing.assert_array_equal(kind, [2, 0, 0, 0])
    np.testing.assert_array_equal(a[2:], 0.0)
    q[:, 2] = 0.2
    q[:, 3:7] = [0.0, 1.0, 0.0, 0.0]
    a, kind, _ = labels(bank, q, v, *args)
    np.testing.assert_array_equal(kind, 0)
    np.testing.assert_array_equal(a, 0.0)


def test_actual_group_motor_delay_histories_and_contact_loads():
    rng = np.random.default_rng(90)
    n = 5
    current, prev, old = rng.normal(size=(3, n, 23)).astype("f")
    lag = rng.integers(3, 8, (n, 5))
    history = np.zeros((n, 5, 99), "f")
    history[:, -1, 55:78] = prev
    history[:, -2, 55:78] = old
    sim = SimpleNamespace(robot=z, J=23, history=5, frame_dim=99)
    actual = Sim.control_targets(
        sim,
        jnp.asarray(current),
        jnp.zeros((n, 23)),
        jnp.asarray(history.reshape(n, -1)),
        jnp.asarray(np.c_[np.ones((n, 2)), lag, np.zeros(n)]),
    ).reshape(n, 4, 23)
    gj = lag[:, z.GROUP]
    expected = np.stack(
        [z.DEFAULT_Q + 0.25 * np.where(s >= gj, current, np.where(s + 4 >= gj, prev, old)) for s in range(4)],
        axis=1,
    )
    np.testing.assert_array_equal(actual, expected)
    contacts = SimpleNamespace(
        contact__worldid=jnp.array([0, 0, 1, 1]),
        contact__efc_address=jnp.array([[0, -1], [1, -1], [0, -1], [1, -1]]),
        efc__force=jnp.array([[50.0, 7.0], [60.0, 8.0]]),
        nacon=jnp.array([3]),
        contact__geom=jnp.array([[0, 1], [0, 2], [3, 0], [0, 2]]),
    )
    sim = SimpleNamespace(
        N=2,
        floor_id=0,
        foot_side=np.array([-1, 0, -1, 1]),
        m=SimpleNamespace(opt=SimpleNamespace(gravity=[0.0, 0.0, -10.0])),
    )
    state = SimpleNamespace(
        data=SimpleNamespace(_impl=contacts), world=SimpleNamespace(body_mass=jnp.array([[4.0, 6.0], [3.0, 7.0]]))
    )
    np.testing.assert_allclose(measured_floor_loads(sim, state), [[0.5, 0.0, 0.07], [0.0, 0.6, 0.0]], atol=1e-7)


class Data(NamedTuple):
    qpos: object
    qvel: object


class State(NamedTuple):
    data: Data
    obs: object
    assist: object
    c_obs: object
    motion_train_sensors: object = None


class Transition(NamedTuple):
    qpos1: object
    qvel1: object
    reward: object
    terminated: object
    truncated: object
    stats: object


def test_moving_commands_preserve_sampling_ratio_and_skipped_feedback_gradient():
    tr, opt, disc = learner("fixed.npz", 6.0, False)
    n = 4
    tr.c.rollout = 2
    tr.c.assist_curriculum = False
    tr.extra_rollout_stats = ()
    tr.amp_stride = 1
    tr.actor_input = lambda s: s.obs
    tr.critic_input = lambda s: s.obs[:, :6]
    tr.rollout_motion = lambda disc, motion, transition: (jnp.zeros(n), motion, ())
    tr.motion_features = lambda a: a
    tr.online_ground_targets = lambda state: (jnp.full((n, 23), 0.8), jnp.ones(n, jnp.int32))

    def step(s, a):
        nexts = s._replace(obs=s.obs.at[:, :23].add(0.01 * a))
        return nexts, Transition(
            s.data.qpos,
            s.data.qvel,
            a.mean(-1),
            jnp.zeros(n, bool),
            jnp.zeros(n, bool),
            dict(down_done=0.0, down_up=0.0, diverged=0.0),
        )

    tr.sim = SimpleNamespace(step=step, amp_frame=lambda s: s[0])
    obs = jax.random.normal(jax.random.key(32), (n, 234))
    q = jnp.zeros((n, 30)).at[:, 3].set(1.0)
    state = State(Data(q, jnp.zeros((n, 29))), obs, jnp.zeros(n), jnp.ones((n, 3)))
    live = (state, jnp.zeros((n, 10, 3)), jnp.zeros((4, n, 10, 3)), jnp.int32(0))
    key = jax.random.key(71)
    base, b1, s1 = tr.collect(live, opt[0], disc, key, opt[3])
    tr.c.online_ground_bank = "feedback.npz"
    guided, b2, s2 = tr.collect(live, opt[0], disc, key, opt[3], ppo_iteration=jnp.int32(1))
    assert_tree_equal(base, guided)
    assert_tree_equal(b1, b2[:7])
    assert_tree_equal(s1, s2[:-3])
    x, _, mu, a = b2[:4]
    old = tr.actor_mean(opt[0]["pi"], normalized_input(opt[3]["actor"], x))
    std = tr.action_std(opt[0])
    np.testing.assert_array_equal(mu, old)
    np.testing.assert_array_equal(jnp.exp((0.5 * ((a - mu) ** 2 - (a - old) ** 2) / std**2).sum(-1)), 1.0)
    replay = jnp.ones((2, n, 2, 3))
    dkey = jax.random.key(21)

    def update(on, b):
        tr.c.online_ground_bank = "bank" if on else ""
        return tr.learn(opt, disc, b, replay, jnp.int32(2), dkey, ppo_iteration=jnp.int32(1))

    fixed = update(False, b1)
    skipped = update(True, (*b1, b2[-4], jnp.zeros_like(b2[-3]), *b2[-2:]))
    assert_tree_equal(fixed, skipped)
    new = update(True, b2)
    assert not np.array_equal(new[0][0]["pi"][-1]["b"], fixed[0][0]["pi"][-1]["b"])
    assert_tree_equal(new[1], fixed[1])
    np.testing.assert_array_equal(new[0][0]["std"], fixed[0][0]["std"])


def test_bad_reference_fails_before_the_policy_can_sample(tmp_path):
    import hashlib
    import pytest
    from instantamp.zenbot_online_ground import load_bank

    folder = tmp_path / "floor"
    folder.mkdir()
    clip = folder / "raw.npz"
    clip.write_bytes(b"local raw clip")
    b = fake_bank()
    items = {key: np.asarray(value) for key, value in b._asdict().items()}
    for k in ("q", "v", "raw", "gain", "lengths", "settled", "delay_groups", "opening_hold"):
        items[k] = items[k][:1]
    items["clip_names"] = [clip.name]
    items["source_sha256"] = [hashlib.sha256(clip.read_bytes()).hexdigest()]
    archive = tmp_path / "feedback.npz"
    np.savez(archive, **items)
    assert load_bank(archive, folder).raw.shape[0] == 1
    clip.write_bytes(b"other source")
    with pytest.raises(ValueError, match="source floor clip"):
        load_bank(archive, folder)
    with pytest.raises(FileNotFoundError):
        load_bank(tmp_path / "missing.npz", folder)
    clip.rename(folder / "different_name.npz")
    with pytest.raises(ValueError, match="ordered floor clips"):
        load_bank(archive, folder)


def test_floor_keeps_its_own_standing_feedback_even_at_the_default_joint_pose():
    bank = fake_bank()
    q=bank.q.at[:,:,2].set(.68).at[:,:,7:].set(z.DEFAULT_Q)
    bank=bank._replace(q=q)
    c=jnp.array([0,-1]); step=jnp.array([12,12]); index=jnp.maximum(c,0)
    pose=q[index,step].at[:,:2].add(-q[index,0,:2])
    a,kind,_=labels(bank,pose,jnp.zeros((2,29)),jnp.zeros((2,23)),jnp.zeros((2,23)),
                    c,jnp.zeros(2,int),step,jnp.zeros((2,3)),jnp.ones(2,bool),
                    jnp.broadcast_to(jnp.array([.5,.5,0.]),(2,3)))
    np.testing.assert_array_equal(kind,[1,2])
    assert np.any(np.asarray(a[0]) != np.asarray(a[1]))


def test_packing_rejects_a_truncated_feedback_cache(tmp_path):
    import hashlib
    import json
    import pytest
    from tools.prepare_zenbot_online_ground import pack

    plans = tmp_path / "plans"
    gains = tmp_path / "gains"
    floor = tmp_path / "floor"
    for directory in (plans, gains, floor):
        directory.mkdir()
    clip = floor / "raw.npz"
    clip.write_bytes(b"raw")
    trace = plans / "plan.npz"
    np.savez(
        trace,
        seed=42,
        source_clip=clip.name,
        source_frame=0,
        release_first_rise_held=True,
        hand_to_feet=True,
        external_assist_newtons=0.0,
        raw_action=np.zeros((600, 23), np.float32),
    )
    digest = hashlib.sha256(trace.read_bytes()).hexdigest()
    (plans / "manifest.json").write_text(
        json.dumps({"trajectories": {"p": {"filename": trace.name, "sha256": digest}}})
    )
    np.save(gains / (digest[:16] + ".npy"), np.zeros((180, 23, 104), np.float32))
    with pytest.raises(ValueError, match="full-trajectory"):
        pack(plans, gains, floor, tmp_path / "output.npz")


def test_delay_corrected_reference_and_two_previous_requests_against_native_group_units():
    from instantamp.zenbot_online_ground import aligned_reference_actions

    b = fake_bank()
    clip = np.arange(4)
    phase = np.array([0, 1, 7, 29])
    actual = np.array([[7, 6, 5, 4, 3], [3, 4, 5, 6, 7], [5, 6, 4, 7, 5], [6, 7, 3, 4, 5]])
    current, previous, older = aligned_reference_actions(b, clip, phase, actual)
    for offset, result in enumerate((current, previous, older)):
        truth = np.zeros((4, 23))
        for row in range(4):
            t = phase[row] - offset
            if t < 0:
                continue
            for joint, group in enumerate(z.GROUP):
                difference = (actual[row, group] - int(b.delay_groups[row, group])) / 4.0
                next_t = int(np.clip(t + np.sign(difference), -1, int(b.lengths[row]) - 1))
                second = b.raw[row, next_t, joint] if next_t >= 0 else 0.0
                truth[row, joint] = b.raw[row, t, joint] + abs(difference) * (second - b.raw[row, t, joint])
        np.testing.assert_allclose(result, truth, atol=2e-7)

    # No elapsed delay difference reproduces the original source/local-K equations exactly.
    q = np.asarray(b.q)[clip, phase].copy()
    q[:, :2] -= np.asarray(b.q)[:, 0, :2]
    v = np.asarray(b.v)[clip, phase]
    zero = np.zeros((4, 23), np.float32)
    args = (
        b,
        q,
        v,
        zero,
        zero,
        clip,
        np.zeros(4, int),
        phase,
        np.zeros((4, 3)),
        np.zeros(4, bool),
        np.zeros((4, 3)),
    )
    np.testing.assert_array_equal(labels(*args)[0], labels(*args, b.delay_groups)[0])


def test_nonzero_source_phase_skips_physical_opening_hold():
    b = fake_bank()._replace(opening_hold=jnp.array([0, 4, 8, 2], dtype=jnp.int32))
    clip = np.arange(4)
    raw_start = np.array([0, 5, 5, 0])
    actual_start = raw_start + np.where(raw_start > 0, np.asarray(b.opening_hold), 0)
    elapsed = np.array([2, 3, 4, 5])
    t = actual_start + elapsed
    q = np.asarray(b.q)[clip, t].copy()
    q[:, :2] -= np.asarray(b.q)[clip, actual_start, :2]
    v = np.asarray(b.v)[clip, t]
    z23 = np.zeros((4, 23))
    target, kind, phase = labels(
        b,
        q,
        v,
        z23,
        z23,
        clip,
        raw_start,
        elapsed,
        np.zeros((4, 3)),
        np.zeros(4, bool),
        np.zeros((4, 3)),
        b.delay_groups,
    )
    np.testing.assert_array_equal(phase, t)
    np.testing.assert_array_equal(kind, 1)
