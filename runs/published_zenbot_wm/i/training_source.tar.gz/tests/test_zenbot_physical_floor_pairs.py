import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp.zenbot_motion_train_obs import TERM_HISTORY_INDEX
from instantamp.zenbot_online_ground import labels
from tools import prepare_zenbot_physical_training as pairs
from tools.prepare_zenbot_scratch_pairs import NativeWorld
from test_zenbot_online_ground import fake_bank


def test_heading_translation_invariance_and_native_perturbed_motor_targets():
    rng = np.random.default_rng(70311)
    world, bank = NativeWorld(), fake_bank()
    reference = Rotation.from_euler("xyz", [[1.5, .1, .7], [-1.48, -.2, -.4], [.25, 1.31, -.7], [.08, .18, .23]])
    bank = bank._replace(q=bank.q.at[:, :, 3:7].set(reference.as_quat(scalar_first=True)[:, None]))
    clip, phase, start = np.arange(4), np.array([0,9,14,20]), np.array([0,7,0,5])
    age = phase-start
    q = np.asarray(bank.q)[clip,phase].copy()
    v = np.asarray(bank.v)[clip,phase].copy()+rng.uniform(-.16,.16,(4,29))
    q[:,7:] += rng.uniform(-.04,.04,(4,23))
    rotation = reference*Rotation.from_rotvec(rng.uniform(-.11,.11,(4,3)))
    q[:,3:7] = rotation.as_quat(scalar_first=True)
    q[:,:2] += rng.uniform(-.18,.18,(4,2))
    last, older = rng.uniform(-.8,.8,(2,4,23)).astype(np.float32)
    lag = rng.integers(3,8,(4,5))
    actual, kind, frame = pairs.floor_targets(bank,clip,q,v,last,older,start,age,lag)
    np.testing.assert_array_equal(kind,1)
    lag[0]=5
    for i,k in enumerate(np.asarray(frame)):
        ref_q,ref_v = np.array(bank.q[i,k]),np.array(bank.v[i,k])
        relative = rotation[i]*reference[i].inv()
        w,_,_,z = relative.as_quat(scalar_first=True)
        half = np.arctan2(z if w>=0 else -z, abs(w))
        to_plan = Rotation.from_rotvec([0,0,-2*half])
        aligned_q,aligned_v = q[i].copy(),v[i].copy()
        aligned_q[:2]=ref_q[:2]
        aligned_q[3:7]=(to_plan*rotation[i]).as_quat(scalar_first=True)
        aligned_v[:3]=to_plan.apply(aligned_v[:3])
        tangent=np.empty(29)
        mujoco.mj_differentiatePos(world.model,tangent,1.,ref_q,aligned_q)
        actions=pairs.shifted_actions(np.asarray(bank.raw[i]),np.asarray(bank.delay_groups[i]),lag[i])
        raw=np.vstack((np.zeros((2,23)),actions))
        dx=np.r_[tangent,aligned_v-ref_v,.25*(last[i]-raw[k+1]),.25*(older[i]-raw[k])]
        native=raw[k+2]+np.clip(np.asarray(bank.gain[i,k])@dx,-.65,.65)/.25
        np.testing.assert_allclose(actual[i],native,atol=2e-6)
    heading=Rotation.from_euler("z",np.array([1.7,-.8,.9,-1.9])[:,None])
    changed_q,changed_v=q.copy(),v.copy()
    changed_q[:,3:7]=(heading*rotation).as_quat(scalar_first=True)
    changed_q[:,:2]+=rng.uniform(-1.,1.,(4,2))
    changed_v[:,:3]=heading.apply(v[:,:3])
    changed=labels(bank,changed_q,changed_v,last,older,clip,start,age,np.zeros((4,3)),np.zeros(4,bool),
                   np.tile([.3,.4,.1],(4,1)),lag,physical_reset_phase=True)
    np.testing.assert_allclose(changed[0],actual,atol=2e-6)
    np.testing.assert_array_equal(changed[1],kind)
    np.testing.assert_array_equal(changed[2],frame)


def test_all_reset_phases_have_diverse_delays_perturbations_and_action_noise():
    nominal=np.array([4,5,6,7,3])
    for count in (32,144):
        delay,amount,noise=pairs.floor_randomization(count,nominal,np.random.default_rng(42))
        for phase in range(4):
            group=np.arange(phase,count,4)
            for mask in ((delay[group]==nominal).all(axis=1),amount[group]==0.,noise[group,0]==0.):
                assert mask.any() and not mask.all()
            assert ((delay[group]>=3)&(delay[group]<=7)).all()
        assert not np.array_equal((delay==nominal).all(axis=1),amount==0.)
        assert not np.array_equal(amount==0.,noise[:,0]==0.)


def test_real_cold_history_and_offline_online_equivalence_on_mujoco_states(monkeypatch):
    world=NativeWorld()
    bank=fake_bank()._replace(settled=jnp.full(4,13))
    captured=[]
    direct=pairs.floor_targets

    def capture(bank,clip,q,v,prev,older,start,elapsed,delays):
        outcome=direct(bank,clip,q,v,prev,older,start,elapsed,delays)
        lag=np.where(((start==0)&(elapsed<3))[:,None],5,delays)
        online=labels(bank,q,v,prev,older,clip,start,elapsed,np.zeros((len(q),3)),np.zeros(len(q),bool),
                      np.zeros((len(q),3)),lag,physical_reset_phase=True)
        np.testing.assert_allclose(online[0],outcome[0],atol=1e-6)
        np.testing.assert_array_equal(online[1],outcome[1])
        captured.append((np.asarray(online[0]),np.asarray(online[1]),np.where((start==0)&(elapsed<3),elapsed,-1)))
        return outcome

    monkeypatch.setattr(pairs,"floor_targets",capture)
    obs,target,opening_tick=pairs.floor_episodes(world,bank,0,701,16,5)
    frames=obs[:,np.argsort(TERM_HISTORY_INDEX)].reshape(-1,3,78)
    cold=opening_tick==0
    assert np.count_nonzero(cold)==4
    np.testing.assert_array_equal(frames[cold,0],frames[cold,1])
    np.testing.assert_array_equal(frames[cold,0],frames[cold,2])
    np.testing.assert_array_equal(frames[cold,:,55:],0.)
    np.testing.assert_array_equal(np.unique(opening_tick),[-1,0,1,2])
    active=np.ones(16,bool)
    actions,ticks=[],[]
    for y,kind,opening in captured:
        active &= kind==1
        actions.extend(y[active])
        ticks.extend(opening[active])
    np.testing.assert_allclose(target,actions,rtol=0.,atol=1e-6)
    np.testing.assert_array_equal(opening_tick,ticks)
