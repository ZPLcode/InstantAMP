import io
import json
from zipfile import ZipFile

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import zenbot
from instantamp.sim import Sim
from instantamp.zenbot_motion_train_obs import LAB_ORDER
from instantamp.zenbot_online_ground import behavior_gaussian, rollout_control
from instantamp.zenbot_physical_gait_starts import PhysicalGaitStarts
from test_zenbot_source_gait import CPUData


@pytest.fixture(scope="module")
def initialized():
    base = "data/zenbot23_walk_run_recovery"
    sim = Sim(96, physics=False, robot="zenbot23_getup", floor_dir=base+"/recovery", walk_dir=base+"/walk_run",
              zenbot_getup_stand=True, zenbot_support_weight=8., zenbot_standing_amp=True, zenbot_command_gait=True,
              zenbot_directional_gait=True, zenbot_motion_train_obs=True, zenbot_scratch_resets=True,
              zenbot_scratch_curriculum=True, zenbot_source_gait=True, reset_floor=.25,
              obs_noise=False, assist_newtons=0., random_start=False)
    bank = sim.physical_gait_starts = PhysicalGaitStarts(sim)
    sim.dx = CPUData(jnp.zeros(30), jnp.zeros(29), jnp.zeros(29))
    s = jax.jit(sim.init)(jax.random.key(319))
    return sim, bank, s


def test_reset_restores_measured_state_delays_commands_and_only_prior_actions(initialized):
    sim, bank, s = initialized
    start, end = np.asarray(s.gait_window).T
    selected = np.flatnonzero(start >= 0)
    gait = np.asarray(s.reference_clip) < 0
    assert (end[selected] - start[selected] >= 20).all()
    assert gait.sum() == 72 and 8 <= len(selected) <= 29 and gait[selected].all()
    np.testing.assert_array_equal(s.motion_train_sensors.observation().shape, [sim.N, 234])
    np.testing.assert_array_equal(s.c_obs[~gait], 0.)
    ordinary = gait & (start < 0)
    np.testing.assert_allclose(s.data.qpos[ordinary, 2], .69)
    np.testing.assert_array_equal(s.a_last[start < 0], 0.)

    base = bank.default_directory
    rows = json.loads((base / "manifest.json").read_text())["windows"]
    target, active = jax.jit(bank.target)(s)
    np.testing.assert_array_equal(active, start >= 0)
    applied = (sim.control_targets(target, s.world.bias, s.obs, sim.context(s)).reshape(-1,4,23)
               - zenbot.DEFAULT_Q) / zenbot.ACTION_SCALE
    with ZipFile(base / "windows.zip") as arc:
        for i in selected:
            idx = np.flatnonzero(np.asarray(bank.ends) == end[i]).item()
            frame = start[i] - int(bank.starts[idx])
            with np.load(io.BytesIO(arc.read(rows[idx]["file"]))) as w:
                np.testing.assert_allclose(s.data.qpos[i], w["qpos"][frame], atol=2e-6)
                np.testing.assert_allclose(s.data.qvel[i], w["qvel"][frame], atol=2e-6)
                np.testing.assert_array_equal(s.c_obs[i], w["command"])
                np.testing.assert_array_equal(s.delay_steps[i], w["delays"])
                np.testing.assert_allclose(target[i], w["raw_action"][frame], atol=2e-6)
                actual = np.concatenate((w["prefix_raw_frames"], w["raw_frames"]))[frame+2:frame+5]
                np.testing.assert_allclose(s.motion_train_sensors.frames[i], actual, atol=3e-6)
                np.testing.assert_allclose(s.motion_train_sensors.observation()[i,165:].reshape(3,23),
                                           actual[:,55:][:,LAB_ORDER], atol=2e-6)
                history = np.concatenate((w["initial_prev_raw"], w["raw_action"]))[frame:frame+2]
                np.testing.assert_allclose(s.a_last[i], history[-1], atol=2e-6)
                age = np.arange(4)[:,None] - w["delays"][zenbot.GROUP][None]
                expect = np.where(age >= 0, w["raw_action"][frame], np.where(age >= -4, history[-1], history[-2]))
                np.testing.assert_allclose(applied[i], expect, atol=3e-6)


def test_last_action_hands_off_to_actor_with_no_reset_or_change_of_command(initialized, monkeypatch):
    sim, bank, s = initialized
    n = sim.N
    def frozen_physics(world, data, target, assist, fresh):
        return (data, jnp.ones((n,2)), jnp.zeros(n), jnp.zeros(n,bool),
                jnp.tile(jnp.array([225.,225.,0.,0.,0.,0.]), (n,1)), None)
    monkeypatch.setattr(sim, "physics", frozen_physics)
    start, end = s.gait_window.T
    warm = np.asarray(start >= 0)
    s = s._replace(t=jnp.where(start >= 0, end-start-1, 0))
    target, before = bank.target(s)
    np.testing.assert_array_equal(before, warm)
    nxt, tr = jax.jit(sim.step)(s, target)
    np.testing.assert_array_equal(tr.terminated[warm] | tr.truncated[warm], False)
    np.testing.assert_array_equal(nxt.t[warm], (end-start)[warm])
    np.testing.assert_array_equal(nxt.c_obs[warm], s.c_obs[warm])
    np.testing.assert_array_equal(nxt.data.qpos[warm], s.data.qpos[warm])
    np.testing.assert_array_equal(nxt.a_last[warm], target[warm])
    np.testing.assert_array_equal(bank.target(nxt)[1], False)
    np.testing.assert_array_equal(nxt.gait_curriculum.partial[warm], 0.)
    np.testing.assert_array_equal(bank.target(s._replace(c_obs=jnp.zeros_like(s.c_obs)))[1], False)
    no_reset = jax.jit(sim._reset)(s, jnp.zeros(n, bool), jax.random.key(443))
    np.testing.assert_array_equal(no_reset.gait_window, s.gait_window)
    np.testing.assert_array_equal(no_reset.delay_steps, s.delay_steps)
    np.testing.assert_array_equal(no_reset.data.qpos, s.data.qpos)


def test_gait_action_mix_and_behavior_likelihood_vanish_on_schedule():
    kind = jnp.array([1,2,3,3,0])
    cmd = jnp.array([[0.,0.,0.], [0.,0.,0.], [0.,0.,-.6], [0.,0.,0.], [-.5,0.,0.]])
    actor = jnp.arange(5*23).reshape(5,23) * .01
    target = actor + .73
    for iteration in (1, 1249, 2500, 10000):
        w, noise = jax.jit(rollout_control)(kind, cmd, iteration)
        gain = np.clip((2500-iteration)/2499., 0., 1.)
        np.testing.assert_allclose(w, gain*np.array([.98,.98,.5,0,0]), atol=2e-7)
        mean, std = behavior_gaussian(actor, .5, target, w, noise)
        act = mean+std*jax.random.normal(jax.random.key(34), mean.shape)
        repeat, std2 = behavior_gaussian(actor, .5, target, w, noise)
        ratio = jnp.exp((jnp.log(std/std2)+.5*(((act-mean)/std)**2-((act-repeat)/std2)**2)).sum(-1))
        np.testing.assert_array_equal(ratio,1.)
        np.testing.assert_array_equal(std[2],.5)
        if iteration >= 2500:
            np.testing.assert_array_equal(mean, actor)


def test_only_live_matched_windows_replace_the_existing_labels(initialized, monkeypatch):
    from instantamp import zenbot_online_ground
    from instantamp.train_zenbot_scratch import ScratchAMP

    sim, bank, s = initialized
    trainer = ScratchAMP.__new__(ScratchAMP)
    trainer.online_bank, trainer.sim = None, sim
    start, end = s.gait_window.T
    ordinary_label = jnp.where(s.reference_clip >= 0, 1, 0)
    old = jnp.zeros((sim.N, 23))
    monkeypatch.setattr(zenbot_online_ground, "measured_floor_loads", lambda *a: jnp.zeros((sim.N,3)))
    monkeypatch.setattr(zenbot_online_ground, "labels", lambda *a, **kw: (old, ordinary_label, None))
    current, kind = jax.jit(trainer.online_ground_targets)(s)
    target, use = bank.target(s)
    np.testing.assert_array_equal(kind, jnp.where(use, 3, ordinary_label))
    np.testing.assert_array_equal(current, jnp.where(use[:,None], target, old))
    past = s._replace(t=jnp.where(start >= 0, end-start, s.t))
    expired, kind = jax.jit(trainer.online_ground_targets)(past)
    np.testing.assert_array_equal(expired, old)
    np.testing.assert_array_equal(kind, ordinary_label)
