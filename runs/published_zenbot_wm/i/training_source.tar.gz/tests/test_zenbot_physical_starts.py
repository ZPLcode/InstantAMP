from types import SimpleNamespace
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import zenbot
from instantamp.sim import Sim
from instantamp.zenbot_motion_train_obs import LAB_ORDER
from instantamp.zenbot_physical_starts import PhysicalFloorStarts


class Data(NamedTuple):
    qpos: object
    qvel: object
    qacc_warmstart: object

    def replace(self, **kw):
        return self._replace(**kw)


def test_physical_phase_restores_observation_and_both_real_motor_requests_without_affecting_cold_starts():
    base = "data/zenbot23_walk_run_recovery"
    sim = Sim(48, physics=False, robot="zenbot23_getup", floor_dir=base+"/recovery", walk_dir=base+"/walk_run",
              zenbot_getup_stand=True, zenbot_support_weight=8., zenbot_standing_amp=True, zenbot_command_gait=True,
              zenbot_directional_gait=True, zenbot_motion_train_obs=True, zenbot_scratch_resets=True,
              zenbot_scratch_curriculum=True, zenbot_phase_resets=.6, reset_floor=.6, obs_noise=False, assist_newtons=0.)
    old = sim.floor
    clips, steps = len(old['lengths']), 20
    index = old["offsets"][:, None] + jnp.arange(steps)[None]
    q = jnp.concatenate((jnp.zeros((clips,steps,2)), old["z"][index,None] + zenbot.RESET_LIFT,
                         old["quat"][index], old["q"][index]), -1)
    v = jnp.broadcast_to(jnp.linspace(-.3,.3,29), (clips,steps,29))
    raw = jnp.arange(steps)[None, :, None] * .02 + jnp.arange(23)[None,None,:] / 50 + jnp.zeros((clips,1,1))
    bank = SimpleNamespace(q=q, v=v, raw=raw, lengths=jnp.full((clips,),steps), settled=jnp.full((clips,),12))
    sim.physical_floor_starts = PhysicalFloorStarts(sim, bank)
    sim.dx = Data(jnp.zeros(30), jnp.zeros(29), jnp.zeros(29))
    s = sim.init(jax.random.key(987))
    phase, clip = map(np.asarray,(s.reference_start,s.reference_clip))
    warm = (phase>0) & (clip>=0)
    assert warm.sum()>5 and ((clip>=0)&(phase==0)).sum()>2 and (clip<0).sum()>3
    expected = np.zeros((sim.N,3,23))
    for i in np.flatnonzero(warm):
        for j in range(3):
            k=phase[i]+j-3
            if k>=0: expected[i,j]=raw[clip[i],k]
    np.testing.assert_allclose(s.motion_train_sensors.frames[:,:,55:],expected)
    np.testing.assert_allclose(s.motion_train_sensors.observation()[:,165:].reshape(-1,3,23),expected[:,:,LAB_ORDER])
    np.testing.assert_allclose(s.a_last,expected[:,-1])
    np.testing.assert_allclose(s.obs.reshape(sim.N,5,sim.frame_dim)[:,-3:,55:78],expected)
    action=jnp.full((sim.N,23),-.8)
    applied=(sim.control_targets(action,s.world.bias,s.obs,sim.context(s)).reshape(-1,4,23)-zenbot.DEFAULT_Q)/.25
    delay=np.asarray(s.delay_steps)[:,zenbot.GROUP]
    age=np.arange(4)[None,:,None]-delay[:,None,:]
    want=np.where(age>=0,-.8,np.where(age>=-4,expected[:,-1:, :],expected[:,-2:-1,:]))
    np.testing.assert_allclose(applied,want,atol=5e-7)
    np.testing.assert_array_equal(sim.floor['z'][sim.floor['offsets']],old['z'][old['offsets']])
    ids = np.arange(sim.N)
    nominal = (ids < round(sim.reset_floor * sim.N)) & (ids % 4 != 3)
    np.testing.assert_allclose(np.asarray(s.world.geom_friction)[nominal], np.broadcast_to(
        sim.m.geom_friction, (nominal.sum(), *sim.m.geom_friction.shape)))
    assert not np.allclose(np.asarray(s.world.geom_friction)[~nominal], sim.m.geom_friction)
    fresh=jnp.zeros(sim.N,bool)
    s2=sim.physical_floor_starts.restore(sim,s,fresh,jax.random.key(655))
    np.testing.assert_array_equal(s2.motion_train_sensors.frames,s.motion_train_sensors.frames)


    # Only immediate physical RSI worlds restore delivered requests into their true actor and motor history.
    from instantamp.zenbot_immediate_ground import delivered_prefix
    bank.delay_groups = jnp.array([[3, 4, 5, 6, 7]] * clips)
    sim.physical_floor_starts.immediate_ground_bank = bank
    immediate = (np.arange(sim.N) % 2) == 0
    mixed = s._replace(delay_steps=jnp.where(immediate[:, None], 0, s.delay_steps))
    restored = sim.physical_floor_starts.restore(sim, mixed, jnp.ones(sim.N, bool), jax.random.key(655))
    use = immediate & warm
    assert use.any() and (warm & ~immediate).any()
    delivered = np.asarray(delivered_prefix(bank, mixed.reference_clip, mixed.reference_start))
    np.testing.assert_array_equal(restored.motion_train_sensors.frames[~use], s.motion_train_sensors.frames[~use])
    np.testing.assert_allclose(restored.motion_train_sensors.frames[use, :, 55:], delivered[use, -3:], atol=1e-7)
    np.testing.assert_allclose(restored.a_last[use], delivered[use, -1], atol=1e-7)
    np.testing.assert_array_equal(restored.a_last[~use], s.a_last[~use])


def test_mixed_behavior_gaussian_has_exact_ratio_at_old_actor_and_pure_mean_after_fade():
    from instantamp.zenbot_online_ground import behavior_gaussian, rollout_control

    key=jax.random.key(101)
    mu=jax.random.normal(key,(3,23)); target=mu+1.
    base=jnp.full(23,.5)
    cmd=jnp.array([[0.,0.,0.],[0.,0.,0.],[1.,0.,0.]])
    for it in (1,1000,2500,10000):
        w,scale=rollout_control(jnp.array([1,2,0]),cmd,it)
        prior,std=behavior_gaussian(mu,base,target,w,scale)
        action=prior+std*jax.random.normal(jax.random.fold_in(key,it),prior.shape)
        new,std2=behavior_gaussian(mu,base,target,w,scale)
        ratio=jnp.exp((jnp.log(std/std2)+.5*(((action-prior)/std)**2-((action-new)/std2)**2)).sum(-1))
        np.testing.assert_array_equal(ratio,1.)
        np.testing.assert_allclose(std[:2],.12)
        np.testing.assert_allclose(std[2],.50)
        np.testing.assert_array_equal(prior[2],mu[2])
        if it>=2500:
            np.testing.assert_array_equal(w,0.)
            np.testing.assert_array_equal(prior,mu)
        else:
            assert 0.<float(w[0])<1.
