"""Exercise the source motor fit used before the next PPO rollout."""

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import optim
from instantamp.train_g1_getup_amp import normalized_input
from test_zenbot_scratch_reference_guide import learner


def test_cold_and_changing_targets_share_the_existing_ground_half():
    trainer, _, _ = learner("synthetic", 1.0)
    trainer.opening_rows = jnp.array([0, 1])
    trainer.changing_rows = jnp.array([5, 6])
    sample = np.asarray(trainer.sample_reference_rows(jax.random.key(88), 256))
    assert np.isin(sample[:16], [0, 1]).all()
    assert np.isin(sample[16:72], [5, 6]).all()
    assert (sample[72:128] < 28).all()
    np.testing.assert_array_equal(np.bincount(sample[128:] // 28, minlength=9), [0] + [16] * 8)


def test_physical_gradient_moves_the_same_actor_toward_source_targets():
    trainer, (ac, _, _, norms), _ = learner("synthetic", 1.0)
    trainer.c.reference_fit_steps = 4
    mask = jax.tree.map(lambda _: False, ac["pi"])
    source = normalized_input(norms["actor"], trainer.guide_obs[:8])

    def error(actor):
        return np.abs(np.asarray(trainer.actor_mean(actor, source)) - 2.0).mean()

    before = error(ac["pi"])
    pi, state = jax.jit(trainer.fit_reference)(
        ac["pi"], optim.init(ac["pi"], mask), norms["actor"], jax.random.key(71)
    )
    assert error(pi) < before
    assert int(state["t"]) == 4
