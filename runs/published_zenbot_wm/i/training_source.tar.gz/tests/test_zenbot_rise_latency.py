import numpy as np

from tools.evaluate_zenbot_rise_latency import summarize
from tools.score_zenbot_sequence import ground_timing


def test_moving_on_the_floor_is_distinct_from_a_quiet_pause():
    q = np.zeros((101, 30))
    v = np.zeros((101, 29))
    q[:, 2] = .25
    q[25:, 7:] = .25
    v[25:, 6:] = 1.
    q[50:, 2] = .40
    timing = ground_timing(q, v, rise=90)
    assert timing == dict(first_joint_motion_s=.50, first_pelvis_lift_s=1., longest_quiet_ground_s=.50)


def test_timeout_counts_against_both_capped_time_and_reference_deadline():
    row = dict(reference_rise_s=2., rise=2.5, held=True, refall=False, pre_rise_attempts={"retries": 0},
               ground_timing=dict(first_pelvis_lift_s=.5, longest_quiet_ground_s=.20))
    stuck = dict(row, rise=None, held=False, ground_timing=dict(first_pelvis_lift_s=None, longest_quiet_ground_s=12.))
    summary = summarize([row, stuck], 12.)
    assert summary["rise_restricted_mean_s"] == 7.25
    assert summary["rose_by_ref_plus_1_5s"] == summary["held_first_attempt"] == summary["rose"] == 1
    assert summary["longest_quiet_ground_max_s"] == 12.
