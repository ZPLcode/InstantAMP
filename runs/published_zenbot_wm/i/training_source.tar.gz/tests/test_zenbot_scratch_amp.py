from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import amp, zenbot
from instantamp.train_zenbot_scratch import CommandWindows, ScratchAMP, ScratchSettings
from instantamp.zenbot_gait_demos import DIRECTION_CLIPS, STRAIGHT_CLIPS, gait_command_index


def test_every_command_gets_contiguous_reference_frames_from_its_own_clip():
    # Encode a clip's label in the first channel and the frame within that clip in the second.
    def bank(labels, names=()):
        frames = [np.stack((np.full(31, label), np.arange(31)), axis=-1) for label in labels]
        result = SimpleNamespace(frames=jnp.asarray(np.concatenate(frames)),
                                 starts=jnp.asarray([31 * k + i for k in range(len(labels)) for i in range(4)]),
                                 clip_probabilities=None)
        if names:
            result.clip_counts = np.full(len(labels), 4)
            result.clip_names = names
        else:
            result.clip_lengths = np.full(len(labels), 4)
        return result

    names = [STRAIGHT_CLIPS["walk"][0], *DIRECTION_CLIPS]
    windows = CommandWindows(bank([0, 0]), bank([1]), bank([1 + gait_command_index(n) for n in names], names),
                             bank([3], [STRAIGHT_CLIPS["run"][0]]))
    labels = np.tile(np.arange(9), 10)
    samples = np.asarray(windows.sample(jax.random.key(42), labels, 3))
    np.testing.assert_array_equal(samples[..., 0], np.broadcast_to(labels[:, None], samples.shape[:2]))
    assert np.all(np.diff(samples[..., 1], axis=1) == 3)


def test_gait_fall_retains_its_command_and_earns_zero_style(monkeypatch):
    learner = ScratchAMP.__new__(ScratchAMP)
    learner.condition_dim = 9
    learner.c = ScratchSettings()
    learner.standing_target = jnp.zeros(90)
    monkeypatch.setattr(amp, "recovery_style", lambda _, replay, **kw: jnp.ones(len(replay)))
    stats = dict(gait_command=jnp.asarray(zenbot.DIRECTIONAL_COMMANDS[[0, 6, 6]]),
                 gait_ready=jnp.array([False, True, False]), stand_blend=jnp.zeros(3),
                 gait_velocity_error=jnp.zeros((3, 3)), min_foot_load_bw=jnp.zeros(3))
    tr = SimpleNamespace(stats=stats, terminated=jnp.array([False, False, True]))
    rewards, replay, _ = learner.rollout_motion({}, jnp.zeros((3, 10, 90)), tr)
    np.testing.assert_array_equal(replay[:, -1, -9:].argmax(axis=-1), [0, 7, 7])
    assert rewards[0] > 0 and rewards[1] > rewards[0] and rewards[2] == 0
