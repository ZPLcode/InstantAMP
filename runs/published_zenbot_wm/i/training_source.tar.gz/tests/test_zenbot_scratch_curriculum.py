from typing import NamedTuple
from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import zenbot
from instantamp.train_zenbot_getup_stand_amp import RiseStandAMP
from instantamp.train_zenbot_scratch import ScratchAMP


def test_ppo_iteration_controls_force_for_floor_worlds_only(monkeypatch):
    class WorldState(NamedTuple):
        reference_clip: object
        t: object
        assist: object

    monkeypatch.setattr(RiseStandAMP, "collect", lambda self, live, *args: live[0].assist)
    trainer = object.__new__(ScratchAMP)
    trainer.c = SimpleNamespace(assist_curriculum=True)
    state = WorldState(jnp.array([0, 1, -1]), jnp.array([20, 400, 150]), jnp.zeros(3))
    collect = jax.jit(lambda it: trainer.collect((state,), None, None, None, ppo_iteration=it))
    for it, fraction in ((1, 1.), (1500, 1500/2999), (3000, 0.), (10000, 0.)):
        expected = zenbot.INITIAL_ASSIST * fraction
        np.testing.assert_allclose(collect(it), [expected, expected, 0.], atol=2e-5)
    with pytest.raises(ValueError, match="PPO iteration"):
        trainer.collect((state,), None, None, None)


def test_contact_and_height_gate_even_at_full_force():
    loads = jnp.zeros((7, 6)).at[[0, 1, 2, 3, 4, 6], 4].set(2.)
    z = jnp.array([.2, .48, .58, .68, .70, .2, .2])
    fresh = jnp.array([False] * 6 + [True])
    cap = jnp.full(7, zenbot.INITIAL_ASSIST)
    expected = np.array([1., 1., .5, 0., 0., 0., 0.]) * zenbot.INITIAL_ASSIST
    np.testing.assert_allclose(zenbot.supported_lift(cap, z, loads, fresh, 0), expected, atol=2e-4)
    assert np.isclose(zenbot.supported_lift(cap, z, loads, fresh, 1)[-1], zenbot.INITIAL_ASSIST)


def test_late_sustained_stand_continues_for_ten_seconds_and_floor_miss_terminates():
    # A 101-frame reference, reset at frame 20: the final frame is 80 steps away.
    # Worlds 0/1 recover early or exactly at the deadline, world 2 misses, world 3 starts in gait.
    source = jnp.array([0, 0, 0, -1])
    start = jnp.array([20, 20, 20, 0])
    def tick(first_stand, step):
        ready = step == jnp.array([100, 130, 900, 1])
        # Gait-born worlds retain the simulator's randomized first-episode limit.
        first_stand, failed, timeout = zenbot.scratch_recovery_end(
            source, start, jnp.array([101]), step, first_stand, ready, 500, step >= 237)
        return first_stand, (failed, timeout)
    first, (failed, timeout) = jax.jit(lambda: jax.lax.scan(tick, jnp.full(4, -1), jnp.arange(701)))()
    np.testing.assert_array_equal(first, [100, 130, -1, -1])
    np.testing.assert_array_equal(failed[:130], False)
    np.testing.assert_array_equal(failed[130], [False, False, True, False])
    np.testing.assert_array_equal(failed[:, [0, 1, 3]], False)
    np.testing.assert_array_equal(np.argmax(timeout, axis=0), [600, 630, 500, 237])


def test_initial_and_later_gait_time_limits_use_the_baseline_reset_schedule():
    from instantamp.sim import Sim

    class Data(NamedTuple):
        qpos: object
        qvel: object
        qacc_warmstart: object

        def replace(self, **kwargs):
            return self._replace(**kwargs)

    base = "data/zenbot23_walk_run_recovery"
    sim = Sim(12, physics=False, robot="zenbot23_getup", floor_dir=base + "/recovery",
              walk_dir=base + "/walk_run", reset_floor=.5, random_start=True,
              assist_newtons=0., zenbot_support_weight=8., zenbot_getup_stand=True,
              zenbot_standing_amp=True, zenbot_command_gait=True, zenbot_directional_gait=True,
              zenbot_scratch_resets=True, zenbot_scratch_curriculum=True, reference_weight=12.)
    sim.dx = Data(jnp.zeros(sim.m.nq), jnp.zeros(sim.m.nv), jnp.zeros(sim.m.nv))
    key = jax.random.key(68)
    state = sim.init(key)
    floor = np.asarray(state.reference_clip) >= 0
    assert floor.sum() == 6
    key_t = jax.random.split(key, 5)[2]
    staggered = np.asarray(jax.random.randint(key_t, (sim.N,), 1, sim.episode_steps + 1))
    np.testing.assert_array_equal(state.episode_limit[floor], sim.episode_steps)
    np.testing.assert_array_equal(state.episode_limit[~floor], staggered[~floor])
    assert len(set(staggered[~floor])) > 1
    reset = sim._reset(state, jnp.ones((sim.N,), bool), jax.random.key(533))
    np.testing.assert_array_equal(reset.episode_limit, sim.episode_steps)
