"""Cold starts for guided training use measured stances with two loaded soles."""

import json
from pathlib import Path

import numpy as np

from instantamp import zenbot
from instantamp.resets import _heading_velocity
from instantamp.sim import load_bank
from instantamp.zenbot_gait_demos import command_reset_bank, guided_gait_reset_bank


def test_all_commands_receive_the_recorded_stances_and_keep_the_directional_frames(tmp_path):
    stand_dir = Path("data/zenbot23_walk_run_recovery/standing")
    recording = json.loads((stand_dir / "manifest.json").read_text())["files"]
    assert len(recording) == 6
    stand = load_bank(str(stand_dir), len(zenbot.DOF), sample_clip_times=True)
    quiet = np.asarray(stand["q"])
    assert np.max(np.linalg.norm(stand["v"], axis=1)) < .02
    assert np.max(np.degrees(np.mean(abs(quiet - zenbot.DEFAULT_Q), axis=1))) < 2.
    sources = {}
    for clip, (name, start, length) in enumerate(zip(sorted(recording), stand["offsets"], stand["lengths"])):
        assert min(recording[name]["min_each_foot_bw"]) > .25
        sources.update({row.tobytes(): clip for row in quiet[int(start):int(start + length)]})

    names = ("stand_4s_120f", "Male1_B1_StandToWalk", "run__C3_-_run_stageii",
             "male_walk__Walk_B4_-_Stand_to_Walk_Back_stageii", "droidupe1_side_left",
             "droidupe1_side_right", "droidupe1_turn_left", "droidupe1_turn_right")
    for group, (name, target) in enumerate(zip(names, zenbot.DIRECTIONAL_COMMANDS)):
        n = 24 + group * 3
        t = np.arange(n) / 50.
        z = np.zeros(n)
        angles = np.tile(zenbot.DEFAULT_Q, (n, 1))
        angles[:, 0] = 3 + group
        angles[:, 1] += t
        quat = np.column_stack((z, z, np.sin(t*target[2]/2), np.cos(t*target[2]/2)))
        np.savez(tmp_path / (name + ".npz"), fps=50., root_quat=quat, dof_pos=angles,
                 root_pos=np.column_stack((z, z, z + .69)), root_lin_vel=np.tile([*target[:2], 0.], (n, 1)),
                 root_ang_vel=np.tile([0., 0., target[2]], (n, 1)), dof_vel=np.zeros_like(angles))
    raw = load_bank(str(tmp_path), len(zenbot.DOF))
    walk = command_reset_bank(tmp_path, raw, np.ones(len(raw["z"]), bool), True)
    result = guided_gait_reset_bank(walk, str(stand_dir))
    assert set(result) == set(walk)
    np.testing.assert_array_equal(result["offsets"], np.cumsum(np.r_[0, result["counts"][:-1]]))
    for group, (offset, n_rows) in enumerate(zip(result["offsets"], result["counts"])):
        new = slice(int(offset), int(offset + n_rows))
        poses = np.asarray(result["q"])[new]
        source = np.array([sources.get(row.tobytes(), -1) for row in poses])
        cold = source >= 0
        assert set(source[cold]) == set(range(6))
        if group == 0:
            assert cold.all()
            np.testing.assert_array_equal(poses, quiet)
            continue
        assert abs(cold.mean() - .25) <= .02
        old_offset = int(walk["offsets"][group])
        old = slice(old_offset, old_offset + int(walk["counts"][group]))
        for field in ("z", "quat", "v", "w", "q", "qd"):
            # Every original forward, backward, lateral or yaw frame survives without alteration.
            np.testing.assert_array_equal(np.asarray(result[field])[new][~cold], np.asarray(walk[field])[old])
        velocity = _heading_velocity(np.asarray(result["quat"])[new][~cold][:, [1, 2, 3, 0]],
                                     np.asarray(result["v"])[new][~cold], np.asarray(result["w"])[new][~cold])
        np.testing.assert_allclose(velocity.mean(axis=0), zenbot.DIRECTIONAL_COMMANDS[group], atol=1e-6)
