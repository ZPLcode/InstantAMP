import hashlib
import json
import sys
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import train_zenbot_scratch as scratch
from instantamp.train_g1_getup_amp import GetUpAMP


def test_all_commands_still_matching_and_opposite():
    commands = np.asarray(scratch.zenbot.DIRECTIONAL_COMMANDS)
    assert commands.shape == (8, 3)
    still = np.asarray(scratch.commanded_velocity_score(commands, -commands))
    match = np.asarray(scratch.commanded_velocity_score(commands, np.zeros_like(commands)))
    reverse = np.asarray(scratch.commanded_velocity_score(commands, -2. * commands))
    np.testing.assert_allclose(still, [1., *([0.] * 7)], atol=1e-6)
    np.testing.assert_allclose(match, np.ones(8), atol=1e-6)
    np.testing.assert_allclose(reverse, [1., *([-1.] * 7)], atol=1e-6)
    # Zero command should still penalize physical drift.
    assert scratch.commanded_velocity_score(jnp.zeros(3), jnp.array([.4, 0., 0.])) == 0.


def test_guide_sampling_allocates_half_to_floor_independent_of_bank_size():
    trainer = GetUpAMP.__new__(GetUpAMP)
    counts = np.arange(5, 14, dtype=np.int32)
    starts = np.r_[0, counts.cumsum()[:-1]]
    skills = np.repeat(np.arange(9), counts)
    trainer.guide_counts = jnp.array(counts)
    trainer.guide_rows = jnp.array(starts[:, None] + np.arange(counts.max()))
    result = jax.jit(lambda k: trainer.sample_reference_rows(k, 256))(jax.random.key(7))
    np.testing.assert_array_equal(np.bincount(skills[np.asarray(result)]), [128] + [16] * 8)


def test_entry_records_reproducible_defaults_without_running_training(monkeypatch, tmp_path):
    pair_file = tmp_path / "custom_train.npz"
    skill = np.repeat(np.arange(9), 3)
    np.savez(pair_file, obs=np.zeros((len(skill), 234), np.float32),
             q_target_raw=np.zeros((len(skill), 23), np.float32), skill=skill)
    received = {}
    def capture(cfg, cls, metadata):
        received.update(cfg=cfg, cls=cls, meta=metadata)
    monkeypatch.setattr(scratch, "train", capture)
    monkeypatch.setattr(sys, "argv", ["train_zenbot_scratch", "--reference-pairs", str(pair_file)])
    scratch.main()
    cfg, meta = received["cfg"], received["meta"]
    assert cfg.iterations == 10000 and cfg.seed == 42
    assert cfg.num_envs * cfg.rollout * cfg.iterations == 983040000
    assert cfg.assist_curriculum and cfg.fixed_std and cfg.init_std == .5 and cfg.linear_command_tracking
    assert cfg.gait_speed_weight == 8. and cfg.guide_weight == 6. and cfg.guide_final_weight == .3 and cfg.guide_end_iteration == 3500
    assert cfg.guide_batch == 256 and Path(cfg.reference_guide_path) == pair_file
    assert cfg.init_policy == cfg.rise_teacher == cfg.gait_teacher == ""
    assert meta["eval_assist_newtons"] == 0.
    assert meta["reference_pair_sha256"] == hashlib.sha256(pair_file.read_bytes()).hexdigest()
    assert meta["reference_pair_datasets"]["train"]["rows_per_skill"] == [3] * 9
    assert meta["reference_pair_datasets"]["train"]["rows"] == 27
    assert "instantamp/sim.py" in meta["reference_pair_source_sha256"]
    json.dumps(meta)
    report = {"bytes_sha256": {"train": meta["reference_pair_sha256"]},
              "generator_source_sha256": {"tools/prepare_zenbot_scratch_pairs.py": "at_generation"}}
    (tmp_path / "checks_v2.json").write_text(json.dumps(report))
    monkeypatch.setattr(sys, "argv", ["train_zenbot_scratch", "--reference-pairs", str(pair_file), "--guide-final-weight", "0"])
    scratch.main()
    assert received["cfg"].guide_final_weight == 0.
    assert received["meta"]["reference_pair_generation_source_sha256"] == report["generator_source_sha256"]
    assert "checks_v2.json" in received["meta"]["reference_pair_checks_sha256"]

    monkeypatch.setattr(sys, "argv", ["train_zenbot_scratch", "--pure-ppo"])
    scratch.main()
    cfg = received["cfg"]
    assert not (cfg.reference_guide_path or cfg.assist_curriculum or cfg.fixed_std or cfg.linear_command_tracking)
    assert (cfg.num_envs, cfg.rollout, cfg.init_std, cfg.gait_speed_weight) == (768, 48, 1., 14.)
