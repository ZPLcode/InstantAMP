from types import SimpleNamespace

import numpy as np
import pytest

from tools import evaluate_zenbot_getup as ground
from tools import evaluate_zenbot_scratch as scratch


class Captured(Exception):
    pass


def test_floor_and_stance_reset_only_change_five_actual_motor_delays(monkeypatch):
    seed=932277
    q=np.r_[0.,0.,.69,1.,np.zeros(26)]
    v=np.zeros(29)
    lags=np.array([4,5,3,6,7])
    seen=[]
    def reset(pose,vel,delay,command):
        seen.append((pose.copy(),vel.copy(),delay.copy(),np.array(command)))
        raise Captured

    player=SimpleNamespace(names=[("a",0),("b",0)],poses=[q,q],velocities=[v,v],
                           native=SimpleNamespace(reset=reset),speed=0.)
    monkeypatch.setattr(scratch,"standing_start",lambda bank,seed:("stand",2,q,v,lags))
    for evaluation in (lambda **kw:ground.evaluate(player,1,seed,100,-1,**kw),
                       lambda **kw:scratch.from_standing(player,None,seed,["still"],150,**kw)):
        with pytest.raises(Captured): evaluation()
        with pytest.raises(Captured): evaluation(immediate_motors=True)
        a,b=seen[-2:]
        for index in (0,1,3):np.testing.assert_array_equal(a[index],b[index])
        np.testing.assert_array_equal(b[2],np.zeros(5,int))
        assert np.all((a[2]>=3)&(a[2]<=7))
    np.testing.assert_array_equal(seen[0][2],np.random.default_rng(seed).integers(3,8,(2,5))[1])
    np.testing.assert_array_equal(seen[2][2],lags)


def test_monitor_caches_and_separates_motor_domains(monkeypatch,tmp_path):
    import hashlib
    import json
    from pathlib import Path
    from tools import monitor_zenbot_scratch as monitor

    ck=tmp_path/"004500.npz"
    ck.write_bytes(b"saved")
    calls=[]
    def evaluator(command,check,env):
        immediate="--immediate-motors" in command
        pending=Path(command[command.index("--out")+1])
        pending.write_text(json.dumps(dict(immediate_motors=immediate,sha256=hashlib.sha256(ck.read_bytes()).hexdigest(),seeds=[42])))
        calls.append(immediate)
    monkeypatch.setattr(monitor.subprocess,"run",evaluator)
    for zero in (False,True):
        out=tmp_path/f"{zero}.json"
        monitor.evaluate(ck,out,(42,),immediate_motors=zero)
        monitor.evaluate(ck,out,(42,),immediate_motors=zero)
        with pytest.raises(ValueError,match="separate evaluation directory"):
            monitor.evaluate(ck,out,(42,),immediate_motors=not zero)
    assert calls==[False,True]
