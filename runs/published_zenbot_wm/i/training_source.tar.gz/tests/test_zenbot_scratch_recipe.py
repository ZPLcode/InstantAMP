"""Run the recipe in a relocated checkout with recording stand-ins for training and evaluation."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


RECIPE = Path(__file__).resolve().parents[1] / "tools/recipes/train_zenbot_scratch.sh"


@pytest.fixture
def checkout(tmp_path):
    root = tmp_path / "clean checkout"
    script = root / "tools/recipes" / RECIPE.name
    script.parent.mkdir(parents=True)
    shutil.copy(RECIPE, script)
    python = root / ".venv/bin/python"
    python.parent.mkdir(parents=True)
    python.write_text(f"#!{sys.executable}\n" + r'''
import json, os, pathlib, sys
args = sys.argv[1:]
assert args[0] == "-m"
with open(os.environ["RECORD"], "a") as stream:
    print(json.dumps([args, os.getcwd(), os.environ.get("JAX_PLATFORMS")]), file=stream)
mode = os.environ["FAIL_STAGE"]
if args[1] == "tools.prepare_zenbot_scratch_pairs":
    if mode == "prepare": sys.exit(17)
    out = pathlib.Path(args[3])
    out.mkdir(parents=True)
    (out / "train.npz").write_text("generated examples")
elif args[1] == "instantamp.train_zenbot_scratch":
    if mode == "train": sys.exit(23)
    if "--reference-pairs" in args:
        assert pathlib.Path(args[args.index("--reference-pairs") + 1]).read_text() == "generated examples"
    ckpt = pathlib.Path(args[args.index("--log-dir") + 1]) / "ckpt"
    ckpt.mkdir(parents=True)
    (ckpt / ("009750.npz" if mode == "missing" else "010000.npz")).touch()
else:
    raise AssertionError(args)
''')
    python.chmod(0o755)
    release = root / "releases/zenbot_motion_train/evaluate.sh"
    release.parent.mkdir(parents=True)
    release.write_text('''#!/usr/bin/env bash
set -eu
[[ -f "$POLICY" ]]
printf '%s\\n' "$POLICY" "$SIM_PYTHON" "$@" > "$EVALUATION"
''')
    record = tmp_path / "record"
    evaluated = tmp_path / "evaluation"
    def run(args, fail=""):
        env = {**os.environ, "SIM_PYTHON": ".venv/bin/python", "POLICY": "/wrong/old.npz", "RECORD": str(record),
               "EVALUATION": str(evaluated), "FAIL_STAGE": fail, "JAX_PLATFORMS": "cuda"}
        result = subprocess.run(["bash", str(script), *args], env=env, cwd=tmp_path, capture_output=True, text=True)
        calls = [json.loads(line) for line in record.read_text().splitlines()] if record.exists() else []
        eval_args = evaluated.read_text().splitlines() if evaluated.exists() else []
        return result, calls, eval_args
    return root, run


@pytest.mark.parametrize("plain", [False, True])
def test_recipe_preserves_seed_final_checkpoint_and_release_benchmark(checkout, plain):
    root, run = checkout
    directory = str(root / "absolute trial") if plain else "runs/relative trial"
    args = [directory, "--pure-ppo"] if plain else [directory]
    result, calls, eval_args = run(args)
    assert result.returncode == 0, result.stderr
    pairs = directory + "/reference_pairs"
    guide = ["--pure-ppo"] if plain else ["--reference-pairs", pairs + "/train.npz"]
    expected = [] if plain else [[["-m", "tools.prepare_zenbot_scratch_pairs", "--out", pairs], str(root), "cpu"]]
    expected.append([["-m", "instantamp.train_zenbot_scratch", *guide, "--seed", "42", "--iterations", "10000",
                      "--log-dir", directory], str(root), "cuda"])
    assert calls == expected
    # The release script selects its own public seed lists when no seed override is supplied.
    assert eval_args == [directory + "/ckpt/010000.npz", ".venv/bin/python", directory + "/evaluation"]
    assert (root / pairs).exists() == (not plain)


def test_refuses_existing_checkpoint_before_touching_reference_examples(checkout):
    root, run = checkout
    directory = root / "existing"
    (directory / "ckpt").mkdir(parents=True)
    pairs = directory / "reference_pairs/train.npz"
    pairs.parent.mkdir()
    pairs.write_bytes(b"original")
    result, calls, eval_args = run(["existing"])
    assert result.returncode != 0 and not calls and not eval_args
    assert pairs.read_bytes() == b"original"


@pytest.mark.parametrize("failure, expected", [("prepare", 17), ("train", 23), ("missing", 1)])
def test_failed_stage_or_missing_final_checkpoint_prevents_evaluation(checkout, failure, expected):
    _, run = checkout
    result, calls, eval_args = run(["failed"], failure)
    assert result.returncode == expected and not eval_args
    assert len(calls) == (1 if failure == "prepare" else 2)
