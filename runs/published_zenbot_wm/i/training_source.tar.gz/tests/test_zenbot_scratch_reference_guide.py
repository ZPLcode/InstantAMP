"""Small, reproducible PPO updates with the same observation and action widths as the Zenbot actor."""

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import amp, nets, optim
from instantamp.train_g1_getup_amp import normalized_input
from instantamp.train_zenbot_scratch import ScratchAMP, ScratchSettings


def learner(guide_path, weight, moving_targets=True):
    # The PPO learner, its actors, Adam, and AMP discriminator all run their normal update.
    # A synthetic replay batch supplies both sides of the discriminator without using a motion file.
    trainer = object.__new__(ScratchAMP)
    trainer.c = ScratchSettings()
    c = trainer.c
    c.num_envs, c.epochs, c.minibatches = 4, 1, 1
    c.fixed_std = True
    c.reference_guide_path, c.guide_weight = guide_path, weight
    c.guide_end_iteration, c.guide_batch = 3500, 256
    c.init_std = .5
    trainer.condition_dim = 0
    trainer.disc_batch = 4
    trainer.discriminator_examples = lambda key, sample: (sample + .1, sample)
    trainer.obs_norm = {"raw": True, **nets.rn_init(234)}
    key = jax.random.key(90)
    ac = {"pi": nets.mlp_init(key, [234, 23]), "v": nets.mlp_init(key, [6, 1]), "std": jnp.full(23, .5)}
    ac["pi"][-1]["b"] = jnp.zeros(23)
    trainer.mask = jax.tree.map(lambda _: False, ac)
    actor_norm = {"mean": jnp.full(234, 2.), "var": jnp.full(234, 4.), "count": jnp.float32(1.)}
    critic_norm = {"mean": jnp.full(6, -1.), "var": jnp.full(6, 2.), "count": jnp.float32(1.)}
    optimizer = (ac, optim.init(ac, trainer.mask), jnp.float32(.0001), {"actor": actor_norm, "critic": critic_norm})
    # At the rollout mean the linear actor outputs exactly zero. Updated moments or raw input give a different label.
    trainer.guide_obs = jnp.broadcast_to(actor_norm["mean"], (256, 234))
    trainer.guide_targets = jnp.full((256, 23), 2. if moving_targets else 0.)
    trainer.guide_rows = jnp.arange(9*28, dtype=jnp.int32).reshape(9, 28)
    trainer.guide_counts = jnp.full(9, 28, dtype=jnp.int32)
    disc = amp.init(key, frames=2, hidden=(4,), frame_dim=3)
    return trainer, optimizer, disc


def run_update(guide_path, weight, iteration, *, moving_targets=True, ppo_loss=False, final_weight=0.):
    trainer, optimizer, disc = learner(guide_path, weight, moving_targets)
    trainer.c.guide_final_weight = final_weight
    ac, _, _, norms = optimizer
    key = jax.random.key(43)
    obs = jax.random.normal(key, (8, 234)) + 8.
    critic_obs = jax.random.normal(key, (8, 6)) - 6.
    mu = trainer.actor_mean(ac["pi"], normalized_input(norms["actor"], obs))
    value = nets.mlp_apply(ac["v"], normalized_input(norms["critic"], critic_obs), jax.nn.elu)[:, 0]
    adv = jnp.linspace(-1., 1., 8) if ppo_loss else jnp.zeros(8)
    target = value + (adv if ppo_loss else 0.)
    actions = mu + .5 * jax.random.normal(key, mu.shape)
    batch = (obs, critic_obs, mu, actions, value, adv, target)
    replay = jax.random.normal(key, (2, 4, 2, 3))
    updated, new_disc, stats = trainer.learn(
        optimizer, disc, batch, replay, jnp.int32(2), key, train_actor=True, ppo_iteration=jnp.int32(iteration))
    # The KL of the first PPO batch is zero only if it exactly reproduces the rollout actor mean.
    np.testing.assert_allclose(stats[0], 0., atol=5e-6)
    expected = {"actor": nets.rn_update(norms["actor"], obs), "critic": nets.rn_update(norms["critic"], critic_obs)}
    assert_tree_equal(updated[3], expected, atol=1e-5)
    np.testing.assert_array_equal(updated[0]["std"], np.full(23, .5))
    np.testing.assert_array_equal(updated[1]["leaves"]["std"]["m"], 0.)
    if guide_path:
        strength = final_weight + (weight - final_weight) * np.clip((3500 - iteration) / 3499., 0., 1.)
        np.testing.assert_allclose(stats[-1], strength, atol=1e-6)
    return updated, new_disc, ac


def assert_tree_equal(actual, expected, atol=0.):
    assert jax.tree.structure(actual) == jax.tree.structure(expected)
    for a, b in zip(jax.tree.leaves(actual), jax.tree.leaves(expected)):
        np.testing.assert_allclose(a, b, atol=atol, rtol=0.)


def test_zero_or_expired_guide_matches_unguided_ppo_and_fixed_std():
    baseline, disc, initial = run_update("", 0., 1, ppo_loss=True)
    assert any(np.any(np.asarray(a) != np.asarray(b))
               for a, b in zip(jax.tree.leaves(initial["pi"]), jax.tree.leaves(baseline[0]["pi"])))
    for weight, iteration in ((0., 1), (6., 3500), (6., 9000)):
        result, other_disc, _ = run_update("synthetic.npz", weight, iteration, ppo_loss=True)
        assert_tree_equal(result, baseline)
        assert_tree_equal(other_disc, disc)


def test_early_guide_updates_only_actor_with_frozen_rollout_normalization():
    guided, disc, initial = run_update("synthetic.npz", 6., 1)
    # No PPO actor or critic signal in this batch, so all changed policy parameters originate from the guide.
    assert np.any(np.asarray(guided[0]["pi"][-1]["b"]) > 0.)
    assert_tree_equal(guided[0]["v"], initial["v"])
    matched, matched_disc, initial = run_update("synthetic.npz", 6., 1, moving_targets=False)
    assert_tree_equal(matched[0]["pi"], initial["pi"])
    assert_tree_equal(matched[0]["v"], initial["v"])
    assert_tree_equal(matched_disc, disc)


def test_terminal_weight_retains_the_selected_actor_guide_strength():
    for iteration in (1, 1750, 3500, 10000):
        updated, _, before = run_update("synthetic.npz", 6., iteration, final_weight=.3)
        assert np.any(np.asarray(updated[0]["pi"][-1]["b"]) > 0.)
        assert_tree_equal(updated[0]["v"], before["v"])
    # After the transition, both the actor update and its Adam moments match a constant 0.3.
    constant, _, _ = run_update("synthetic.npz", .3, 1, final_weight=.3)
    assert_tree_equal(updated, constant)
