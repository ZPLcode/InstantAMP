from functools import partial
from pathlib import Path
from types import SimpleNamespace
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import train_zenbot_getup_stand_amp as standing
from instantamp import zenbot
from instantamp.sim import Sim
from instantamp.train_zenbot_scratch import ScratchAMP, ScratchSettings
from instantamp.zenbot_gait_demos import gait_command_index


class CPUData(NamedTuple):
    qpos: object
    qvel: object
    qacc_warmstart: object

    def replace(self, **kwargs):
        return self._replace(**kwargs)


@pytest.mark.parametrize("short,frames,stride", [(False, 10, 3), (True, 3, 1)])
def test_native_banks_rollout_replay_and_discriminator_agree(monkeypatch, short, frames, stride):
    bank = Path("data/zenbot23_walk_run_recovery")
    if not (bank / "walk_run/sampling.json").exists():
        pytest.skip("requires the prepared Zenbot locomotion reference bank")
    monkeypatch.setattr(standing, "Sim", partial(Sim, physics=False))
    cfg = ScratchSettings(
        short_amp_window=short, num_envs=2, rollout=2, minibatches=1, critic_warmup=0,
        floor_dir=str(bank / "recovery"), stand_dir=str(bank / "standing"),
        gait_dir=str(bank / "walk_run"),
    )
    trainer = ScratchAMP(cfg)
    sim = trainer.sim
    sim.dx = CPUData(jnp.zeros(sim.m.nq), jnp.zeros(sim.m.nv), jnp.zeros(sim.m.nv))
    live, optimizer, disc = trainer.init()
    state, history, replay, written = live
    depth = sim.amp_dim + trainer.condition_dim
    span = 1 + (frames - 1) * stride
    assert trainer.amp_span == span
    assert history.shape == (cfg.num_envs, span, sim.amp_dim)
    assert replay.shape == (244, cfg.num_envs, frames, depth)
    assert disc["net"][0]["w"].shape[0] == frames * depth

    # Get eligible raw-frame starts independently from the command sampler.
    eligible = [[] for _ in range(9)]
    offset = 0
    for label, source in enumerate((trainer.demos, trainer.stand_demos, trainer.walk_demos, trainer.run_demos)):
        assert source.window == span
        if label < 2:
            eligible[label].append(np.asarray(source.starts) + offset)
        else:
            starts = np.split(np.asarray(source.starts), np.cumsum(source.clip_counts)[:-1])
            for name, clip_starts in zip(source.clip_names, starts, strict=True):
                eligible[1 + gait_command_index(name)].append(clip_starts + offset)
        offset += len(source.frames)

    # Encode raw time in a scalar unaffected by motion_features.
    windows = trainer.windows
    windows.frames = windows.frames.at[:, 0].set(jnp.arange(len(windows.frames)))
    labels = np.tile(np.arange(9), 8)
    condition = jax.nn.one_hot(labels, 9)[:, None, :]
    policy = jnp.zeros((len(labels), frames, depth)).at[:, :, -9:].set(condition)
    expert, negative = trainer.discriminator_examples(jax.random.key(1), policy)
    np.testing.assert_array_equal(negative, policy)
    np.testing.assert_array_equal(expert[:, :, -9:], negative[:, :, -9:])
    times = np.asarray(expert[:, :, 0], dtype=int)
    expected_spacing = np.broadcast_to(np.arange(frames) * stride, times.shape)
    np.testing.assert_array_equal(times - times[:, :1], expected_spacing)
    for label, groups in enumerate(eligible):
        assert groups
        assert np.isin(times[labels == label, 0], np.concatenate(groups)).all()

    # Only physics is replaced. Run the real collector, discriminator, and replay writer, including
    # a terminal pre-reset frame at tick 1 and the following reset episode with initial coordinate 100.
    state = state._replace(data=state.data.replace(qpos=state.data.qpos.at[:, 0].set(0)))
    history = history.at[:, :, 0].set(jnp.arange(1 - span, 1)[None])
    amp_frame = sim.amp_frame
    monkeypatch.setattr(sim, "amp_frame", lambda s: amp_frame(s).at[:, 0].set(s[0][:, 0]))

    def step(previous, action):
        pos = previous.data.qpos.at[:, 0].add(1)
        end = (jnp.arange(cfg.num_envs) == 1) & (pos[:, 0] == 1)
        after = pos.at[:, 0].set(jnp.where(end, 100., pos[:, 0]))
        result = previous._replace(data=previous.data.replace(qpos=after))
        zeros = jnp.zeros(cfg.num_envs)
        stats = dict.fromkeys(("down_done", "down_up", "diverged", *trainer.extra_rollout_stats), jnp.float32(0))
        stats.update(
            gait_command=jnp.asarray(zenbot.DIRECTIONAL_COMMANDS[[1, 7]]),
            gait_ready=jnp.ones(cfg.num_envs, bool), stand_blend=zeros,
            gait_velocity_error=jnp.zeros((cfg.num_envs, 3)), min_foot_load_bw=zeros,
        )
        transition = SimpleNamespace(
            qpos1=pos, qvel1=previous.data.qvel, terminated=end,
            truncated=jnp.zeros_like(end), reward=zeros, stats=stats,
        )
        return result, transition

    monkeypatch.setattr(sim, "step", step)
    current, _, _ = trainer.collect(
        (state, history, replay, written), optimizer[0], disc, jax.random.key(2), optimizer[3],
    )
    _, _, samples, written = current
    assert int(written) == 2
    first = np.arange(2 - span, 2, stride)
    np.testing.assert_array_equal(samples[0, 0, :, 0], first)
    np.testing.assert_array_equal(samples[1, 0, :, 0], first + 1)
    np.testing.assert_array_equal(samples[0, 1, :, 0], first)
    np.testing.assert_array_equal(samples[1, 1, :, 0], [100] * (frames - 1) + [101])
    conditions = jax.nn.one_hot(jnp.array([2, 8]), 9)[None, :, None, :]
    np.testing.assert_array_equal(samples[:2, :, :, -9:], np.broadcast_to(conditions, (2, 2, frames, 9)))
