import pytest

from tools.train_zenbot_skill_actor import teacher_perturbation


def test_hidden_teacher_commands_and_legacy_distillation_labels():
    torch = pytest.importorskip("torch")
    frames = torch.zeros(4, 5, 99)
    frames[:, :, 96] = 2.5
    noise = torch.zeros_like(frames)
    noise[:, :, 0] = 0.5
    speeds = torch.tensor([[1.0] * 5, [float("nan")] * 5, [2.5] * 5, [1.0] * 5])
    blend = torch.tensor([1.0, float("nan"), 1.0, 1.0])
    commands = torch.tensor([1.0, 1.0, 2.5, 1.0])[:, None]
    target = commands.expand(4, 23).clone()

    def gait(history):
        return (history[:, -1, 6] * (1.0 + history[:, -1, 0]))[:, None].expand(-1, 23)

    def rise(history):
        return torch.zeros(len(history), 23)

    applied, delta = teacher_perturbation(
        frames,
        target,
        torch.tensor([3, 3, 4, 3]),
        torch.tensor([True, True, True, False]),
        speeds,
        blend,
        noise,
        rise,
        gait,
        torch.zeros(23),
        True,
        torch,
    )
    torch.testing.assert_close(delta[:, 0], torch.tensor([0.5, 0.0, 1.25, 0.0]))
    torch.testing.assert_close(applied[:, -1, 0], torch.tensor([0.5, 0.0, 0.5, 0.0]))


def test_motion_train_distillation_imu_and_noise_axes():
    from instantamp.zenbot_motion_train_obs import SENSOR_NOISE
    from tools.distill_zenbot_directions import motion_train_noisy_history

    torch = pytest.importorskip("torch")
    clean = torch.zeros(2, 5, 78)
    clean[:, :, 0] = torch.arange(5.0) * 2.0
    clean[:, :, 3] = 1.0
    clean[:, :, 7] = 0.4
    clean[:, :, 55:] = -0.5
    # 2 ms and 35 ms exercise both interpolation intervals.
    delays = torch.tensor([[0.1, 0.0], [0.95, 1.0]])
    sensed = motion_train_noisy_history(
        clean, torch, latency_samples=delays, noise_samples=torch.ones(2, 3, 78)
    )
    expected = clean[:, -3:].clone()
    expected[:, :, 0] -= torch.tensor([0.2, 3.5])[:, None]
    torch.testing.assert_close(sensed[:, -3:], expected + torch.as_tensor(SENSOR_NOISE))
    torch.testing.assert_close(sensed[:, :2], clean[:, :2])


def test_floor_command_changes_only_student_history_on_low_zero_command_samples():
    from tools.distill_zenbot_directions import with_ground_intents

    torch = pytest.importorskip("torch")
    observed = torch.zeros(3, 5, 78)
    observed[2, :, 6] = 1.0
    instruction = torch.tensor([[0.0, -0.4, 0.6]])
    student = with_ground_intents(
        observed, torch.tensor([True, False, True]), instruction, 1.0, torch
    )
    torch.testing.assert_close(student[0, -3:, 6:9], instruction.repeat(3, 1))
    torch.testing.assert_close(observed[0], torch.zeros_like(observed[0]))
    torch.testing.assert_close(student[1:], observed[1:])
    torch.testing.assert_close(student[:, :2], observed[:, :2])
    torch.testing.assert_close(student[:, :, 9:], observed[:, :, 9:])
