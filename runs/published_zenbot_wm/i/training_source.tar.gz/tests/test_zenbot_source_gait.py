import json
from functools import partial
from pathlib import Path
from types import SimpleNamespace
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import amp, env, zenbot
from instantamp import train_zenbot_getup_stand_amp as standing
from instantamp import zenbot_source_gait as gait
from instantamp.sim import Sim, unflatten
from instantamp.train_zenbot_scratch import ScratchAMP, ScratchSettings


def test_source_commands_and_physical_reset():
    n = 8192
    key = jax.random.key(122)
    q, v = gait.stand_reset(key, n)
    pos, rot, lin, ang, angles, dangles = unflatten(q, v)
    np.testing.assert_allclose(pos[:, 2], .69)
    np.testing.assert_allclose(np.linalg.norm(q[:, 3:7], axis=1), 1., atol=1e-6)
    for x, limit in [(pos[:, :2], .5), (lin, .2), (ang, .2)]:
        assert abs(x).max() <= limit + 1e-6
        assert abs(x.mean()) < .01 and x.std() > .1
    np.testing.assert_array_equal(dangles, 0.)
    default = np.asarray(zenbot.DEFAULT_Q)
    nonzero = default != 0
    np.testing.assert_array_equal(angles[:, ~nonzero], 0.)
    ratio = np.asarray(angles)[:, nonzero] / default[nonzero]
    assert .79999 <= ratio.min() < .801 and 1.199 < ratio.max() <= 1.20001

    for stage in range(3):
        cmd = jax.jit(gait.sample_command, static_argnums=1)(key, n, stage)
        actual = gait.command(cmd, rot)
        stand = np.asarray(cmd.is_standing)
        move = np.asarray(cmd.is_heading)
        turn = ~stand & ~move
        np.testing.assert_allclose([stand.mean(), turn.mean(), move.mean()], [.05, .20, .75], atol=.013)
        np.testing.assert_array_equal(actual[stand], 0.)
        np.testing.assert_array_equal(actual[turn, :2], 0.)
        np.testing.assert_allclose(actual[turn, 2], cmd.vel[turn, 2])
        assert actual[turn, 2].min() < -2.18 < 2.18 < actual[turn, 2].max()
        assert -1. <= actual[move, 0].min() < -.99
        assert stage + .99 < actual[move, 0].max() <= stage + 1.
        assert abs(actual[move, 1]).max() <= .5
        assert abs(actual[move, 2]).max() <= 1.5
        assert actual[move, 2].std() > .7
        np.testing.assert_array_equal(cmd.time_left, 10.)


def test_curriculum_excludes_recovery_and_requires_both_directions_and_falls():
    advance = jax.jit(lambda state, *args: state.advance(*args))
    error = jnp.array([.15, .25, 4.])
    enabled = jnp.array([True, True, False])
    falls, timeout = jnp.array([False, True, True]), jnp.array([True, False, False])
    cmd = jnp.array([.8, -.9, 3.])
    empty = gait.Curriculum.empty(3)
    closed = advance(empty, cmd, error, enabled, falls, timeout)
    np.testing.assert_allclose(closed.completed, [2., .4, 1., .15, 1., .25, 1., 2.], atol=1e-6)
    window = jnp.array([30000., 3000., 10000., 1000., 10000., 1000., 0., 1024.])
    def assess(window):
        return advance(empty._replace(control_ticks=jnp.int32(999), completed=window), cmd, error, enabled, falls, timeout)
    promoted = assess(window)
    assert int(promoted.stage) == 1
    np.testing.assert_array_equal(promoted.completed, 0.)
    assert int(assess(window.at[4].set(0.)).stage) == 0
    bad_falls = assess(window.at[6].set(200.))
    assert int(bad_falls.stage) == 0
    np.testing.assert_array_equal(bad_falls.completed, 0.)
    assert bad_falls.last_metrics[-1] > .10
    assert int(assess(window.at[3].set(5000.)).stage) == 0


def test_tracking_in_body_frame_and_fall_thresholds():
    rotation = jnp.tile(jnp.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])[None], (4,1,1))
    vel = jnp.array([[0., 1., 0.], [0., 0., 0.], [0., 0., 0.], [0., 0., 0.]])
    angular = jnp.array([[0.,0.,0.], [0.,0.,1.], [0.,0.,-1.], [0.,0.,0.]])
    command = jnp.array([[1.,0.,0.], [0.,0.,1.], [0.,0.,1.], [0.,0.,0.]])
    scores, error = gait.tracking((None,rotation,vel,angular,None,None),command)
    np.testing.assert_allclose(error, 0.)
    np.testing.assert_allclose(scores[[0,1,3],], [3.5 + .5 * np.tanh(2), 3.5 + .5 * np.tanh(2), 3.5], atol=1e-6)
    assert scores[2] < 2.
    assert gait.failed(jnp.array([.2,.19,.7,.7,.7]), jnp.array([.5,1.,.49,1.,1.]),
                       jnp.array([False,False,False,True,False]),jnp.array([False,False,False,False,True])).tolist() == [
        False,True,True,True,True]


class CPUData(NamedTuple):
    qpos: object
    qvel: object
    qacc_warmstart: object

    @property
    def _impl(self):
        return SimpleNamespace(nacon=jnp.zeros(1), contact__dist=jnp.zeros(1))

    @property
    def ctrl(self):
        return jnp.zeros_like(self.qpos[..., 7:])

    @property
    def xfrc_applied(self):
        return jnp.zeros((*self.qpos.shape[:-1], 64, 6))

    def replace(self, **kwargs):
        return self._replace(**kwargs)


def test_mixed_real_entry_point(monkeypatch):
    bank = Path("data/zenbot23_walk_run_recovery")
    if not (bank / "walk_run/sampling.json").exists():
        pytest.skip("requires prepared Zenbot AMP motions")
    monkeypatch.setattr(standing, "Sim", partial(Sim, physics=False))
    c = ScratchSettings(source_gait=True, num_envs=4,rollout=2,minibatches=1,assist_curriculum=True,
                        floor_dir=str(bank / "recovery"),stand_dir=str(bank / "standing"),gait_dir=str(bank / "walk_run"))
    trainer = ScratchAMP(c)
    sim = trainer.sim
    sim.dx = CPUData(jnp.zeros(sim.m.nq), jnp.zeros(sim.m.nv), jnp.zeros(sim.m.nv))
    live, _, disc = trainer.init()
    state, history, replay, _ = live
    assert trainer.actor_input(state).shape == (4, 234)
    assert trainer.condition_dim == 3 and (trainer.amp_span, trainer.amp_stride) == (3,1)
    assert history.shape == (4,3,sim.amp_dim) and replay.shape == (244,4,3,sim.amp_dim + 3)
    assert disc["net"][0]["w"].shape[0] == 3 * (sim.amp_dim + 3)
    floor = np.asarray(state.reference_clip) >= 0
    assert floor.sum() == 2
    np.testing.assert_array_equal(state.gait_ready, ~floor)
    np.testing.assert_array_equal(state.c_obs[floor], 0.)
    np.testing.assert_allclose(state.data.qpos[~floor,2],.69)
    np.testing.assert_array_equal(state.data.qvel[~floor,6:], 0.)
    assert state.data.qvel[~floor,:6].std() > .04
    assert ((state.cmd.time_left[floor] >= 2) & (state.cmd.time_left[floor] <= 4)).all()
    np.testing.assert_array_equal(state.cmd.time_left[~floor],10.)
    state = sim._reset(state, jnp.ones(4,bool), jax.random.key(54))
    np.testing.assert_array_equal(state.episode_limit, np.where(state.reference_clip >= 0,sim.episode_steps,1000))
    mask = gait.illegal_contact_geoms(sim.m)
    names = [sim.m.body(int(b)).name for b in np.asarray(sim.m.geom_bodyid)[mask]]
    for name in ("torso_Link","left_hip_yaw_Link","left_knee_Link","right_wrist_roll_rubber_hand"):
        assert any(name in candidate for candidate in names)
    assert not any("ankle" in name for name in names)
    raw = json.loads((bank / "walk_run/sampling.json").read_text())["weights"]
    expected = np.array([raw[clip.stem] for clip in sorted((bank / "walk_run").glob("*.npz"))])
    assert len(expected) == 17
    np.testing.assert_allclose(trainer.source_gait_demos.clip_probabilities, expected / expected.sum())
    # Number each physical clip frame monotonically in each bank, offset by its skill.
    for idx,source in enumerate((trainer.demos,trainer.stand_demos,trainer.source_gait_demos)):
        source.frames = source.frames.at[:,6].set(jnp.arange(len(source.frames)) + idx * 100000)
    labels = np.tile(np.arange(3),15)
    policy = jnp.zeros((len(labels),3,sim.amp_dim+3)).at[:,:,-3:].set(jax.nn.one_hot(labels,3)[:,None,:])
    expert,negative = trainer.discriminator_examples(jax.random.key(501),policy)
    np.testing.assert_array_equal(negative,policy)
    np.testing.assert_array_equal(expert[:,:,-3:],policy[:,:,-3:])
    np.testing.assert_array_equal(expert[:,0,6] // 100000,labels)
    np.testing.assert_allclose(np.diff(expert[:,:,6],axis=1),1.)

    monkeypatch.setattr(amp, "recovery_style", lambda *a, **kw: jnp.ones(4))
    active = jnp.array([False, False, True, True])
    under_stand_command = jnp.array([True, True, False, True])
    stats = dict(source_gait_active=active, source_standing=under_stand_command, stand_blend=jnp.zeros(4),
                 source_velocity_score=jnp.full(4,2.), source_tilt_l2=jnp.array([.5,.25,0.,.25]), min_foot_load_bw=jnp.zeros(4))
    transition = SimpleNamespace(stats=stats, terminated=jnp.array([False,True,True,False]),
                                 diverged=jnp.zeros(4,bool), reward=jnp.full(4,-.01))
    mixed,rows,_ = trainer.rollout_motion(disc,history,transition)
    np.testing.assert_array_equal(rows[:, -1,-3:].argmax(-1),[0,0,2,1])
    np.testing.assert_allclose(trainer.blend_reward(transition,mixed),
                               [.5*(-.01+env.DT*10),-.005, .3*(-.01+env.DT*2)+.7*env.DT*1.5,
                                .3*(-.01+env.DT*(2-1.2*.25))+.7*env.DT*1.5])

    # Run the real step, including terminal precedence and phase-specific task/curriculum bookkeeping.
    # Stub the four physics substeps at their outputs to place the same illegal terrain contact in every world.
    def contact_step(world, data, target, assist, fresh):
        return (data, jnp.ones((4, 2)), jnp.zeros(4), jnp.ones(4, bool),
                jnp.tile(jnp.array([240., 240., 0., 0., 0., 0.]), (4, 1)), None)

    monkeypatch.setattr(sim, "physics", contact_step)
    before = state._replace(episode_limit=jnp.where(floor, state.episode_limit, 1))
    following, tr = sim.step(before, jnp.ones((4, sim.J)), auto_reset=False)
    np.testing.assert_array_equal(tr.stats["source_gait_active"], ~floor)
    np.testing.assert_array_equal(tr.terminated, ~floor)
    np.testing.assert_array_equal(tr.truncated, False)
    np.testing.assert_array_equal(following.gait_curriculum.completed[6:], [2., 2.])
    np.testing.assert_array_equal(following.c_obs[floor], 0.)
    np.testing.assert_array_equal(following.cmd.time_left[floor], state.cmd.time_left[floor])
    rate_id = sim.terms.index("action_rate_l2")
    np.testing.assert_array_equal(tr.parts[~floor][:, np.arange(len(sim.terms)) != rate_id], 0.)
    np.testing.assert_allclose(tr.parts[~floor, rate_id], .02 * (-.015) * 23, atol=1e-7)


def test_moving_amp_windows_use_the_source_67_channels_and_measured_velocity():
    trainer = object.__new__(ScratchAMP)
    trainer.c = ScratchSettings(source_gait=True)
    trainer.sim = SimpleNamespace(J=23)
    trainer.amp_stride = 1
    window = jnp.arange(2 * 3 * 95, dtype=jnp.float32).reshape(2, 3, 95)
    features = np.asarray(trainer.source_style_features(trainer.motion_features(window), jnp.array([2, 0])))
    np.testing.assert_array_equal(features[0, :, 6:73], window[0, :, 6:73])
    np.testing.assert_array_equal(features[0, :, :6], 0.)
    np.testing.assert_array_equal(features[0, :, 73:], 0.)
    np.testing.assert_array_equal(features[1, :, :32], window[1, :, :32])
    np.testing.assert_array_equal(features[1, :, 55:], window[1, :, 55:])
    np.testing.assert_allclose(features[1, :, 32:55], 95. / .02)


def test_critic_can_compare_a_body_frame_command_and_measured_velocity_at_any_heading():
    trainer = object.__new__(ScratchAMP)
    trainer.c = ScratchSettings(source_gait=True)
    q = jnp.zeros((2, 30)).at[:, 2].set(.69).at[0, 3].set(1.)
    q = q.at[1, 3].set(jnp.sqrt(.5)).at[1, 6].set(jnp.sqrt(.5))
    v = jnp.zeros((2, 29)).at[0, 0].set(1.).at[1, 1].set(1.)
    state = SimpleNamespace(obs=jnp.zeros((2, 495)), data=SimpleNamespace(qpos=q, qvel=v))
    x = trainer.critic_input(state)
    assert x.shape == (2, 499)
    np.testing.assert_allclose(x[0], x[1], atol=1e-6)
    np.testing.assert_allclose(x[:, -3:], [[1, 0, 0], [1, 0, 0]], atol=1e-6)
