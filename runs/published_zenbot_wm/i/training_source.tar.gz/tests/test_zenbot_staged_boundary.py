import dataclasses
import json

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import optim
from instantamp import zenbot_staged_ppo as staged
from instantamp.zenbot_staged_boundary import read_learner,writer_lock
from instantamp.zenbot_staged_gait import source_configuration
from instantamp.zenbot_staged_recovery import RecoverySettings
from test_zenbot_staged_ppo import TinySim, TinyTrainer


class SampledSim(TinySim):
    def init(self,key):
        state=super().init(key)
        pos=state.data.qpos.at[:,:3].set(jax.random.uniform(key,(2,3)))
        velocity=jax.random.normal(jax.random.fold_in(key,1),state.data.qvel.shape)
        return state._replace(data=state.data._replace(qpos=pos,qvel=velocity))


class Learner(TinyTrainer):
    def __init__(self,cfg,wide=False):
        super().__init__(cfg,wide)
        self.sim=SampledSim(wide)

    actor_input=staticmethod(lambda state:state.data.qpos[:,:4])
    critic_input=staticmethod(lambda state:state.data.qvel[:,:6])

    def collect(self,live,ac,disc,key,norms):
        live,batch,metrics=super().collect(live,ac,disc,key,norms)
        return live,batch.at[0].add(self.actor_input(live[0]).mean()+self.critic_input(live[0]).mean()),metrics

    def learn(self,opt,disc,batch,replay,written,key,train_actor):
        opt,new_disc,metrics=super().learn(opt,disc,batch,replay,written,key,train_actor)
        # Exercise every discriminator parameter and both Adam moments using a real differentiable loss.
        def loss(layers):
            x=jnp.ones(layers[0]["w"].shape[0])*batch[0]
            for layer in layers:
                x=jax.nn.tanh(x@layer["w"]+layer["b"])
            return jnp.square(x-.75).mean()
        layers,adam=optim.step(disc["net"],jax.grad(loss)(disc["net"]),disc["opt"],
                               jax.tree.map(lambda _:False,disc["net"]),.0001)
        return opt,{**new_disc,"net":layers,"opt":adam},metrics


def plan(run):
    first=dataclasses.replace(source_configuration(run),num_envs=2,rollout=2,save_every=2,log_every=1)
    second = RecoverySettings(**{**dataclasses.asdict(first), "rollout":3}, floor_reward_scale=.05)
    return staged.StagePlan(first,second,2,4)


def joint(previous,settings):
    return Learner(settings,True)


def snapshot(tree):
    return jax.tree.map(lambda a:np.array(a,copy=True),tree)


def identical(a,b):
    assert jax.tree.structure(a)==jax.tree.structure(b)
    for left,right in zip(jax.tree.leaves(a),jax.tree.leaves(b),strict=True):
        assert left.dtype==right.dtype
        np.testing.assert_array_equal(left,right)


def test_exact_split_two_plus_two(tmp_path,monkeypatch):
    starts=[]
    real_start=staged.start_second
    def capture(trainer,opt,disc,key,curriculum):
        live,disc=real_start(trainer,opt,disc,key,curriculum)
        starts.append(snapshot((opt,disc,key,curriculum,live,trainer.actor_input(live[0]),trainer.critic_input(live[0]))))
        return live,disc
    monkeypatch.setattr(staged,"start_second",capture)
    whole,split=tmp_path/"whole",tmp_path/"split"
    final=snapshot(staged.train_staged(plan(whole),joint,make_stage1=Learner))
    staged.train_staged(plan(split),joint,make_stage1=Learner,stop_at_boundary=True)
    with (split/"log.jsonl").open("a") as legacy:
        with pytest.raises(RuntimeError,match="already has the training log"):
            staged.continue_staged(plan(split),joint)
    with writer_lock(split):
        with pytest.raises(RuntimeError,match="owns this run"):
            staged.continue_staged(plan(split),joint)
    def no_random_init(*args,**kwargs):
        pytest.fail("A resumed learner must come entirely from its archived boundary")
    monkeypatch.setattr(Learner,"init",no_random_init)
    resumed=snapshot(staged.continue_staged(plan(split),joint))
    for filename in ("config.json", "continuation_000002.json"):
        assert json.loads((split/filename).read_text())["second"]["floor_reward_scale"] == .05
    identical(starts[0],starts[1])
    identical(final,resumed)
    assert int(resumed[0][1]["t"])==int(resumed[1]["opt"]["t"])==4
    def rows(folder):
        data=[json.loads(line) for line in (folder/"log.jsonl").read_text().splitlines()]
        for row in data: del row["train_s"]
        return data
    assert rows(whole)==rows(split)
    assert [(r["it"],r["stage_it"],r["env_steps"]) for r in rows(split)]==[(1,1,4),(2,2,8),(3,1,14),(4,2,20)]
    assert (whole/"ckpt/000004.npz").read_bytes()==(split/"ckpt/000004.npz").read_bytes()
    final_log=(split/"log.jsonl").read_bytes()
    with pytest.raises(ValueError,match="already contains stage two"):
        staged.continue_staged(plan(split),joint)
    assert (split/"log.jsonl").read_bytes()==final_log


def test_incomplete_or_wrong_source_boundary_is_refused(tmp_path):
    p=plan(tmp_path)
    staged.train_staged(p,joint,make_stage1=Learner,stop_at_boundary=True)
    archive=tmp_path/"transition_000002.npz"
    raw=archive.read_bytes()
    archive.write_bytes(raw+b"bad")
    with pytest.raises(ValueError,match="SHA"):
        read_learner(tmp_path,p)
    archive.write_bytes(raw)
    actor=tmp_path/"ckpt/000002.npz"
    raw_actor=actor.read_bytes()
    actor.write_bytes((tmp_path/"ckpt/000000.npz").read_bytes())
    with pytest.raises(ValueError,match="archived learner"):
        read_learner(tmp_path,p)
    actor.write_bytes(raw_actor)
    marker=tmp_path/"ckpt/000003.json"
    marker.write_text("{}")
    with pytest.raises(ValueError,match="complete stage-one"):
        read_learner(tmp_path,p)
    marker.unlink()
    _,opt,disc,_,cur,steps,_=read_learner(tmp_path,p)
    assert int(opt[1]["t"])==int(disc["opt"]["t"])==2 and int(cur.stage)==2 and steps==8
