from functools import partial

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import env, zenbot, zenbot_source_gait as gait
from instantamp.rot import quat_to_mat
from instantamp.sim import Sim
from instantamp.train_zenbot_scratch import ScratchSettings
from instantamp.zenbot_staged_gait import source_configuration
from instantamp.zenbot_staged_recovery import recovery_configuration, sample_side_and_turn_commands


def test_fixed_requests_preserve_source_stops_unselected_motion_and_ten_second_clock(tmp_path):
    assert not ScratchSettings().staged_side_and_turn_commands
    assert not source_configuration(tmp_path).staged_side_and_turn_commands
    assert recovery_configuration(tmp_path).staged_side_and_turn_commands
    # Evaluate the same bound native source sampler used by both Sim._reset and env.tick.
    sim=object.__new__(Sim)
    sim.N=16000
    sim.zenbot_source_gait=True
    key=jax.random.key(23497)
    original=sim.sample_command(key,2)
    sample=partial(sample_side_and_turn_commands,sim.sample_command)
    mixed=jax.jit(sample)(key,2)
    q,_=gait.stand_reset(jax.random.key(3281),sim.N)
    rotations=quat_to_mat(q[:,3:7])
    actual=np.asarray(gait.command(mixed,rotations))
    matched=np.all(actual[:,None]==zenbot.DIRECTIONAL_COMMANDS[None,4:8],axis=2)
    chosen=matched.any(axis=1)
    np.testing.assert_allclose(matched.mean(axis=0),.11875,atol=.009)
    assert not np.any(mixed.is_heading[chosen])
    np.testing.assert_array_equal(mixed.is_standing,original.is_standing)
    np.testing.assert_array_equal(actual[np.asarray(original.is_standing)],0.)
    np.testing.assert_array_equal(actual[~chosen],np.asarray(gait.command(original,rotations))[~chosen])
    np.testing.assert_array_equal(mixed.time_left,10.)
    expired=original._replace(time_left=jnp.where(jnp.arange(sim.N)%2==0,.001,1.))
    renewed=env.tick(expired,key,sample=lambda k:sample(k,2))
    order=np.arange(sim.N)%2==0
    np.testing.assert_array_equal(renewed.vel[order],mixed.vel[order])
    np.testing.assert_array_equal(renewed.vel[~order],original.vel[~order])
    np.testing.assert_array_equal(renewed.time_left[order],10.)


def test_only_staged_trainer_installs_the_new_sampler(monkeypatch,tmp_path):
    import dataclasses
    import hashlib
    import json
    from types import SimpleNamespace
    from instantamp.train_zenbot_scratch import ScratchAMP
    from instantamp.zenbot_staged_recovery import StagedRecovery

    bank=tmp_path/"ground.npz"
    np.savez(bank,clip_names=["clip"])
    (tmp_path/"support_frames.json").write_text(json.dumps({
        "clip_names":["clip"],"ground_bank_sha256":hashlib.sha256(bank.read_bytes()).hexdigest(),"first_support":[8]}))
    def prepare(trainer,cfg):
        sim=object.__new__(Sim)
        sim.N,sim.zenbot_source_gait,sim.floor=64,True,{}
        trainer.sim=sim
        trainer.online_bank=SimpleNamespace(lengths=np.array([80]))
    monkeypatch.setattr(ScratchAMP,"__init__",prepare)
    cfg=ScratchSettings(online_ground_bank=str(bank))
    key=jax.random.key(203)
    original=gait.sample_command(key,64,1)
    prior=StagedRecovery(cfg).sim.sample_command(key,1)
    for a,b in zip(prior,original,strict=True): np.testing.assert_array_equal(a,b)
    configured=StagedRecovery(dataclasses.replace(cfg,staged_side_and_turn_commands=True)).sim.sample_command(key,1)
    chosen=np.any(np.all(np.asarray(configured.vel)[:,None]==zenbot.DIRECTIONAL_COMMANDS[None,4:8],axis=-1),axis=1)
    assert chosen.any() and (~chosen).any()
    assert not np.any(configured.is_heading[chosen])
