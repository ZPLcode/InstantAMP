import json

import jax.numpy as jnp
import numpy as np
import pytest

from test_zenbot_online_ground import fake_bank
from tools import prepare_zenbot_physical_training as physical
from tools.prepare_zenbot_scratch_pairs import NativeWorld
from tools.prepare_zenbot_staged_floor_pairs import publish
from tools.prepare_zenbot_support_frames import first_support_frame, sha256, support_frames


def test_first_support_uses_post_action_state_and_bank_clip_order(tmp_path):
    names = ["b.npz", "a.npz"]
    digests = []
    entries = {}
    for n, name in enumerate(names):
        trace = np.tile([0.7, 1.0, 0.5, 0.0, 0.0], (24, 1))
        trace[:2+n, 4] = 0.1
        assert first_support_frame(trace) == 3+n
        with pytest.raises(ValueError, match="never reaches"):
            first_support_frame(trace[:11+n])
        path = tmp_path / name
        np.savez(path, source_clip=name, dt=0.02, physical=trace)
        digests.append(sha256(path))
        entries[name] = {"sha256": digests[-1], "filename": name}
    (tmp_path / "manifest.json").write_text(json.dumps({"trajectories": dict(sorted(entries.items()))}))
    bank = tmp_path / "bank.npz"
    np.savez(bank, clip_names=names, plan_sha256=digests, lengths=[24, 24])
    assert support_frames(bank, tmp_path) == {
        "ground_bank_sha256": sha256(bank), "clip_names": names, "first_support": [3, 4]}
    (tmp_path / names[0]).write_bytes(b"replaced plan")
    with pytest.raises(ValueError, match="changed physical plan"):
        support_frames(bank, tmp_path)


def test_filter_uses_matched_phase_without_changing_trajectory_or_history(monkeypatch):
    world = NativeWorld()
    bank = fake_bank()._replace(settled=jnp.full(4, 13))
    original = physical.floor_targets
    frames = []

    def capture(*args):
        target, kind, phase = original(*args)
        # Real contact matching can move backward across the handoff boundary.
        test_phase = jnp.where(args[-2] % 2 == 0, 1, 3)
        frames.append((np.asarray(kind), np.asarray(test_phase)))
        return target, kind, test_phase

    monkeypatch.setattr(physical, "floor_targets", capture)
    baseline = physical.floor_episodes(world, bank, 0, 701, 8, 5)
    eligible = []
    active = np.ones(8, bool)
    for kind, phase in frames:
        active &= kind == 1
        eligible.extend(phase[active] < 3)
    frames.clear()
    counts = {}
    filtered = physical.floor_episodes(world, bank, 0, 701, 8, 5, stop_after_phase=3, audit=counts)
    assert any(eligible) and not all(eligible)
    for before, after in zip(baseline, filtered, strict=True):
        np.testing.assert_array_equal(before[eligible], after)
    assert counts["cold_rows"] + counts["phase_reset_rows"] == sum(eligible)
    assert counts["min_matched_phase"] == counts["max_matched_phase"] == 1


def test_publication_replaces_the_entire_previous_pair_set(tmp_path):
    previous = tmp_path / "reference_pairs"
    pending = tmp_path / "new_pairs"
    previous.mkdir()
    pending.mkdir()
    for name in ("train.npz", "valid.npz", "checks_v2.json"):
        (previous / name).write_text("old")
        (pending / name).write_text("new")
    publish(pending, previous)
    assert {p.read_text() for p in previous.iterdir()} == {"new"}
    assert {p.read_text() for p in pending.iterdir()} == {"old"}
