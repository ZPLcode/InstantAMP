import dataclasses
import hashlib
import json
from functools import partial
from pathlib import Path
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

from instantamp import amp, nets, optim
from instantamp.sim import Sim
from instantamp.zenbot_source_gait import Curriculum
from instantamp.zenbot_staged_gait import LocomotionPPO, source_configuration
from instantamp.zenbot_staged_ppo import StagePlan, expand_gait_discriminator, train_staged


class Data(NamedTuple):
    qpos: object
    qvel: object
    qacc_warmstart: object

    def replace(self, **kw):
        return self._replace(**kw)


def test_real_stage_one_cpu_initialization(monkeypatch,tmp_path):
    from instantamp import train_zenbot_getup_stand_amp as standing
    monkeypatch.setattr(standing, "Sim", partial(Sim, physics=False))
    cfg=dataclasses.replace(source_configuration(tmp_path),num_envs=4,rollout=24)
    trainer=LocomotionPPO(cfg)
    trainer.sim.dx=Data(jnp.zeros(30),jnp.zeros(29),jnp.zeros(29))
    live,opt,disc=trainer.init()
    assert trainer.gamma==.99 and len(trainer.expert.clip_offsets)==17
    assert trainer.actor_input(live[0]).shape==(4,234)
    assert trainer.critic_input(live[0]).shape[-1]==opt[0]["v"][0]["w"].shape[0]
    assert disc["net"][0]["w"].shape==(3*67,1024)
    assert live[2].shape==(244,4,3,67)
    np.testing.assert_array_equal(live[0].reference_clip,-1)
    np.testing.assert_allclose(live[0].data.qpos[:,2],.69)
    np.testing.assert_allclose(opt[0]["std"],.4)
    assert int(opt[1]["t"])==int(disc["opt"]["t"])==0
    from instantamp.train import save_policy
    path=tmp_path/"initial"
    pi=jax.device_get(opt[0]["pi"])
    save_policy(str(path),{"pi":pi,"avg":pi,"obs_norm":opt[3]["actor"]},{"it":0,"env_steps":0,"train_s":0.})
    # CPU and GPU generate equivalent seeded weights; final float32 multiply/add rounding differs by at most one ULP.
    expected="0dd80bb4aea54c6beb189548d2df080e352c37bab0315c92fa3c740227301386" if jax.default_backend()=="cpu" else "a8feac4a7f16271b83f33b65c91c34156f642f5e887b91a8f964906ba2305f76"
    assert hashlib.sha256(path.with_suffix(".npz").read_bytes()).hexdigest()==expected
    actor,b=trainer.discriminator_examples(jax.random.key(1),live[1])
    assert actor.shape==b.shape==(4,3,67)


def test_expand_preserves_logits_moments_and_norm():
    key=jax.random.key(17)
    d=amp.init(key,3,(9,5),67)
    d["norm"]={k:v+.25 for k,v in d["norm"].items()}
    for m in d["opt"]["leaves"][0]["w"]:
        d["opt"]["leaves"][0]["w"][m]=jnp.arange(201*9,dtype=jnp.float32).reshape(201,9)*.001
    d["opt"]["t"]=jnp.int32(84)
    old=jax.random.normal(key,(4,3,67))
    full=jax.random.normal(key,(4,3,80)).at[:,:,6:73].set(old)
    new=expand_gait_discriminator(d,80)
    np.testing.assert_allclose(amp.score(d["net"],d["norm"],old),amp.score(new["net"],new["norm"],full),atol=1e-6)
    for m in ("m","v"):
        clipped=new["opt"]["leaves"][0]["w"][m].reshape(3,80,9)
        np.testing.assert_array_equal(clipped[:,6:73],d["opt"]["leaves"][0]["w"][m].reshape(3,67,9))
        np.testing.assert_array_equal(clipped[:,:6],0.);np.testing.assert_array_equal(clipped[:,73:],0.)
    assert int(new["opt"]["t"])==84 and new["norm"]["count"]==d["norm"]["count"]


class FakeState(NamedTuple):
    data: Data
    gait_curriculum: Curriculum
    first_command_stage: object


class TinySim:
    def __init__(self,wide):
        self.width=80 if wide else 67
        self.sample_command=lambda key,stage:stage
    def init(self,key):
        n=2; q=jnp.zeros((n,30)).at[:,3].set(1.)
        return FakeState(Data(q,jnp.zeros((n,29)),jnp.zeros((n,29))),Curriculum.empty(n),self.sample_command(key,0))
    def amp_frame(self,state):
        return jnp.zeros((2,self.width))


class TinyTrainer:
    condition_dim=0
    amp_span=amp_frames=3
    extra_rollout_stats=motion_metric_names=()
    def __init__(self,cfg,wide=False):
        self.c,self.sim,self.wide=cfg,TinySim(wide),wide
    actor_input=staticmethod(lambda s: jnp.zeros((2,4)))
    critic_input=staticmethod(lambda s: jnp.zeros((2,6)))
    fix_condition_norm=staticmethod(lambda d:d)
    def init(self):
        assert not self.wide,"The second stage must never initialize an actor/discriminator"
        ac={"pi":nets.mlp_init(jax.random.key(3),[4,2]),"v":nets.mlp_init(jax.random.key(5),[6,1]),"std":jnp.ones(2)}
        adam=optim.init(ac,jax.tree.map(lambda _:False,ac))
        state=self.sim.init(jax.random.key(1))
        live=(state,jnp.zeros((2,3,67)),jnp.zeros((244,2,3,67)),jnp.int32(0))
        return live,(ac,adam,jnp.float32(.0001),{"actor":nets.rn_init(4),"critic":nets.rn_init(6)}),amp.init(jax.random.key(8),3,(5,2),67)
    def collect(self,live,ac,disc,key,norms):
        state,*tail=live
        curriculum=state.gait_curriculum._replace(stage=jnp.int32(2))
        state=state._replace(gait_curriculum=curriculum)
        batch=jnp.array([jax.random.uniform(key),state.first_command_stage],dtype=jnp.float32)
        return (state,*tail),batch,jnp.arange(7,dtype=jnp.float32)
    def learn(self,opt,disc,batch,replay,written,key,train_actor):
        ac,adam,lr,norms=opt
        adv=jnp.float32(1)+jax.random.uniform(key)+batch[0]
        ac,adam=optim.step(ac,jax.tree.map(lambda x:jnp.full_like(x,adv),ac),adam,jax.tree.map(lambda _:False,ac),lr)
        disc={**disc,"opt":{**disc["opt"],"t":disc["opt"]["t"]+1}}
        norms=jax.tree.map(lambda x:x+.25,norms)
        return (ac,adam,lr,norms),disc,jnp.zeros(6)


def test_one_initialization_and_continuous_clocks_prng_and_adam(tmp_path):
    a=dataclasses.replace(source_configuration(tmp_path),num_envs=2,rollout=2,save_every=2,log_every=1)
    b=dataclasses.replace(a,rollout=3)
    boundaries=[]; observed=[]
    class Second(TinyTrainer):
        def init_stage_aux(self,opt,boundary):
            assert boundary.actor_checkpoint.exists() and boundary.learner_archive.exists()
            boundaries.append((boundary,int(opt[1]["t"])))
            return 0
        def before_stage_collect(self,opt,aux,previous, key,absolute,local):
            observed.append((absolute,local,None if previous is None else float(previous),aux))
            return opt,aux+1
        def retain_stage_rollout(self,batch,live,key,absolute,local):
            return batch[1]
    def create(prev,cfg):
        return Second(cfg,True)
    opt,disc,key=train_staged(StagePlan(a,b,2,4),create,make_stage1=TinyTrainer)
    assert observed==[(3,1,None,0),(4,2,2.,1)]
    assert len(boundaries)==1 and boundaries[0][1]==2
    record=json.loads((tmp_path/"transition_000002.json").read_text())
    assert record["actor_adam_steps"]==record["discriminator_adam_steps"]==2
    assert record["env_steps"]==8 and record["curriculum_stage"]==2
    assert hashlib.sha256(boundaries[0][0].learner_archive.read_bytes()).hexdigest()==record["sha256"]
    with np.load(boundaries[0][0].learner_archive) as saved:
        assert "optimizer/0/pi/0/w" in saved and "discriminator/opt/leaves/0/w/m" in saved
        np.testing.assert_array_equal(saved["key"],record["prng_key"])
    assert int(opt[1]["t"])==int(disc["opt"]["t"])==4
    expected=jax.random.PRNGKey(43)
    for step in range(1,5):
        if step==3: expected,_=jax.random.split(expected)
        expected,_,_=jax.random.split(expected,3)
    np.testing.assert_array_equal(key,expected)
    log=[json.loads(x) for x in (tmp_path/"log.jsonl").read_text().splitlines()]
    assert [(x["it"],x["stage_it"],x["env_steps"]) for x in log]==[(1,1,4),(2,2,8),(3,1,14),(4,2,20)]
