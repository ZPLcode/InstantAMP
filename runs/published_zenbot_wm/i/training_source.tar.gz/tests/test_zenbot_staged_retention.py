"""The stage transition uses the deployed actor math and an independent pair of raw-action Huber losses."""

import unittest

import jax
import jax.numpy as jnp
import numpy as np
from instantamp import nets, optim
from instantamp.zenbot_motion_train_obs import motion_train_actor_mean
from instantamp.zenbot_staged_retention import broaden, fit_step, init_optimizer
from tools.collect_zenbot_staged_retention import sense_and_act
from instantamp.zenbot_motion_train_obs import advance_sensors


class RetentionTest(unittest.TestCase):
    def setUp(self):
        self.actor = nets.mlp_init(jax.random.key(32), [234, 16, 23])
        rng = np.random.default_rng(1784)
        self.norm = {
            "mean": jnp.asarray(rng.normal(0, 0.12, 234), jnp.float32),
            "var": jnp.asarray(rng.uniform(0.1, 1.3, 234), jnp.float32),
        }
        self.obs = jnp.asarray(rng.normal(size=(256, 234)), jnp.float32)
        self.raw = jnp.asarray(rng.normal(size=(256, 23)), jnp.float32)

    def test_matches_independent_adam_and_huber(self):
        mask = jax.tree.map(lambda _: False, self.actor)
        optimizer = init_optimizer(self.actor)
        base = jax.tree.map(np.asarray, self.actor)
        theta, moments, metrics = fit_step(
            self.actor, optimizer, self.norm, self.obs[:128], self.raw[:128], self.obs[128:], self.raw[128:]
        )

        def reference(p):
            e = jnp.abs(motion_train_actor_mean(p, self.norm, self.obs) - self.raw)
            row = jnp.where(e < 1.0, 0.5 * e**2, e - 0.5).mean(1)
            return (row[:128].mean() + 256.0 * row[128:].mean()) / 257.0

        loss, g = jax.value_and_grad(reference)(self.actor)
        g, _ = optim.clip_by_global_norm(g, 1.0)
        expected, state = optim.step(self.actor, g, optim.init(self.actor, mask), mask, 1e-4)
        for a, b in zip(jax.tree.leaves((theta, moments)), jax.tree.leaves((expected, state))):
            np.testing.assert_allclose(a, b, atol=3e-7, rtol=1e-5)
        np.testing.assert_allclose(metrics["supervised_loss"], loss, rtol=1e-6)
        self.assertEqual(int(optimizer["t"]), 0)
        for before, after in zip(jax.tree.leaves(base), jax.tree.leaves(self.actor)):
            np.testing.assert_array_equal(before, after)

    def test_broaden_preserves_unsaturated_actor_and_count(self):
        inputs = jnp.clip(self.obs, -1.0, 1.0)
        stat = dict(self.norm, count=jnp.float32(4096))
        out, after = broaden(self.actor, stat, self.obs * 3.0 + 2.0)
        ref = motion_train_actor_mean(self.actor, stat, inputs)
        new = motion_train_actor_mean(out, after, inputs)
        np.testing.assert_allclose(ref, new, rtol=1e-5, atol=1e-5)
        self.assertIs(after["count"], stat["count"])
        self.assertIs(out[1], self.actor[1])
        same, norm = broaden(self.actor, stat, self.obs, fraction=0)
        self.assertIs(same, self.actor)
        self.assertIs(norm, stat)

    def test_unmodified_targets_give_zero_gradient(self):
        same = motion_train_actor_mean(self.actor, self.norm, self.obs)
        theta, state, result = fit_step(
            self.actor,
            init_optimizer(self.actor),
            self.norm,
            self.obs[:128],
            same[:128],
            self.obs[128:],
            same[128:],
        )
        self.assertEqual(float(result["supervised_loss"]), 0.0)
        for before, after in zip(jax.tree.leaves(self.actor), jax.tree.leaves(theta)):
            np.testing.assert_array_equal(before, after)

    def test_observation_and_stored_means_match_motion_train_per_world(self):
        batch = 4
        rng = np.random.default_rng(31)
        flag = jnp.array([False, True, True, False])
        merged = None
        states = [None, None]
        for t in range(4):
            vals = [jnp.asarray(rng.normal(size=(batch, n)), jnp.float32) for n in (6, 3, 23, 23, 23)]
            fresh = jnp.full(batch, t == 0)
            key = jax.random.key(70 + t)
            merged, obs, label = sense_and_act(self.actor, self.norm, merged, *vals, fresh, flag, key)
            for i, noisy in enumerate((False, True)):
                states[i] = advance_sensors(states[i], *vals, fresh, key, corrupt=noisy)
                ref = states[i].observation()
                use = np.asarray(flag) == noisy
                np.testing.assert_allclose(np.asarray(obs)[use], np.asarray(ref)[use], atol=1e-6)
                expected = motion_train_actor_mean(self.actor, self.norm, ref)
                np.testing.assert_allclose(np.asarray(label)[use], np.asarray(expected)[use], atol=2e-6)


if __name__ == "__main__":
    unittest.main()
