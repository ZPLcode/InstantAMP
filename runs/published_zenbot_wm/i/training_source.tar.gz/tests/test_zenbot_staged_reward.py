import dataclasses
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import amp
from instantamp import train_zenbot_staged as cli
from instantamp.train_zenbot_scratch import ScratchAMP
from instantamp.zenbot_staged_gait import source_configuration
from instantamp.zenbot_staged_recovery import StagedRecovery, recovery_configuration


@pytest.mark.parametrize("terms", [
    ("action_rate_l2", "supported_hold", "joint_pos_limits"),
    ("joint_pos_limits", "supported_hold", "action_rate_l2"),
])
def test_scales_only_the_floor_reward_except_its_blended_action_rate(tmp_path, terms):
    trainer = object.__new__(StagedRecovery)
    trainer.sim = SimpleNamespace(J=23, terms=terms)
    trainer.c = recovery_configuration(tmp_path)
    trainer.amp_stride = 1
    trainer.condition_dim = 3
    width = 95
    trainer.standing_target = jnp.zeros(width)
    motion = jnp.zeros((6, 3, width))
    disc = amp.init(jax.random.key(12), 3, frame_dim=width+3)
    rate = jnp.array([-.12, -.17, -.31, -.4, -.025, -.105])
    # Rows include ordinary floor motion, an expired floor episode, the recovery-to-stand step,
    # a supported standing timeout, locomotion and a locomotion fall.
    active = jnp.array([False, False, False, True, True, True])
    hold = jnp.array([0., 0., .16, 0., 0., 0.])
    cost = jnp.array([-.31, -.27, -.04, 0., 0., 0.])
    parts = {"action_rate_l2": rate, "supported_hold": hold, "joint_pos_limits": cost}
    transition = SimpleNamespace(
        parts=jnp.stack([parts[name] for name in terms], -1), reward=rate+hold+cost,
        stats=dict(source_gait_active=active, gait_ready=jnp.array([False,False,True,True,True,False]),
                   source_standing=jnp.array([True,True,True,True,False,False]),
                   stand_blend=jnp.array([0.,0.,1.,1.,0.,0.]), min_foot_load_bw=jnp.array([0.,0.,.45,.48,0.,0.]),
                   source_velocity_score=jnp.array([0.,0.,1.,3.5,2.,0.]), source_tilt_l2=jnp.array([1.,1.,0.,0.,.4,.9])),
        terminated=jnp.array([False,True,False,False,False,True]),
        truncated=jnp.array([False,False,False,True,False,False]), diverged=jnp.zeros(6, bool),
    )
    style = trainer.source_motion(disc, motion, transition)[0]
    assert style[1] == 0
    original = jax.jit(lambda s: ScratchAMP.blend_reward(trainer, transition, s))(style)
    default = jax.jit(lambda s: trainer.blend_reward(transition, s))(style)
    np.testing.assert_array_equal(default, original)
    trainer.c = dataclasses.replace(trainer.c, floor_reward_scale=.05)
    actual = jax.jit(lambda s: trainer.blend_reward(transition, s))(style)
    np.testing.assert_array_equal(np.asarray(actual)[active], np.asarray(original)[active])
    expected = .5*rate + .05*.5*(hold+cost+style)
    np.testing.assert_allclose(np.asarray(actual)[~active], np.asarray(expected)[~active], rtol=2e-6)
    trainer.c = dataclasses.replace(trainer.c, floor_reward_scale=0.)
    only_rate = trainer.blend_reward(transition, style)
    np.testing.assert_array_equal(np.asarray(only_rate)[~active], np.asarray(.5*rate)[~active])


def test_recipe_metadata_and_continuation_inherit_the_requested_scale(tmp_path, monkeypatch):
    run = tmp_path/"train"
    (run/"reference_pairs").mkdir(parents=True)
    for path in (run/"ground_bank.npz", run/"support_frames.json", run/"reference_pairs/train.npz"):
        path.write_bytes(b"test fixture")
    monkeypatch.chdir(tmp_path)
    assert not hasattr(source_configuration(run), "floor_reward_scale")
    assert recovery_configuration(run).floor_reward_scale == 1.
    plans = []
    def record(plan, factory, **kwargs):
        plans.append(plan)
    monkeypatch.setattr(cli, "train_staged", record)
    monkeypatch.setattr(cli, "continue_staged", record)
    def invoke(*flags):
        monkeypatch.setattr(sys, "argv", ["train_zenbot_staged", "--run-dir", str(run), *flags])
        cli.main()
    invoke("--floor-reward-scale", ".05", "--stop-at-boundary")
    assert json.loads((run/"recipe.json").read_text())["floor_reward_scale"] == .05
    config = dataclasses.asdict(plans[-1].second)
    assert config["floor_reward_scale"] == .05
    (run/"config.json").write_text(json.dumps(dict(second=config)))
    invoke("--continue-at-boundary")
    assert plans[-1].second.floor_reward_scale == .05
    (run/"config.json").write_text('{"second":{}}')
    invoke("--continue-at-boundary")
    assert plans[-1].second.floor_reward_scale == 1.


@pytest.mark.parametrize("scale", [-.001, 1.01, float("nan"), float("inf")])
def test_staged_scale_rejects_invalid_values(tmp_path, scale):
    with pytest.raises(ValueError, match="floor_reward_scale"):
        recovery_configuration(tmp_path, floor_reward_scale=scale)


@pytest.mark.parametrize("explicit", [False, True])
def test_one_command_recipe_passes_scale_only_to_the_joint_trainer(tmp_path, explicit):
    root = Path(__file__).resolve().parents[1]
    script = root/"tools/recipes/train_zenbot_staged_scratch.sh"
    recorder = tmp_path/"mock-python"
    recorder.write_text(f"#!{sys.executable}\n" + """import json, os, sys
args = sys.argv[1:]
with open(os.environ["CAPTURE"], "a") as log:
    print(json.dumps(args), file=log)
if args[:2] == ["-m", "instantamp.train_zenbot_staged"]:
    sys.exit(43)
""")
    recorder.chmod(0o755)
    run = tmp_path/"fresh run"
    capture = tmp_path/"calls.jsonl"
    extra = ["--floor-reward-scale", ".05"] if explicit else []
    cmd = ["bash", str(script), str(run), *extra]
    result = subprocess.run(cmd, env={**os.environ, "SIM_PYTHON":str(recorder), "CAPTURE":str(capture)},
                            capture_output=True, text=True)
    assert result.returncode == 43, result.stderr
    calls = [json.loads(row) for row in capture.read_text().splitlines()]
    assert calls[-1] == ["-m", "instantamp.train_zenbot_staged", "--run-dir", str(run), *extra]
    assert all("--floor-reward-scale" not in call for call in calls[:-1])
