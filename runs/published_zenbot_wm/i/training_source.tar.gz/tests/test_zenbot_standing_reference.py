from types import SimpleNamespace

import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import amp, env, zenbot
from instantamp.train_zenbot_getup_stand_amp import RiseStandAMP, Settings, standing_pose_match


def test_reference_bonus_rewards_a_supported_return_to_the_standing_pose(monkeypatch):
    # Native AMP pose channels come before height, gravity, landmark XY and clearances.
    angle = 9
    height = angle + 2 * len(zenbot.DOF) + 3 * len(zenbot.KEY_BODIES)
    expert = jnp.zeros(height + 22).at[5].set(1.).at[height].set(.69)
    displaced = expert.at[angle + zenbot.DOF.index("right_shoulder_yaw")].set(1.8)
    displaced = displaced.at[angle + zenbot.DOF.index("left_knee")].set(.5).at[height].set(.62)
    displaced = displaced.at[3:6].set(jnp.array([.3, 0., np.sqrt(.91)]))
    for frame in (expert.at[3:6].set(displaced[3:6]), expert.at[height].set(.62),
                  expert.at[angle].set(.5), expert.at[angle + 17].set(1.8)):
        assert standing_pose_match(frame, expert) < standing_pose_match((frame + expert) / 2., expert) < 1.
    trainer = RiseStandAMP.__new__(RiseStandAMP)
    trainer.condition_dim = 1
    trainer.c = SimpleNamespace(stand_reference_weight=8.)
    trainer.standing_target = expert
    monkeypatch.setattr(amp, "recovery_style", lambda disc, windows, **kwargs: jnp.zeros(len(windows)))
    frames = jnp.stack((expert, expert, expert, expert, displaced))
    windows = jnp.repeat(frames[:, None], 10, axis=1)
    transition = SimpleNamespace(stats={
        "stand_blend": jnp.array([0., 1., .5, 1., 1.]),
        "min_foot_load_bw": jnp.array([.5, 0., .5, .5, .5]),
    })
    reward, replay, metrics = trainer.rollout_motion(None, windows, transition)
    np.testing.assert_allclose(reward[:4], env.DT * 8. * np.array([0., 0., .5, 1.]))
    assert 0. < reward[4] < reward[3]
    assert np.isclose(metrics[-1], reward.mean())
    np.testing.assert_array_equal(replay[..., :-1], windows)


@pytest.mark.parametrize("weight", [-1., float("nan")])
def test_reference_weight_is_finite_and_nonnegative(weight):
    with pytest.raises(ValueError, match="stand_reference_weight"):
        RiseStandAMP.validate(Settings(stand_reference_weight=weight))
