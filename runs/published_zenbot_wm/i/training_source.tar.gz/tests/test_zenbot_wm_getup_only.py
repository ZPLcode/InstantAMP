"""Get-up-only WM collection, phase clocks, real motors and imagined commands."""
from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import buffer, env, zenbot
from instantamp.sim import Sim
from instantamp.train import InstantAMP
from test_zenbot_motion_train_wm_sim import CpuState, native_substeps, simulator


def floor_sim(n, paired, stance_share=0., min_rise_score=0.):
    sim = Sim(n, robot=zenbot.MIXED_TASK, physics=False, zenbot_motion_train_wm=True,
              zenbot_wm_getup_only=True, zenbot_wm_reference_training=paired, wm_stance_start_share=stance_share,
              wm_min_rise_score=min_rise_score,
              walk_dir="unused_getup_gait_bank", reset_floor=0., prob_shove=1., push=True,
              randomize_world=False, obs_noise=False)
    sim.dx = CpuState(jnp.zeros(30), jnp.zeros(29), jnp.zeros(29))
    return sim


def test_every_world_starts_on_the_floor_without_the_gait_reset_bank():
    sim = floor_sim(1024, paired=False)
    assert sim.walk == {} and not np.any(sim.wm_gait_worlds)
    assert sim.reset_floor == 1. and sim.prob_shove == 0. and not sim.push
    state, source = sim._fresh(jax.random.key(314), sim.world(jax.random.key(4)), return_source=True)
    q, v, up = map(np.asarray, state)
    clip, frame = map(np.asarray, source)
    assert (clip >= 0).all() and not up.any()
    cold = frame == 0
    assert .44 < cold.mean() < .56
    for selected in (cold, ~cold):
        assert set(clip[selected]) == set(range(11))
    np.testing.assert_array_equal(v[cold, 2:], 0.)
    ix = np.asarray(sim.wm_reference.offsets)[clip[~cold]] + frame[~cold]
    np.testing.assert_array_equal(q[~cold], np.asarray(sim.wm_reference.qpos)[ix])
    np.testing.assert_array_equal(v[~cold], np.asarray(sim.wm_reference.qvel)[ix])


def test_real_resampling_refall_and_imagined_start_stay_getup_only():
    sim = floor_sim(16, paired=True)
    s = sim.init(jax.random.key(27))
    assert s.down.all() and not s.was_up.any() and (s.reference_clip >= 0).all()
    np.testing.assert_array_equal(s.t, 0)
    np.testing.assert_array_equal(s.cmd.vel, 0.)
    np.testing.assert_array_equal(s.c_obs, 0.)
    assert s.motion_train_sensors.observation().shape == (16,234)
    assert np.any(np.all(s.delay_steps==0,axis=1)) and np.any(np.all(s.delay_steps>=3,axis=1))
    # All were previously upright. With no push, their sampled floor pose must continue as a new recovery.
    s = s._replace(was_up=jnp.ones(sim.N,bool), recovery_left=jnp.zeros(sim.N,jnp.int32),
                   cmd=s.cmd._replace(time_left=jnp.full(sim.N,.001)),
                   push_at=jnp.ones(sim.N,jnp.int32), push_t=jnp.zeros(sim.N,jnp.int32))
    sim.physics=lambda *args:native_substeps(sim,*args)
    zero=jnp.zeros((sim.N,23))
    post,tr=sim.step(s,zero)
    assert not tr.truncated.any() and not tr.terminated.any() and int(tr.stats["pushes"])==0
    np.testing.assert_array_equal(post.data.qpos,tr.qpos1)
    np.testing.assert_array_equal(post.data.qvel,tr.qvel1)
    np.testing.assert_array_equal(post.t,1)
    np.testing.assert_array_equal(post.cmd.vel,0.)
    np.testing.assert_array_equal(post.c_obs,0.)
    # The same sampler is used after a ten-second imagined command expires and when choosing an imagination start.
    expired=sim.sample_wm_command(jax.random.key(9),53)._replace(time_left=jnp.zeros(53))
    gathered=env.tick(expired,jax.random.key(1),sample=lambda k:sim.sample_wm_command(k,53))
    assert gathered.is_standing.all() and not gathered.is_heading.any()
    np.testing.assert_array_equal(gathered.vel,0.)
    xs=InstantAMP.__new__(InstantAMP)
    xs.B_im=32
    xs.sim,xs.amp,xs.ppo,xs.recovery_clock=sim,False,False,False
    xs.cfg=SimpleNamespace(motion_train_wm=True,wm_reference_training=True,g1_style=False,
                            recovery_amp_seconds=4.,imag_down=0.,cmd_fresh=1.)
    record,_=xs.record(s,post,tr,zero,zero)
    flat=buffer.flatten(dict(record,ok=jnp.ones(sim.N)))
    replay=buffer.add(buffer.init(1,flat,full_precision_obs=True),flat)
    imagined=xs.sample_starts(replay,jax.random.key(7))
    np.testing.assert_array_equal(imagined["cmd"].vel,0.)
    np.testing.assert_array_equal(imagined["c_obs"],0.)
    np.testing.assert_array_equal(imagined["obs"][:,18:27],0.)
    assert (imagined["reference_clip"]>=0).all()


def test_stance_starts_supply_real_upright_negatives_with_zero_commands():
    sim = floor_sim(512, paired=True, stance_share=.25)
    s = sim.init(jax.random.key(42))
    stand = np.asarray(s.was_up)
    cold = np.asarray(s.reference_start == 0)
    assert .18 < stand.mean() < .32 and .40 < cold.mean() < .60
    assert not (cold & stand).any()
    assert np.all(np.asarray(s.reference_start)[stand] > 490)
    assert np.all(np.asarray(s.recovery_left)[stand] == 0)
    np.testing.assert_array_equal(s.c_obs, 0.)
    np.testing.assert_array_equal(s.t, 0)
    assert len(np.unique(s.episode_limit)) > 10


def test_imagined_openings_are_real_valid_transitions_and_fall_back_to_uniform():
    tpl = {"s_qpos": jnp.zeros((4, 30)), "t": jnp.arange(4), "ok": jnp.array([1., 0., 1., 1.])}
    replay = buffer.init(6, tpl)
    for tick in range(6):
        replay = buffer.add(replay, {**tpl, "t": jnp.arange(4) + 4 * tick})
    samples = buffer.sample_starts(replay, jax.random.key(2), 128, reset_frac=1., reset_window=4)
    assert set(np.asarray(samples["t"]).tolist()) == {0, 2, 3}
    samples = buffer.sample_starts(replay, jax.random.key(2), 128, reset_frac=1., reset_window=0)
    assert np.all(samples["ok"] == 1) and np.any(samples["t"] > 4)


def test_early_resets_preserve_cold_midrise_and_stand_worlds_across_episodes():
    sim = floor_sim(128, paired=True, stance_share=.25, min_rise_score=.55)
    world = sim.world(jax.random.key(1))
    for seed in (2, 3, 4):
        (q, v, up), (clip, frame) = sim._fresh(jax.random.key(seed), world, return_source=True)
        np.testing.assert_array_equal(up, sim.wm_start_quantiles >= .75)
        np.testing.assert_array_equal(frame == 0, sim.wm_start_quantiles < .5)
        for group in (np.arange(0, 128, 2), np.arange(1, 128, 2)):
            assert int(up[group].sum()) == 16 and int((frame[group] == 0).sum()) == 32


def test_getup_only_is_opt_in():
    with pytest.raises(ValueError,match="Motion Train world-model"):
        Sim(1,robot=zenbot.MIXED_TASK,physics=False,zenbot_wm_getup_only=True)
    joint=simulator(n=32,zenbot_wm_reference_training=True,zenbot_wm_getup_only=False)
    assert "command_rows" in joint.walk and joint.wm_gait_worlds.sum()==8
    s=joint.init(jax.random.key(14))
    assert np.any(s.c_obs!=0.) and s.down.any() and not s.down.all()
