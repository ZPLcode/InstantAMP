import hashlib
import json
from pathlib import Path
import sys

import pytest

from tools import monitor_zenbot_scratch as monitor


def sidecar(run, name, it, contents):
    ckpt = run / "ckpt"
    ckpt.mkdir(exist_ok=True)
    path = ckpt / f"{name}.npz"
    path.write_bytes(contents)
    path.with_suffix(".json").write_text(json.dumps({"it":it}))
    return path


def test_available_uses_saved_iterations_and_caches_cpu_results(tmp_path, monkeypatch):
    first = sidecar(tmp_path, "0007", 1000, b"1000 model")
    sidecar(tmp_path, "003000", 250, b"other model")  # The digits do not encode the training iteration.
    partial = tmp_path / "ckpt/new.json"
    partial.write_text('{"it":')
    partial.with_suffix(".npz").write_bytes(b"unpublished")
    calls = []

    def record(args, *, env, check):
        assert env["JAX_PLATFORMS"] == "cpu" and env["CUDA_VISIBLE_DEVICES"] == "" and check
        policy = Path(args[3])
        assert args[-2:] == ["--seeds", "42"]
        out = Path(args[args.index("--out")+1])
        calls.append(policy)
        out.write_text(json.dumps({"sha256":hashlib.sha256(policy.read_bytes()).hexdigest(),"seeds":[42]}))

    monkeypatch.setattr(monitor.subprocess, "run", record)
    monkeypatch.setattr(sys, "argv", ["monitor", str(tmp_path), "--wm", "--available"])
    monitor.main()
    assert calls == [first]
    second = sidecar(tmp_path, "0010", 3000, b"3000 model")
    third = sidecar(tmp_path, "0018", 6000, b"6000 model")
    last = sidecar(tmp_path, "0020", 10000, b"10000 model")
    monitor.main()
    assert calls == [first, second, third, last]
    monitor.main()
    assert calls == [first, second, third, last]
    assert {p.name for p in (tmp_path / "milestones").glob("*.json")} == {
        "001000.json", "003000.json", "006000.json", "010000.json"}
    assert not (tmp_path / "milestones/010000_five_seeds.json").exists()


def test_ambiguous_wm_iteration_is_an_error(tmp_path):
    sidecar(tmp_path, "0003", 6000, b"first")
    sidecar(tmp_path, "0007", 6000, b"second")
    with pytest.raises(ValueError, match="Multiple policy sidecars report iteration 6000"):
        monitor.wm_checkpoint(tmp_path, 6000)


def test_live_monitor_polls_and_existing_ppo_final_still_gets_full_seeds(tmp_path, monkeypatch):
    calls = []

    def publish(_):
        sidecar(tmp_path, "0004", 3000, b"published")

    monkeypatch.setattr(monitor.time, "sleep", publish)
    monkeypatch.setattr(monitor, "evaluate", lambda ckpt,out,seeds,**opts: calls.append((ckpt.name,tuple(seeds))))
    monkeypatch.setattr(sys, "argv", ["monitor",str(tmp_path),"--wm","--milestones","3000"])
    monitor.main()
    assert calls == [("0004.npz",(42,))]
    sidecar(tmp_path, "010000", 10000, b"ppo format")
    monkeypatch.setattr(sys, "argv", ["monitor",str(tmp_path),"--milestones","10000"])
    monitor.main()
    assert calls[-2:] == [("010000.npz",(42,)),("010000.npz",monitor.FINAL_SEEDS)]
