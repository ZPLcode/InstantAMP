from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import nets, zenbot
from instantamp.sim import Sim
from instantamp.train import InstantAMP
from instantamp.zenbot_wm_motion_replay import PhysicalMotionReplay


@pytest.fixture(scope="module")
def replay():
    return PhysicalMotionReplay()


def test_four_substeps_use_recorded_actions_and_group_delays(replay):
    assert len(replay.files) == 11
    for clip, file in enumerate(replay.files):
        with np.load(file) as motion:
            raw = motion["raw_action"]
            history = np.concatenate((motion["raw_action_history"], raw))
            lag = motion["delays"][zenbot.GROUP]
            expected = np.stack([
                zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * np.where(
                    tick >= lag, raw, np.where(tick + 4 >= lag, history[1:-1], history[:-2]))
                for tick in range(4)
            ], axis=1)
            np.testing.assert_allclose(replay.targets[clip].reshape(-1, 4, 23), expected, rtol=0., atol=2.e-7)
            np.testing.assert_array_equal(replay.contexts[clip], np.r_[.9, 0., motion["delays"], 0.].astype("f4"))
            np.testing.assert_array_equal(replay.qpos[clip], motion["qpos"].astype("f4"))
            np.testing.assert_array_equal(replay.qvel[clip], motion["qvel"].astype("f4"))


def test_jitted_windows_cover_all_rises_and_stances_without_crossing_clips(replay):
    batch = jax.jit(lambda key: replay.sample_windows(key, 88, 8))(jax.random.key(137))
    batch = jax.device_get(batch)
    assert set(batch) == {"s_qpos", "s_qvel", "s1_qpos", "s1_qvel", "target", "xi", "mask"}
    np.testing.assert_array_equal(batch["mask"], np.ones((88, 8), np.float32))
    q, v, pd, context = map(np.asarray, (replay.qpos, replay.qvel, replay.targets, replay.contexts))
    state = np.concatenate((q, v), axis=-1)
    lookup = {value.tobytes(): (clip, t) for clip, trajectory in enumerate(state) for t, value in enumerate(trajectory)}
    counts = np.zeros((len(q), 2), int)
    for row in range(88):
        first = np.r_[batch["s_qpos"][row, 0], batch["s_qvel"][row, 0]]
        clip, t = lookup[first.tobytes()]
        counts[clip, int(t >= replay.stance_start[clip])] += 1
        for name, source in (("qpos", q), ("qvel", v)):
            np.testing.assert_array_equal(batch["s_" + name][row], source[clip, t:t+8])
            np.testing.assert_array_equal(batch["s1_" + name][row], source[clip, t+1:t+9])
        np.testing.assert_array_equal(batch["target"][row], pd[clip, t:t+8])
        np.testing.assert_array_equal(batch["xi"][row], np.broadcast_to(context[clip], (8, 8)))
    np.testing.assert_array_equal(counts, np.full((11, 2), 4))
    with pytest.raises(ValueError, match="window"):
        replay.sample_windows(jax.random.key(1), 1, replay.max_window + 1)


def test_measured_windows_train_the_same_open_loop_wm_loss(replay):
    trainer = InstantAMP.__new__(InstantAMP)
    trainer.sim = Sim(1, robot=zenbot.MIXED_TASK, physics=False, zenbot_motion_train_wm=True)
    trainer.cfg = SimpleNamespace(mm_bf16="none")
    trainer.err_floor = jnp.full((58,), .01)
    wm, buffers = nets.wm_init(jax.random.key(71), 167, 58, (16, 16))
    window = replay.sample_windows(jax.random.key(72), 4, 8)
    (loss, last), grads = jax.jit(jax.value_and_grad(trainer.wm_loss, has_aux=True))(wm, buffers, window)
    assert np.isfinite(loss) and loss > 0 and last.shape == (4,)
    leaves = jax.tree.leaves(grads)
    assert all(np.isfinite(leaf).all() for leaf in leaves)
    assert any(np.any(leaf) for leaf in leaves)
