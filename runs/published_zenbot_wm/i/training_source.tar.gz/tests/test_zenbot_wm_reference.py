import hashlib
from types import SimpleNamespace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import env, nets, zenbot
from instantamp.rot import quat_to_mat
from instantamp.sim import Sim, unflatten
from instantamp.train import InstantAMP, parse
from instantamp.zenbot_motion_train_obs import advance_sensors
from instantamp.zenbot_wm_reference import PhysicalRecoveryReference, SETTLE_TICKS


def landmarks(pos, rotation, joints):
    del rotation
    offsets = jnp.array([[.1, .1, -.5], [.1, -.1, -.5], [0., .1, -.3],
                         [0., -.1, -.3], [.2, .2, .1], [.2, -.2, .1]])
    return pos[..., None, :] + offsets + .05 * joints[..., :6, None]


@pytest.fixture
def reference(tmp_path):
    source, physical = tmp_path / "source", tmp_path / "physical"
    source.mkdir()
    physical.mkdir()
    for i in range(2):
        name = ("b.npz", "a.npz")[i]
        path = source / name
        np.savez(path, frame=np.array([i]))
        n = 111
        q = np.zeros((n, 30))
        q[:, 2] = np.minimum(.35 + np.arange(n) * .009, .68)
        q[:, 3] = 1.
        q[:, 7:] = zenbot.DEFAULT_Q + (np.arange(n)[:, None] * .007 + i)
        post = np.zeros((n - 1, 5))
        post[:, :2] = np.column_stack((q[1:, 2], np.ones(n-1)))
        post[29:, 2] = 1.
        # No action or policy field exists in this fixture.
        np.savez(physical / f"{i}.npz", qpos=q, qvel=np.zeros((n,29)), physical=post,
                 source_clip=name, source_frame=0, dt=env.DT, external_assist_newtons=0.,
                 source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return PhysicalRecoveryReference(physical, source, landmarks)


def test_physical_clock_selection_and_empty_labels(reference):
    r = reference
    assert r.clip_names == ("a.npz", "b.npz")
    np.testing.assert_array_equal(r.first_support, [30, 30])
    assert r.qpos.shape == (222, 30) and r.qvel.shape == (222, 29)
    clip = jnp.zeros(7, int).at[1].set(-1)
    cutoff = 30 + SETTLE_TICKS
    frame = jnp.array([30, 30, 30, 30, cutoff+1, cutoff, 30])
    start = jnp.array([17, 0, 6, 5, 0, 0, -1])
    active = jnp.array([1, 1, 0, 1, 1, 1, 1], bool)
    fell = jnp.array([0, 0, 0, 1, 0, 0, 0], bool)
    poses = r.poses[r.offsets[0]+frame]
    np.testing.assert_array_equal(r.tracked_score(poses, clip, start, frame-start, active, fell),
                                  [1., 0., 0., 0., 0., 1., 0.])
    held_score = r.tracked_score(r.poses[0], 0, 0, 32, True, False)
    assert held_score < .8


def test_reference_reward_is_same_in_real_and_imagined_label_paths(reference, monkeypatch):
    r = reference
    n, horizon = 2, 5
    sim = Sim.__new__(Sim)
    sim.robot, sim.recovery, sim.mixed = zenbot, False, True
    sim.zenbot_motion_train_wm = sim.zenbot_wm_reference_training = True
    sim.wm_reference, sim.reference = r, None
    sim.noisy_obs, sim.recovery_amp_steps, sim.episode_steps = False, 200, 400
    sim.key_positions = landmarks
    sim.weights = {"motion_reference": 5.}
    sim.terms = tuple(sim.weights)
    sim.q_soft = jnp.tile(jnp.array([-3., 3.]), (23, 1))
    zeros = jnp.zeros(n)
    sim.view_state = lambda s: SimpleNamespace(height=s[0][:,2], soles=jnp.zeros((n,2)), clearance=jnp.ones((n,2)),
        kin=env.Kin(s[1], s[2], s[3], jnp.zeros((n,2,3))))
    sim.soft_contact = lambda soles: jnp.zeros((n, 2))
    xs = InstantAMP.__new__(InstantAMP)
    xs.sim, xs.B_im, xs.J, xs.recovery_clock, xs.ppo = sim, n, 23, False, False
    xs.cfg = SimpleNamespace(motion_train_wm=True, wm_reference_training=1, recovery_amp_seconds=4.,
                  mm_bf16="none", horizon=horizon, imag_unroll=1, imag_remat="none", gamma=1.,
                  g1_style=False, num_envs=n)
    xs.act = lambda pi,norm,obs,previous,out_bf16=False: jnp.zeros((n,23))
    xs.termination = lambda clr: zeros
    xs.termination_down = lambda *args: zeros
    q = jnp.stack((r.qpos[10],r.qpos[10]))
    v = jnp.zeros((n,29))
    S = unflatten(q,v)
    cmd = sim.sample_wm_command(jax.random.key(41), n)
    prev = jnp.zeros((n,23))
    sensors = advance_sensors(None, jnp.tile(jnp.array([0.,0.,0.,0.,0.,-1.]),(n,1)),
                            jnp.zeros((n,3)), q[:,7:], v[:,6:], prev, jnp.ones(n,bool), jax.random.key(2),False)
    # Only the first world was born on a paired physical trajectory. It crosses upright, then falls.
    state = SimpleNamespace(cmd=cmd, was_up=jnp.zeros(n,bool), c_obs=jnp.zeros((n,3)), t=jnp.zeros(n,int),
                            motion_train_sensors=sensors, a_last=prev, a_ode=prev, obs=sensors.observation(),
                            world=SimpleNamespace(bias=prev), reference_clip=jnp.array([0,-1]),
                            reference_start=jnp.array([10,-1]),reference_yaw=None,episode_limit=None,
                            recovery_left=jnp.full(n,100))
    sim.context = lambda _: jnp.zeros((n,8))
    tr = SimpleNamespace(qpos=q,qvel=v,qpos1=q,qvel1=v,target=jnp.zeros((n,92)),reward=zeros,
                         terminated=zeros>1,truncated=zeros>1,stats={})
    start,_ = xs.record(state,state,tr,prev,prev)
    start['cmd'] = cmd
    np.testing.assert_array_equal(start['reference_clip'],[0,-1])
    np.testing.assert_array_equal(start['reference_start'],[10,-1])
    def physical_next(s):
        tick = s[2][:,0]
        # Upright on transition 1, falls on transition 2. Thereafter it stays down.
        z = jnp.where(tick == 0, .68, .30)
        return (s[0].at[:,2].set(z), s[1], s[2].at[:,0].add(1.), *s[3:])
    monkeypatch.setattr(nets,'wm_step',lambda wm,wb,s,*args,**kw: physical_next(s))
    s1 = physical_next(S)
    real = sim.reward_terms(S,s1,sim.view_state(s1).kin,prev,prev,state.c_obs,jnp.zeros(n,bool),zeros,
                            jnp.zeros((n,2)),zeros,sim.q_soft,clip=state.reference_clip,reference_start=state.reference_start,
                            step=1,recovery_active=jnp.ones(n,bool))
    assert 0. < float(real['motion_reference'][0]) < 1. and real['motion_reference'][1] == 0.
    loss, aux = xs.imagine(None,None,None,None,start,jax.random.split(jax.random.key(16),horizon))
    # First transition is paid faithfully. The new fall and all subsequent down transitions yield zero.
    expected = env.DT * 5. * real['motion_reference'][0] / n
    np.testing.assert_allclose(-loss,expected,rtol=1.e-6)
    np.testing.assert_allclose(aux['reference_im_score'],real['motion_reference'][0],rtol=1.e-6)
    np.testing.assert_allclose(aux['reference_im_coverage'],1./(n*horizon),rtol=1.e-6)


def test_reference_option_is_opt_in():
    base = ['--robot',zenbot.MIXED_TASK,'--motion_train_wm','1']
    assert parse(base).wm_reference_training == 0
    assert parse([*base,'--wm_reference_training','1']).wm_reference_training == 1
    with pytest.raises(ValueError):
        parse([*base,'--wm_reference_training','2'])
def test_failed_rise_uses_the_same_tracked_window_in_real_and_imagined_time(reference):
    clip = jnp.array([0, 0, 0, 0, 0, -1, 0, 0])
    elapsed = jnp.array([3, 9, 9, 9, 9, 9, 9, 9])
    start = jnp.array([0, 0, 0, int(reference.first_support[0])+50, 0, 0, 0, 0])
    score = jnp.array([.1, .4, .8, 0., 0., 0., .9, .49])
    active = jnp.array([True, True, True, False, False, True, False, True])
    fell = jnp.array([False, False, False, False, False, False, True, False])
    np.testing.assert_array_equal(reference.failed_rise(score, clip, start, elapsed, active, fell, .5),
                                  [False, True, False, False, False, False, True, True])

