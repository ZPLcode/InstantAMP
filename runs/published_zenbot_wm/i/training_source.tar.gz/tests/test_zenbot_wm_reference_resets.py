"""CPU coverage and transition boundaries for paired recovery and dedicated gait collection."""
import jax
import jax.numpy as jnp
import numpy as np
import pytest

from instantamp import zenbot
from instantamp.sim import Sim
from test_zenbot_motion_train_wm_sim import native_substeps, simulator


def check_gait_poses(sim, pos, command, selection):
    by_command = sim.walk["command_rows"]
    counts, offsets, rows = map(np.asarray, (by_command["counts"], by_command["offsets"], by_command["row"]))
    bank = np.column_stack((sim.walk["z"], sim.walk["quat"], sim.walk["q"]))
    group = np.square(np.asarray(command)[:, None] - zenbot.DIRECTIONAL_COMMANDS).sum(-1).argmin(-1)
    for i in np.unique(group[selection]):
        valid = bank[rows[offsets[i]:offsets[i] + counts[i]]]
        valid_bytes = set(row.tobytes() for row in valid)
        assert all(row.tobytes() in valid_bytes for row in np.asarray(pos)[selection & (group == i), 2:])


def test_paired_wm_reset_distribution_matches_command_and_physical_phase():
    sim = simulator(n=1024, zenbot_wm_reference_training=True, prob_shove=.2)
    sim.reset_floor = .35
    st = sim.init(jax.random.key(8915))
    group = np.asarray(sim.wm_gait_worlds)
    np.testing.assert_array_equal(group, (np.arange(sim.N) // 2) % 4 == 0)
    assert group.sum() == 256
    assert (group & (np.arange(sim.N) % 2 == 0)).sum() == 128
    assert st.motion_train_sensors.observation().shape == (sim.N, 234)
    clip, phase = np.asarray(st.reference_clip), np.asarray(st.reference_start)
    floor = clip >= 0
    cold, moving = floor & (phase == 0), floor & (phase > 0)
    assert not (floor & group).any() and np.asarray(st.was_up)[group].all()
    assert abs(floor[~group].mean() - .35) < .05 and abs(cold.sum() / floor.sum() - .5) < .07
    np.testing.assert_array_equal(st.down, floor)
    np.testing.assert_array_equal(st.t[floor], 0)
    np.testing.assert_array_equal(st.c_obs[floor], 0.)
    for subset in (cold, moving):
        assert len(np.unique(clip[subset])) == 11
    pos, vel = np.asarray(st.data.qpos), np.asarray(st.data.qvel)
    np.testing.assert_array_equal(vel[cold, 2:], 0.)
    assert .04 < np.abs(vel[cold, :2]).max() < .071
    opens = sim.floor["openings"]
    np.testing.assert_array_equal(pos[cold, 2], np.asarray(opens["z"])[clip[cold]] + zenbot.RESET_LIFT)
    assert np.abs(pos[cold, 7:] - np.asarray(opens["q"])[clip[cold]]).max() < np.deg2rad(2.001)
    ref = sim.wm_reference
    ix = np.asarray(ref.offsets)[clip[moving]] + phase[moving]
    np.testing.assert_array_equal(pos[moving], np.asarray(ref.qpos)[ix])
    np.testing.assert_array_equal(vel[moving], np.asarray(ref.qvel)[ix])
    assert np.all(phase[moving] < np.asarray(sim.floor["phases"]["limits"])[clip[moving]])
    assert len(np.unique(np.asarray(st.c_obs)[group], axis=0)) == 8
    check_gait_poses(sim, pos, st.c_obs, group)


def test_gait_fall_truncates_only_reserved_worlds_and_forgets_previous_floor_pair():
    sim = simulator(n=16, zenbot_wm_reference_training=True)
    st = sim.init(jax.random.key(11))
    group = np.asarray(sim.wm_gait_worlds)
    down = sim.wm_reference.qpos[0]
    down = down.at[2].set(.30)
    stand = jnp.asarray([0., 0., .69, 1., 0., 0., 0., *zenbot.DEFAULT_Q])
    # Previously upright worlds 0..7 fall; worlds 8..15 reach upright for the first time.
    falling = np.arange(sim.N) < 8
    pos = jnp.where(jnp.asarray(falling)[:, None], down, stand)
    st = st._replace(data=st.data.replace(qpos=pos, qvel=jnp.zeros_like(st.data.qvel)),
                     was_up=jnp.asarray(falling), down=~sim.wm_gait_worlds,
                     reference_clip=jnp.where(sim.wm_gait_worlds, -1, 0),
                     reference_start=jnp.zeros(sim.N, jnp.int32), t=jnp.full(sim.N, 20),
                     recovery_left=jnp.where(falling, 0, 180))
    sim.physics = lambda *args: native_substeps(sim, *args)
    nxt, tr = sim.step(st, jnp.zeros((sim.N, 23)))
    reset = group & falling
    assert not tr.terminated.any() and not tr.diverged.any()
    np.testing.assert_array_equal(tr.truncated, reset)
    np.testing.assert_array_equal(np.asarray(tr.terminated | tr.truncated), reset)
    np.testing.assert_array_equal(nxt.t, np.where(reset, 0, 21))
    np.testing.assert_array_equal(nxt.reference_clip, np.where(group | falling, -1, 0))
    np.testing.assert_array_equal(nxt.reference_start[reset], 0)
    # Normal worlds keep the actual fallen state and can recover; reserved worlds restart at a command-matched pose.
    np.testing.assert_array_equal(nxt.data.qpos[~reset], tr.qpos1[~reset])
    assert np.all(np.asarray(nxt.was_up)[reset]) and not np.asarray(nxt.was_up)[falling & ~group].any()
    assert np.all(np.asarray(nxt.was_up)[~falling])
    assert np.all(np.asarray(nxt.recovery_left)[falling & ~group] == sim.recovery_amp_steps)
    np.testing.assert_array_equal(nxt.c_obs[falling & ~group], 0.)
    np.testing.assert_array_equal(nxt.motion_train_sensors.frames[reset, -1, 55:], 0.)
    check_gait_poses(sim, nxt.data.qpos, nxt.c_obs, reset)


def test_paired_wm_sampling_requires_the_deployable_wm_mode():
    with pytest.raises(ValueError, match="Motion Train world-model task"):
        Sim(1, physics=False, robot=zenbot.MIXED_TASK, zenbot_wm_reference_training=True)
