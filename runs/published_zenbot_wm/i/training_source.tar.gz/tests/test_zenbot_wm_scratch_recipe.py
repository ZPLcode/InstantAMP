"""Run the WM recipe with a recording trainer and the actual release benchmark shell script."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
RECIPE = Path("tools/recipes/train_zenbot_wm_scratch.sh")
EVALUATE = Path("releases/zenbot_motion_train/evaluate.sh")


@pytest.fixture
def checkout(tmp_path):
    root = tmp_path / "repository with spaces"
    for relative in (RECIPE, EVALUATE, Path("tools/monitor_zenbot_scratch.py")):
        dest = root / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(ROOT / relative, dest)
    record = tmp_path / "calls.jsonl"
    interp = tmp_path / "recording python"
    interp.write_text(f"#!{sys.executable}\n" + r'''
import json
import os
from pathlib import Path
import sys

import numpy as np

args = sys.argv[1:]
if args[:1] == ["-"]:
    os.execv(sys.executable, [sys.executable, *args])
with Path(os.environ["RECORD"]).open("a") as fp:
    print(json.dumps([args, os.environ.get("JAX_PLATFORMS")]), file=fp)
mode = os.environ["SCENARIO"]
if args[:2] == ["-m", "instantamp.train"]:
    if mode == "train_error":
        sys.exit(23)
    if mode == "edit_live_recipe":
        recipe = Path("tools/recipes/train_zenbot_wm_scratch.sh")
        recipe.write_text("#" * 4096 + "\n" + recipe.read_text())
    root = Path(args[args.index("--log_dir") + 1]) / "ckpt"
    for stem, it in [("9999", 1000), ("0004", 10000), ("010000", 9000)]:
        if it == 10000 and mode == "no_metadata":
            continue
        (root / (stem + ".json")).write_text(json.dumps({"it":it, "env_steps":5_136_384}))
        if it == 10000 and mode == "no_policy":
            continue
        dim = 390 if mode == "bad_width" else 234
        output = 22 if mode == "bad_output" else 23
        data = {"obs_norm/mean":np.zeros(dim), "avg/0/w":np.zeros((dim,output)),
                "avg/0/b":np.zeros(output)}
        if mode == "ode":
            data["ode/dmax"] = 3.24
        np.savez(root / (stem + ".npz"), **data)
    if mode == "duplicate":
        (root / "duplicate.json").write_text('{"it":10000}')
elif args[1].startswith("tools.evaluate_"):
    if mode == "eval_error":
        sys.exit(19)
    policy = Path(args[2])
    assert policy.resolve().name == "0004.npz" and policy.name == "policy.npz"
elif args[1] == "tools.export_zenbot_motion_train":
    out = Path(args[3])
    assert (out / "policy.npz").resolve().name == "0004.npz"
    for name in ("policy.pt", "policy.onnx"):
        (out / name).touch()
elif args[1] != "tools.compare_zenbot_scratch":
    sys.exit(77)
''')
    interp.chmod(0o755)
    verify = root / EVALUATE.parent / "verify_deployment.sh"
    verify.write_text("""#!/usr/bin/env bash
set -euo pipefail
[[ $POLICY_DIR == "$1" && -e "$1/policy.pt" && -e "$1/policy.onnx" ]]
printf '%s\\n' "$1" > "$1/deployment_was_invoked"
""")
    run = root / "run with spaces"

    def launch(args=(), mode="ok", deployment=False, before_run=()):
        env = dict(os.environ, RECORD=str(record), SCENARIO=mode, SIM_PYTHON=str(interp),
                   JAX_PLATFORMS="cuda", OPENBLAS_NUM_THREADS="1")
        for name in ("DEPLOY_PYTHON","TORCH_PYTHON","MOTION_TRAIN_ROOT"):
            env.pop(name,None)
        if deployment:
            env.update(DEPLOY_PYTHON=str(interp),TORCH_PYTHON=str(interp),MOTION_TRAIN_ROOT=str(root))
        result = subprocess.run(["bash", str(root / RECIPE), *before_run, str(run), *args], env=env,
                                cwd=tmp_path, capture_output=True, text=True)
        calls = [json.loads(line) for line in record.read_text().splitlines()] if record.exists() else []
        return result, calls
    return run, launch


@pytest.mark.parametrize(("before_run", "after_run"), [
    ([], []),
    ([], ["--verify-deployment"]),
    ([], ["--reference-training"]),
    (["--reference-training"], ["--verify-deployment"]),
    (["--verify-deployment", "--reference-training"], []),
])
def test_random_wm_training_and_actual_release_benchmark(checkout, before_run, after_run):
    run, launch = checkout
    flags = before_run + after_run
    deployment = "--verify-deployment" in flags
    reference = "--reference-training" in flags
    result, calls = launch(after_run, before_run=before_run, deployment=deployment)
    assert result.returncode == 0, result.stderr
    training, platform = calls[0]
    assert platform == "cuda"
    assert training[:2] == ["-m", "instantamp.train"]
    opts = dict(zip(training[2::2], training[3::2], strict=True))
    assert opts == {
        "--robot":"zenbot23_walk_run_recovery", "--motion_train_wm":"1", "--log_dir":str(run),
        "--seed":"42", "--max_iterations":"10000", "--minutes":"0", "--ckpt_iterations":"1000",
        "--num_envs":"512", "--env_steps":"1", "--pi_batch":"512", "--wm_batch":"512", "--amp_batch":"512",
        "--warmup_steps":"32", "--wm_only_iters":"200", "--wm_window":"8", "--horizon":"32",
        "--amp_w":"2", "--amp_getup":"1", "--ode":"0", "--legged_real_ppo":"0", "--ppo_frac":"0",
        "--action_rate_l2_weight":"-.015",
        **({"--wm_reference_training": "1"} if reference else {}),
    }
    from instantamp.train import ZenbotMotionTrainWMConfig, parse
    cfg = parse(training[2:])
    assert isinstance(cfg, ZenbotMotionTrainWMConfig)
    assert bool(cfg.wm_reference_training) == reference
    assert (cfg.init_policy, cfg.init_full, cfg.legged_prior_file, cfg.recovery_base_actor) == ("", "", "", "")
    assert cfg.robot == "zenbot23_walk_run_recovery" and cfg.amp_w > 0 and cfg.amp_getup
    assert cfg.walk_dir == cfg.amp_dir and cfg.floor_dir == cfg.amp_getup_dir
    assert cfg.num_envs * (cfg.warmup_steps + cfg.env_steps * cfg.max_iterations) == 5_136_384
    expected = ["tools.evaluate_zenbot_four_skills", "tools.evaluate_zenbot_directions",
                "tools.evaluate_zenbot_source_getup", "tools.evaluate_zenbot_four_skills",
                "tools.evaluate_zenbot_four_skills", "tools.compare_zenbot_scratch"]
    assert [args[1] for args,_ in calls[1:7]] == expected
    assert all(platform == "cpu" for _,platform in calls[1:7])
    ground = calls[1][0]
    assert ground[ground.index("--seeds")+1:ground.index("--transition-trials")] == [
        "932277","1654679","2718869","3950477","5969183"]
    assert ground[ground.index("--transition-trials")+1:ground.index("--gait-reference")] == [
        str(n) for n in range(0,22,2)]
    assert (run / "policy.npz").resolve() == run / "ckpt/0004.npz"
    assert (run / "deployment_was_invoked").is_file() == deployment
    assert [args[1] for args,_ in calls[7:]] == (["tools.export_zenbot_motion_train"] if deployment else [])


@pytest.mark.parametrize("mode", ["train_error","no_metadata","no_policy","duplicate","bad_width","bad_output","ode"])
def test_requires_actual_final_234_direct_actor(checkout, mode):
    run, launch = checkout
    result,calls = launch(mode=mode)
    assert result.returncode != 0 and len(calls) == 1
    assert not (run / "policy.npz").exists()


def test_evaluation_failure_stops_comparison_and_deployment(checkout):
    run, launch = checkout
    result,calls = launch(["--verify-deployment"], mode="eval_error", deployment=True)
    assert result.returncode == 19
    assert [args[1] for args,_ in calls] == ["instantamp.train","tools.evaluate_zenbot_four_skills"]
    assert not (run / "deployment_was_invoked").exists()


def test_evaluation_survives_recipe_edit_during_training(checkout):
    run, launch = checkout
    result, calls = launch(mode="edit_live_recipe")
    assert result.returncode == 0, result.stderr
    assert (run / "policy.npz").resolve() == run / "ckpt/0004.npz"
    assert calls[-1][0][1] == "tools.compare_zenbot_scratch"


@pytest.mark.parametrize("flags", [[], ["--reference-training"]])
def test_existing_checkpoint_and_incomplete_deployment_settings_fail_before_training(checkout, flags):
    run, launch = checkout
    result,calls = launch(["--verify-deployment"])
    assert result.returncode != 0 and not calls and not run.exists()
    (run / "ckpt").mkdir(parents=True)
    result,calls = launch(flags)
    assert result.returncode != 0 and not calls
