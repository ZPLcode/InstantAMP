"""Fold measured command-response gains into a three-frame Zenbot actor's first layer."""

import argparse
from pathlib import Path

import numpy as np

from instantamp.zenbot_motion_train_obs import MOTION_TRAIN_WIDTH


def calibrate(checkpoint, destination, lateral, turn):
    """Fold steady and onset gains into the three weights for each command history."""
    with np.load(checkpoint, allow_pickle=False) as archive:
        fields = dict(archive)
    if fields["obs_norm/mean"].shape != (MOTION_TRAIN_WIDTH,) or "obs_norm/raw" not in fields:
        raise ValueError("Expected a raw 234-input Motion Train actor")
    for axis, (steady_gain, onset_gain) in enumerate((lateral, turn), 1):
        if not np.all(np.isfinite([steady_gain, onset_gain])) or steady_gain <= 0.0:
            raise ValueError("Command gains must be finite, with a positive steady gain")
        # Indices 18:27 store [vx, vy, yaw] at the three most recent times.
        rows = np.array([18, 21, 24]) + axis
        for prefix in ("avg", "pi", "live"):
            key = f"{prefix}/0/w"
            if key not in fields:
                continue
            weights = fields[key]
            onset = onset_gain * weights[rows].sum(axis=0)
            weights[rows] *= steady_gain
            weights[rows[0]] -= onset
            weights[rows[-1]] += onset
    destination.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(destination, **fields)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("destination", type=Path)
    for name in ("lateral", "turn"):
        parser.add_argument(f"--{name}", nargs=2, type=float, default=(1.0, 0.0), metavar=("STEADY", "ONSET"))
    args = parser.parse_args()
    calibrate(args.checkpoint, args.destination, args.lateral, args.turn)
