"""Collect a live stage-boundary Zenbot actor's own motor means on independent native MuJoCo episodes."""

import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

# In a training process use a CPU subprocess for this CLI. Importing the supervised fit module sets no devices.
if __name__ == "__main__":
    os.environ["JAX_PLATFORMS"] = "cpu"
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    if not __package__:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import jax
import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation
from instantamp import env, zenbot, zenbot_source_gait
from instantamp.inference import load
from instantamp.zenbot_motion_train_obs import advance_sensors, motion_train_actor_mean
from tools.prepare_zenbot_scratch_pairs import NativeWorld

GROUPS = ("stand", "forward", "run", "back", "left", "right", "turn_left", "turn_right", "continuous")
SIGMAS = (0.0, 0.25, 0.5, 0.85)
CLIPS = (
    "stand_4s_120f",
    "Male1_B1_StandToWalk",
    "run__C3_-_run_stageii",
    "male_walk__Walk_B4_-_Stand_to_Walk_Back_stageii",
    "droidupe1_side_left",
    "droidupe1_side_right",
    "droidupe1_turn_left",
    "droidupe1_turn_right",
)
ROOT = Path(zenbot.__file__).resolve().parents[1]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def stage_at(run, iteration):
    observed = None
    with (run / "log.jsonl").open() as lines:
        for line in lines:
            if not line.strip():
                continue
            row = json.loads(line)
            if row["it"] <= iteration and "source_speed_stage" in row:
                observed = int(row["source_speed_stage"])
    if observed is None:
        raise ValueError("Specify --speed-stage or provide source_speed_stage from this run's log.jsonl")
    return observed


def state_from_clip(path, rng):
    with np.load(path, allow_pickle=False) as clip:
        length = len(clip["dof_pos"])
        t = int(rng.integers(max(1, length // 5), max(2, 4 * length // 5)))
        quat = clip["root_quat"][t, [3, 0, 1, 2]]
        pose = np.r_[clip["root_pos"][t], quat, clip["dof_pos"][t]]
        omega = Rotation.from_quat(quat, scalar_first=True).inv().apply(clip["root_ang_vel"][t])
        vel = np.r_[clip["root_lin_vel"][t], omega, clip["dof_vel"][t]]
    return pose, vel, t


def starts(seed, folder):
    rng = np.random.default_rng(seed)
    q, v = zenbot_source_gait.stand_reset(jax.random.key(seed), 4 * len(GROUPS))
    poses, vels = list(np.asarray(q)), list(np.asarray(v))
    groups = list(np.tile(np.arange(len(GROUPS)), 4))
    origin = [("source_stand", -1)] * len(groups)
    for group, clip in enumerate(CLIPS):
        for _ in range(2):
            qq, vv, t = state_from_clip(folder / (clip + ".npz"), rng)
            poses.append(qq)
            vels.append(vv)
            groups.append(group)
            origin.append((clip, t))
    as_rows = np.array(groups)
    return np.array(poses), np.array(vels), as_rows, origin


@jax.jit
def sense_and_act(actor, norm, state, imu, cmd, q, v, last, fresh, noisy, key):
    # Keep both sensor variants on the exact native motor path. A world's corruption flag is fixed per episode.
    clean = advance_sensors(state, imu, cmd, q, v, last, fresh, key, corrupt=False)
    corrupt = advance_sensors(state, imu, cmd, q, v, last, fresh, key, corrupt=True)

    def pick(a, b):
        return jnp.where(noisy.reshape((-1,) + (1,) * (a.ndim - 1)), a, b)

    sensor = jax.tree.map(pick, corrupt, clean)
    observed = sensor.observation()
    return sensor, observed, motion_train_actor_mean(actor, norm, observed)


def illegal_contact(world, data, illegal, wrench):
    for index, con in enumerate(data.contact):
        a, b = con.geom
        other = b if a == world.floor else a if b == world.floor else -1
        if other >= 0 and illegal[other]:
            mujoco.mj_contactForce(world.model, data, index, wrench)
            if wrench[0] > 1.0:
                return True
    return False


def episodes(actor, norm, world, folder, seed, sigma, stage, ticks):
    q, v, group, origin = starts(seed, folder)
    n = len(q)
    rng = np.random.default_rng(seed)
    lags = rng.integers(3, 8, (n, 5))
    # Each command receives both clean and fully delayed/corrupted Motion Train observations.
    noisy = np.zeros(n, bool)
    for g in range(len(GROUPS)):
        ix = np.flatnonzero(group == g)
        noisy[ix[1::2]] = True
    source = zenbot_source_gait.sample_command(jax.random.key(seed + 1), n, stage)
    source_vel = np.asarray(source.vel).copy()
    source_heading = np.asarray(source.heading)
    continuous = group == 8
    direction = zenbot.DIRECTIONAL_COMMANDS[np.minimum(group, 7)]
    ds = [mujoco.MjData(world.model) for _ in group]
    for data, pose, vel in zip(ds, q, v):
        data.qpos[:] = pose
        data.qvel[:] = vel
        mujoco.mj_forward(world.model, data)
    live = np.ones(n, bool)
    old = np.zeros((n, 23), np.float32)
    older = old.copy()
    sensor = None
    samples = []
    illegal = zenbot_source_gait.illegal_contact_geoms(world.model)
    wrench = np.zeros(6)
    expanded = lags[:, zenbot.GROUP]
    for tick in range(ticks):
        if not live.any():
            break
        q = np.asarray([d.qpos for d in ds])
        v = np.asarray([d.qvel for d in ds])
        matrix = Rotation.from_quat(q[:, 3:7], scalar_first=True).as_matrix()
        yaw = np.arctan2(matrix[:, 1, 0], matrix[:, 0, 0])
        err = source_heading - yaw
        velocity = source_vel.copy()
        velocity[:, 2] = np.where(
            source.is_heading, np.clip(0.5 * np.arctan2(np.sin(err), np.cos(err)), -1.5, 1.5), velocity[:, 2]
        )
        cmd = np.where(
            continuous[:, None], np.where(np.asarray(source.is_standing)[:, None], 0.0, velocity), direction
        )
        inputs = (np.c_[v[:, 3:6], -matrix[:, 2]], cmd, q[:, 7:], v[:, 6:], old)
        sensor, obs, mean = sense_and_act(
            actor,
            norm,
            sensor,
            *[jnp.asarray(a, jnp.float32) for a in inputs],
            jnp.full(n, tick == 0),
            noisy,
            jax.random.key((seed + 17 * tick + 5) % 2**32),
        )
        mean = np.asarray(mean)
        if tick % 3 == 0:
            use = np.flatnonzero(live & (q[:, 2] > 0.45) & (matrix[:, 2, 2] > 0.707))
            samples.append(
                (np.asarray(obs)[use], mean[use], group[use], noisy[use], use, np.full(len(use), tick, np.int32))
            )
        action = (mean + sigma * rng.normal(size=mean.shape)).astype(np.float32)
        for i in np.flatnonzero(live):
            d = ds[i]
            world.step(d, action[i], old[i], older[i], expanded[i])
            up = 1 - 2 * (d.qpos[4:6] ** 2).sum()
            live[i] = bool(d.qpos[2] >= 0.2 and up >= 0.5 and not illegal_contact(world, d, illegal, wrench))
        older, old = old, action
    data = tuple(np.concatenate(parts) for parts in zip(*samples))
    plan = dict(
        seed=seed,
        sigma=sigma,
        origins=origin,
        group=group.tolist(),
        noisy=noisy.tolist(),
        motor_delays=lags.tolist(),
    )
    return data, plan


def write_bank(run, iteration, out, rows, seed, stage, ticks, folder):
    if jax.default_backend() != "cpu":
        raise ValueError("Collect stage behavior on CPU")
    if out.suffix != ".npz":
        raise ValueError("--out must end in .npz")
    if rows < 9 * 2 * 4 or ticks < 2:
        raise ValueError("Request at least one row per command/sensor/noise stratum")
    ck = run / "ckpt" / f"{iteration:06}.npz"
    meta = ck.with_suffix(".json")
    if json.loads(meta.read_text()).get("it") != iteration:
        raise ValueError("Wrong checkpoint iteration")
    ck_digest = digest(ck)
    sources = [
        Path(__file__),
        Path(inspect.getsourcefile(advance_sensors)),
        Path(inspect.getsourcefile(NativeWorld)),
        Path(inspect.getsourcefile(zenbot_source_gait.stand_reset)),
        Path(zenbot.__file__),
        ROOT / "assets/zenbot_23dof_43kg.xml",
        *(folder / (clip + ".npz") for clip in CLIPS),
    ]
    source_hashes = {p.name: digest(p) for p in sources}
    settings = dict(
        iteration=iteration,
        checkpoint_sha256=ck_digest,
        checkpoint_weights="live",
        rows=rows,
        seed=seed,
        speed_stage=stage,
        control_ticks=ticks,
        sigmas=SIGMAS,
        source_sha256=source_hashes,
    )
    settings = json.loads(json.dumps(settings))
    out.parent.mkdir(parents=True, exist_ok=True)
    pair = out
    manifest = out.with_suffix(".json")
    if manifest.exists():
        prior = json.loads(manifest.read_text())
        if prior["settings"] != settings or digest(pair) != prior["sha256"]:
            raise ValueError("Existing behavior manifest differs")
        return prior
    actor, norm, _ = load(ck, which="live")
    if (
        not isinstance(actor, list)
        or actor[0]["w"].shape[0] != 234
        or actor[-1]["b"].shape != (23,)
        or np.asarray(norm["mean"]).shape != (234,)
    ):
        raise ValueError("Expected one 234-channel, 23-motor Zenbot stage-boundary MLP")
    buckets = {}
    plans = []
    rng = np.random.default_rng(seed)
    # Store a bounded sample from each stratum. Equalize groups before choosing the final rows.
    cells = [(g, c, s) for g in range(9) for c in (0, 1) for s in range(4)]
    goal = {cell: rows // len(cells) + (i < rows % len(cells)) for i, cell in enumerate(cells)}
    world = NativeWorld()
    for batch in range(10):
        for s, sigma in enumerate(SIGMAS):
            episode_seed = int(rng.integers(0, 2**31 - 1))
            (x, y, g, c, world_id, t), plan = episodes(
                actor, norm, world, folder, episode_seed, sigma, stage, ticks
            )
            plan_id = len(plans)
            plans.append(plan)
            for key in cells:
                if key[2] != s or key in buckets and len(buckets[key][0]) >= goal[key]:
                    continue
                idx = np.flatnonzero((g == key[0]) & (c == key[1]))
                if not len(idx):
                    continue
                ix = rng.choice(
                    idx, size=min(len(idx), goal[key] - len(buckets.get(key, [[]])[0])), replace=False
                )
                fragment = (x[ix], y[ix], world_id[ix], t[ix], np.full(len(ix), plan_id))
                buckets[key] = (
                    tuple(np.concatenate((a, b)) for a, b in zip(buckets[key], fragment))
                    if key in buckets
                    else fragment
                )
        if all(k in buckets and len(buckets[k][0]) == goal[k] for k in cells):
            break
    else:
        raise RuntimeError("Insufficient healthy sensor/noise/command samples in ten independent batches")
    if digest(ck) != ck_digest:
        raise ValueError("The source actor changed during collection")
    xx, yy, world_idx, tick, plan_idx = (np.concatenate(xs) for xs in zip(*(buckets[k] for k in cells)))
    group, corrupt, sigma_id = np.repeat(np.asarray(cells), [goal[k] for k in cells], axis=0).T
    continuous = group == 8
    # Categorical rows retain their true group. Match continuous commands to the nearest
    # repository velocity using m/s and rad/s tracking scales, including truly zero commands.
    scaled = (xx[continuous, 24:27, None] - zenbot.DIRECTIONAL_COMMANDS.T[None]) / np.array([0.4, 0.3, 0.4])[
        None, :, None
    ]
    group[continuous] = np.square(scaled).sum(1).argmin(1)
    order = rng.permutation(rows)
    with TemporaryDirectory(dir=out.parent) as tmpdir:
        tmp = Path(tmpdir)
        np.savez_compressed(
            tmp / "behavior.npz",
            obs=xx[order],
            q_target_raw=yy[order],
            group=group[order].astype(np.int8),
            continuous=continuous[order],
            sensor_corruption=corrupt[order].astype(bool),
            sigma_id=sigma_id[order].astype(np.int8),
            world=world_idx[order].astype(np.int16),
            tick=tick[order].astype(np.int32),
            batch=plan_idx[order].astype(np.int16),
        )
        out_meta = dict(
            version=1,
            settings=settings,
            sha256=digest(tmp / "behavior.npz"),
            groups=GROUPS[:8],
            plans=plans,
            dt=env.DT,
            sample_every=3,
            continuous_rows=int(continuous.sum()),
            rows_per_group=np.bincount(group, minlength=8).tolist(),
        )
        (tmp / "manifest.json").write_text(json.dumps(out_meta, indent=2, allow_nan=False) + "\n")
        (tmp / "behavior.npz").replace(pair)
        (tmp / "manifest.json").replace(manifest)
    return out_meta


def main():
    p = argparse.ArgumentParser(__doc__)
    p.add_argument("--run-dir", type=Path, required=True)
    p.add_argument("--iteration", type=int, default=4500)
    p.add_argument("--out", type=Path)
    p.add_argument("--rows", type=int, default=9216)
    p.add_argument("--seed", type=int, default=67425)
    p.add_argument("--speed-stage", type=int, choices=range(4))
    p.add_argument("--ticks", type=int, default=320)
    p.add_argument("--gait-dir", type=Path, default=ROOT / "data/zenbot23_walk_run_recovery/walk_run")
    args = p.parse_args()
    stage = stage_at(args.run_dir, args.iteration) if args.speed_stage is None else args.speed_stage
    out = args.out if args.out is not None else args.run_dir / "retention.npz"
    result = write_bank(args.run_dir, args.iteration, out, args.rows, args.seed, stage, args.ticks, args.gait_dir)
    print(f"{out} {result['settings']['rows']} rows SHA-256 {result['sha256']}")


if __name__ == "__main__":
    main()
