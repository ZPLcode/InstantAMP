"""Replay one frozen Zenbot actor on 81 identical openings with immediate and delayed motors."""

import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path

os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")
os.environ.setdefault("JAX_SKIP_CUDA_CONSTRAINTS_CHECK", "1")

import jax
import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp import zenbot
from instantamp.inference import load
from instantamp.zenbot_motion_train_obs import advance_sensors, motion_train_actor_mean
from instantamp.zenbot_source_gait import illegal_contact_geoms
from tools.evaluate_zenbot_directions import direction_metrics, heading_kinematics
from tools.evaluate_zenbot_walk_recovery import score
from tools.monitor_zenbot_scratch import ready
from tools.prepare_zenbot_scratch_pairs import NativeWorld

FIXTURE = Path(__file__).resolve().parent / "fixtures/zenbot_motor_domains"
STEPS = 400


def digest(path):
    with path.open("rb") as fh:
        return hashlib.file_digest(fh, "sha256").hexdigest()


def compile_step(directory):
    pkg = Path(mujoco.__file__).parent
    library = Path(directory) / "batch.so"
    subprocess.run(
        [
            "c++",
            "-O3",
            "-fPIC",
            "-std=c++17",
            "-shared",
            "-I" + str(pkg / "include"),
            str(FIXTURE / "batch.cc"),
            str(next(pkg.glob("libmujoco.so.*"))),
            "-Wl,-rpath," + str(pkg),
            "-o",
            str(library),
        ],
        check=True,
    )
    step = ctypes.CDLL(str(library)).batch
    c_array = np.ctypeslib.ndpointer
    f64 = c_array(np.float64, flags="C_CONTIGUOUS")
    i32 = c_array(np.int32, flags="C_CONTIGUOUS")
    step.argtypes = [
        ctypes.c_void_p,
        c_array(np.uintp, flags="C_CONTIGUOUS"),
        ctypes.c_int,
        f64,
        i32,
        i32,
        f64,
        f64,
        f64,
        f64,
        f64,
        f64,
        f64,
        i32,
        f64,
        i32,
    ]
    step.restype = None
    return step


@jax.jit
def policy_step(actor, norm, previous, imu, command, joint_angle, joint_speed, old, fresh):
    state = advance_sensors(
        previous, imu, command, joint_angle, joint_speed, old, fresh, jax.random.key(0), corrupt=False
    )
    return state, motion_train_actor_mean(actor, norm, state.observation())


def run_domain(world, step, actor, norm, fixture, groups):
    model = world.model
    n = len(groups)
    q = np.array(fixture["q"], dtype=np.float64, order="C")
    v = np.array(fixture["v"], dtype=np.float64, order="C")
    command = fixture["cmd"].astype(float)
    heading = fixture["heading"]
    servo = np.ascontiguousarray([zenbot.KP, zenbot.KD, zenbot.EFFORT, zenbot.SPEED], dtype=float)
    delays = np.ascontiguousarray(groups[:, zenbot.GROUP], np.int32)
    geom_type = np.full(model.ngeom, -1, np.int32)
    geom_type[world.soles] = [0, 1]
    geom_type[illegal_contact_geoms(model)] = 2
    nominal = zenbot.DEFAULT_Q.astype(float)
    data = [mujoco.MjData(model) for _ in range(n)]
    for d, initial_q, initial_v in zip(data, q, v, strict=True):
        d.qpos[:] = initial_q
        d.qvel[:] = initial_v
        mujoco.mj_forward(model, d)
    pointers = np.asarray([d._address for d in data], np.uintp)

    poses = np.empty((STEPS + 1, n, model.nq))
    poses[0] = q
    speeds = np.empty((STEPS, n, model.nv))
    feet = np.empty((STEPS, n, 2))
    airborne = np.empty((STEPS, n, 4), bool)
    commands = np.empty((STEPS, n, 3))
    previous = np.zeros((n, 23))
    older = previous.copy()
    sensor = None
    strict_falls = [None] * n
    illegal = np.zeros(n, np.int32)
    force = np.zeros(n)
    load_bw = np.zeros((n, 2))
    flight = np.zeros((n, 4), np.int32)
    dynamic = np.isfinite(heading)
    for t in range(STEPS):
        rot = Rotation.from_quat(q[:, 3:7], scalar_first=True).as_matrix()
        yaw = np.arctan2(rot[:, 1, 0], rot[:, 0, 0])
        err = heading[dynamic] - yaw[dynamic]
        command[dynamic, 2] = np.clip(0.5 * np.arctan2(np.sin(err), np.cos(err)), -1.5, 1.5)
        commands[t] = command
        features = (np.c_[v[:, 3:6], -rot[:, 2]], command, q[:, 7:], v[:, 6:], previous)
        sensor, raw = policy_step(
            actor, norm, sensor, *(jnp.asarray(x, jnp.float32) for x in features), jnp.full(n, t == 0)
        )
        action = np.ascontiguousarray(raw, dtype=float)
        step(
            model._address,
            pointers,
            n,
            servo,
            delays,
            geom_type,
            nominal,
            action,
            previous,
            older,
            q,
            v,
            load_bw,
            illegal,
            force,
            flight,
        )
        older, previous = previous, action
        poses[t + 1], speeds[t], feet[t], airborne[t] = q, v, load_bw / world.body_weight, flight
        up = 1 - 2 * np.square(q[:, 4:6]).sum(-1)
        for i in np.flatnonzero((illegal >= 0) | (q[:, 2] < 0.2) | (up < 0.5)):
            if strict_falls[i] is None:
                g = int(illegal[i])
                strict_falls[i] = {
                    "step": t + 1,
                    "seconds": (t + 1) * 0.02,
                    "geom": model.geom(g).name if g >= 0 else "",
                    "newtons": float(force[i]),
                    "height": float(q[i, 2]),
                    "up": float(up[i]),
                    "base_low": bool(q[i, 2] < 0.2),
                    "tilt": bool(up[i] < 0.5),
                }

    rows = []
    for i, name in enumerate(fixture["name"]):
        pose, target = poses[:, i], fixture["cmd"][i]
        kin, _ = heading_kinematics(pose)
        if name == "curriculum":
            passed = (
                strict_falls[i] is None
                and np.linalg.norm(kin[-150:, :2] - commands[-150:, i, :2], axis=-1).mean() <= 0.35
            )
        else:
            passed = direction_metrics(pose, feet[:, i], target)["passed"]
        gait = None
        if name in ("forward", "run"):
            measured = score(
                "walk" if name == "forward" else "run",
                target[0],
                pose[1:],
                speeds[:, i],
                feet[:, i],
                airborne[:, i],
                None,
            )
            gait = {k: measured[k] for k in ("passed", "flight_intervals", "single_support_switches")}
        fell = (pose[:, 2] < 0.42).any() or (1 - 2 * np.square(pose[:, 4:6]).sum(axis=1) < 0.55).any()
        rows.append(
            {
                "name": str(name),
                "group": str(fixture["group"][i]),
                "tag": json.loads(fixture["tag_json"][i]),
                "command": target.tolist(),
                "strict_fall": strict_falls[i],
                "fell": bool(fell),
                "speed_last3": kin[-150:].mean(0).tolist(),
                "speed_at_1s": kin[:50].mean(0).tolist(),
                "passed": bool(passed),
                "gait": gait,
                "measured_tracking_error": float(
                    np.linalg.norm(kin[:, :2] - commands[:, i, :2], axis=-1).mean()
                ),
            }
        )
    return rows


def summarize(rows):
    def stats(sample):
        gait = [r["gait"] for r in sample if r["gait"] is not None]
        return {
            "trials": len(sample),
            "survived": sum(not r["fell"] for r in sample),
            "survived_strict": sum(r["strict_fall"] is None for r in sample),
            "tracking_passed": sum(r["passed"] for r in sample),
            "gait_style_passed": sum(r["passed"] for r in gait),
            "gait_trials": len(gait),
            "median_vx_vy_wz_last3": np.median([r["speed_last3"] for r in sample], axis=0).tolist(),
        }

    groups = {
        "all81": rows,
        "fixed61": [r for r in rows if r["group"] != "source_draw"],
        "standing40": [r for r in rows if r["group"] == "source_birth"],
        "motion21": [r for r in rows if r["group"] == "moving_reference"],
        "curriculum20": [r for r in rows if r["group"] == "source_draw"],
    }
    return {
        name: {
            "total": stats(sample),
            "directions": {
                cmd: stats([r for r in sample if r["name"] == cmd])
                for cmd in sorted({r["name"] for r in sample})
            },
        }
        for name, sample in groups.items()
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True, help="Training run containing ckpt/NNNNNN.npz")
    parser.add_argument("--iterations", type=int, nargs="+", default=[10000])
    parser.add_argument("--out", type=Path, help="Defaults to RUN/evaluation/motor_domains")
    args = parser.parse_args()
    output = args.out or args.run_dir / "evaluation/motor_domains"
    with np.load(FIXTURE / "initial_states.npz", allow_pickle=False) as archive:
        fixture = dict(archive)
    groups = fixture["delay"]
    if groups.shape != (81, 5) or not np.all((groups >= 3) & (groups <= 7)):
        raise ValueError("Expected 81 matched five-group 3–7-substep initial states")
    world = NativeWorld()
    if world.floor != 0 or world.model.opt.timestep != 0.005:
        raise ValueError("This benchmark requires the native 200 Hz Zenbot floor model")
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        step = compile_step(tmp)
        for it in args.iterations:
            ckpt = args.run_dir / "ckpt" / f"{it:06}.npz"
            if not ready(ckpt, it):
                parser.error(f"Missing or incomplete checkpoint {ckpt}")
            actor, norm, _ = load(ckpt)
            report = {
                "iteration": it,
                "checkpoint_sha256": digest(ckpt),
                "mujoco_version": mujoco.__version__,
                "fixture_sha256": digest(FIXTURE / "initial_states.npz"),
                "step_sha256": digest(FIXTURE / "batch.cc"),
                "evaluator_sha256": digest(Path(__file__)),
                "seconds": 8.0,
                "policy_hz": 50,
                "physics_hz": 200,
                "action_noise": 0.0,
                "sensor_corruption": False,
                "motor_guidance": 0.0,
                "training_delay_steps": groups.tolist(),
                "domains": {},
            }
            for domain, delay in (("training_delay", groups), ("zero_delay", np.zeros_like(groups))):
                rows = run_domain(world, step, actor, norm, fixture, delay)
                report["domains"][domain] = {"groups": summarize(rows), "rows": rows}
                print(it, domain, report["domains"][domain]["groups"]["all81"]["total"], flush=True)
            path = output / f"{it:06}.json"
            with tempfile.NamedTemporaryFile(mode="w", dir=output, delete=False) as pending:
                json.dump(report, pending, indent=2, allow_nan=False)
                pending.write("\n")
            Path(pending.name).replace(path)


if __name__ == "__main__":
    main()
