"""Collect native pivot demonstrations and fit a single 234-input Zenbot MLP."""

import argparse
import hashlib
import json
import sys
from copy import copy
from pathlib import Path

import numpy as np

from instantamp.zenbot_motion_train_obs import MOTION_TRAIN_INDEX
from tools.train_zenbot_skill_actor import DenseActor

YAW_ROWS = np.array([20, 23, 26])


def write_recipe(path, sources):
    hashes = {}
    for source in sources:
        if source is not None:
            with source.open("rb") as stream:
                hashes[str(source)] = hashlib.file_digest(stream, "sha256").hexdigest()
    path.write_text(
        json.dumps(
            {"command": ["python", "-m", "tools.fit_zenbot_pivots", *sys.argv[1:]], "input_sha256": hashes},
            indent=2,
        )
        + "\n"
    )


def collect(args):
    """Run both pivot directions from each quiet stand and keep the original commanded history."""
    import mujoco

    from instantamp import zenbot
    from instantamp.zenbot_command_actor import gait_teacher_observation
    from tools.collect_zenbot_recovery_gait import motor_step
    from tools.evaluate_zenbot_directions import direction_metrics
    from tools.evaluate_zenbot_getup import evaluate
    from tools.play_zenbot_getup import ZenbotPlayer

    actor = DenseActor(args.policy)
    teacher = DenseActor(args.teacher)
    player = ZenbotPlayer(args.policy, visuals=False)
    native = player.native
    model = native.model
    pelvis_body = model.jnt_bodyid[0]
    soles = [model.geom("robot_" + name + "_collision").id for name in zenbot.FEET]
    floor = model.geom("floor").id
    body_weight = sum(model.body_mass) * 9.81
    inputs, labels, ticks, directions, rows = [], [], [], [], []
    for seed in args.seeds:
        for trial in args.trials:
            case, _ = evaluate(player, trial, seed, 600, -1)
            if not case["held"]:
                continue
            standing = copy(native.data)
            initial_history = np.asarray(gait_teacher_observation(native.history.reshape(5, 99))).reshape(5, 78)
            motor_delays = np.asarray(native.delays)[zenbot.GROUP]
            for sign in (-1.0, 1.0):
                target_yaw = 0.6 * sign
                start = len(inputs)
                data = copy(standing)
                history = initial_history.copy()
                teacher_history = history.copy()
                corrected_student_history = history.copy()
                previous, older = np.asarray(native.previous), history[-1, 55:].copy()
                velocity = np.zeros(2)
                yaw_rate = integrated_error = 0.0
                base_poses = [data.qpos[:7].copy()]
                foot_loads = []
                for tick in range(400):
                    mujoco.mj_kinematics(model, data)
                    rotation = data.xmat[pelvis_body].reshape(3, 3)
                    if data.qpos[2] < 0.42 or rotation[2, 2] < 0.55:
                        break
                    yaw = np.arctan2(rotation[1, 0], rotation[0, 0])
                    cos_yaw, sin_yaw = np.cos(yaw), np.sin(yaw)
                    to_body = np.array([[cos_yaw, sin_yaw], [-sin_yaw, cos_yaw]])
                    displacement = to_body @ (data.qpos[:2] - standing.qpos[:2])
                    velocity += 0.12 * (to_body @ data.qvel[:2] - velocity)
                    yaw_rate += args.yaw_smoothing * (data.qvel[5] - yaw_rate)
                    integrated_error = np.clip(integrated_error + 0.02 * (target_yaw - yaw_rate), -0.8, 0.8)
                    frame = np.r_[
                        data.qvel[3:6],
                        -rotation[2],
                        0.0,
                        0.0,
                        target_yaw,
                        data.qpos[7:] - zenbot.DEFAULT_Q,
                        data.qvel[6:],
                        previous,
                    ]
                    history[:-1] = history[1:]
                    history[-1] = frame
                    expert_frame = frame.copy()
                    expert_frame[6:8] = np.clip(-args.kp * displacement - args.kd * velocity, -0.55, 0.55)
                    # Request a stepping turn from the teacher even when the previous command was zero.
                    expert_frame[8] = sign * np.clip(
                        args.yaw_bias
                        + args.yaw_p * sign * (target_yaw - yaw_rate)
                        + args.yaw_i * sign * integrated_error,
                        0.35,
                        2.45,
                    )
                    teacher_history[:-1] = teacher_history[1:]
                    teacher_history[-1] = expert_frame
                    label = teacher(teacher_history)
                    if args.feedback_student:
                        corrected_student_history[:-1] = corrected_student_history[1:]
                        corrected_student_frame = frame.copy()
                        corrected_student_frame[6:8] = np.clip(
                            -args.kp * displacement - args.kd * velocity, -0.45, 0.45
                        )
                        corrected_student_frame[8] = sign * np.clip(
                            0.58 + sign * (target_yaw - yaw_rate) * 0.36 + sign * integrated_error * 0.65,
                            0.25,
                            1.0,
                        )
                        corrected_student_history[-1] = corrected_student_frame
                        student_action = actor(corrected_student_history.ravel()[MOTION_TRAIN_INDEX])
                    else:
                        student_action = actor(history.ravel()[MOTION_TRAIN_INDEX])
                    action = (1.0 - args.share) * label + args.share * student_action
                    if tick % 2 == 0:
                        inputs.append(history.copy())
                        labels.append(action if args.executed_labels else label)
                        ticks.append(tick)
                        directions.append(sign)
                    foot_load, _ = motor_step(
                        model, data, action, previous, older, motor_delays, soles, floor, body_weight
                    )
                    base_poses.append(data.qpos[:7].copy())
                    foot_loads.append(foot_load)
                    older, previous = previous, action
                command = [0.0, 0.0, target_yaw]
                if len(foot_loads) == 400:
                    metrics = direction_metrics(np.asarray(base_poses), np.asarray(foot_loads), command)
                else:
                    metrics = {"command": command, "passed": False, "fell": True}
                rows.append(dict(seed=seed, trial=trial, ticks=len(foot_loads), **metrics))
                if args.keep_success and not metrics["passed"]:
                    del inputs[start:], labels[start:], ticks[start:], directions[start:]
        print(seed, len(inputs), sum(r["passed"] for r in rows), len(rows), flush=True)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.out,
        x=np.asarray(inputs, np.float16),
        u=np.asarray(labels, np.float32),
        t=np.asarray(ticks, np.int16),
        sign=np.asarray(directions, np.int8),
    )
    args.out.with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")
    write_recipe(args.out.with_suffix(".recipe.json"), [args.policy, args.teacher])


def fit(args):
    """Match both teachers' actions on true onset and steady states, updating three input rows."""
    import torch

    from tools.distill_zenbot_directions import motion_train_noisy_history

    args.out.mkdir(parents=True, exist_ok=True)
    write_recipe(args.out / "recipe.json", [args.left_policy, args.right_policy, *args.data])
    torch.manual_seed(args.seed)
    torch.set_num_threads(2)
    with np.load(args.left_policy) as archive:
        fields = dict(archive)
    if fields["avg/0/w"].shape[0] != 234 or "obs_norm/raw" not in fields:
        raise ValueError("Expected a raw 234-input actor")
    with np.load(args.right_policy) as right:
        for key, array in fields.items():
            if key.startswith(("avg/", "pi/")):
                other = right[key]
                if key in ("avg/0/w", "pi/0/w"):
                    array = np.delete(array, YAW_ROWS, axis=0)
                    other = np.delete(other, YAW_ROWS, axis=0)
                if not np.array_equal(array, other):
                    raise ValueError(f"Teachers differ outside their yaw rows in {key}")
        right_rows = right["avg/0/w"][YAW_ROWS]
    left_rows = fields["avg/0/w"][YAW_ROWS]
    midpoint = (left_rows + right_rows) * 0.5
    difference = torch.as_tensor((left_rows - right_rows) * 0.5, device=args.device)
    first = fields["avg/0/w"].copy()
    first[YAW_ROWS] = midpoint
    fields["avg/0/w"] = first
    fields["pi/0/w"] = first.copy()
    layers = [
        (
            torch.as_tensor(fields[f"avg/{i}/w"], device=args.device),
            torch.as_tensor(fields[f"avg/{i}/b"], device=args.device),
        )
        for i in range(4)
    ]
    starts, steady = [], []
    for bank in args.data:
        with np.load(bank) as data:
            history, ticks = data["x"], data["t"]
            first_step, third_step = history[ticks == 0], history[ticks == 2]
            if len(first_step) != len(third_step) or not len(first_step):
                raise ValueError(f"Expected matching physical onset samples in {bank}")
            # At t=2 the stored history contains both earlier physical steps.
            second_step = np.concatenate([third_step[:, :1], third_step[:, :4]], axis=1)
            starts.extend([first_step, second_step])
            steady.append(history[ticks >= 2])
    onset = torch.as_tensor(np.concatenate(starts), device=args.device)
    steady = torch.as_tensor(np.concatenate(steady), device=args.device)
    observation_index = torch.as_tensor(MOTION_TRAIN_INDEX, device=args.device)
    correction = torch.zeros_like(difference, requires_grad=True)
    optimizer = torch.optim.Adam([correction], lr=args.lr)

    def downstream(first_hidden):
        hidden = torch.nn.functional.elu(first_hidden)
        for weight, bias in layers[1:-1]:
            hidden = torch.nn.functional.elu(hidden @ weight + bias)
        return hidden @ layers[-1][0] + layers[-1][1]

    for step in range(1, args.updates + 1):
        histories = torch.cat(
            [
                storage[torch.randint(len(storage), (count,), device=args.device)]
                for storage, count in ((onset, args.onset), (steady, 384 - args.onset))
            ]
        ).float()
        if step % 2:
            histories = motion_train_noisy_history(histories, torch)
        observations = histories.flatten(1)[:, observation_index]
        yaws = observations[:, YAW_ROWS]
        first_hidden = observations @ layers[0][0] + layers[0][1]
        with torch.no_grad():
            target = downstream(first_hidden + yaws[:, -1:].sign() * (yaws @ difference))
        actual = downstream(first_hidden + yaws @ correction)
        loss = (actual - target).square().mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if step % args.save_every == 0:
            first_weights = first.copy()
            first_weights[YAW_ROWS] += correction.detach().cpu().numpy()
            for prefix in ("avg", "pi"):
                fields[f"{prefix}/0/w"] = first_weights
            np.savez(args.out / f"{step:06d}.npz", **fields)
            print(step, loss.item(), flush=True)


def teachers(args):
    """Create offline supervision for clockwise and counterclockwise turns."""
    from tools.calibrate_zenbot_commands import calibrate

    args.out.mkdir(parents=True, exist_ok=True)
    left = args.out / "turn_left.npz"
    calibrate(args.policy, left, (1.04, 2.0), (0.95, 0.5))
    calibrate(args.policy, args.out / "turn_right.npz", (1.04, 2.0), (0.94, 2.3))
    # A small horizontal velocity request during turn onset reduced initial drift in the left teacher.
    with np.load(left) as target, np.load(args.policy) as original:
        fields = dict(target)
        for prefix in ("avg", "pi"):
            key = f"{prefix}/0/w"
            weights = fields[key]
            for axis, (steady, onset) in enumerate(((0.045, -0.7), (-0.04, 0.55))):
                translation = original[key][np.array([18, 21, 24]) + axis]
                weights[YAW_ROWS] += steady * translation
                pulse = onset * translation.sum(axis=0)
                weights[26] += pulse
                weights[20] -= pulse
    np.savez(left, **fields)


def transfer(args):
    """Apply the demonstrated yaw change to the selected slow get-up checkpoint."""
    from tools.calibrate_zenbot_commands import calibrate

    args.out.mkdir(parents=True, exist_ok=True)
    with np.load(args.policy) as base, np.load(args.source) as source, np.load(args.fitted) as fitted:
        fields = dict(base)
        for prefix in ("avg", "pi"):
            key = f"{prefix}/0/w"
            # Keep the original column-major array so the source NumPy controller uses its original BLAS path.
            fields[key][YAW_ROWS] += 1.2 * (fitted[key][YAW_ROWS] - source[key][YAW_ROWS])
    pivot = args.out / "pivot.npz"
    np.savez(pivot, **fields)
    calibrate(pivot, args.out / "policy.npz", (1.11, 1.9), (1.0, 0.0))
    write_recipe(args.out / "transfer.json", [args.policy, args.source, args.fitted])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    collector = commands.add_parser(
        "collect", help="Record 8-second turns from successful 12-second native get-ups"
    )
    make_teachers = commands.add_parser("teachers", help="Construct the two turning demonstrators")
    fitter = commands.add_parser("fit", help="Fit a single MLP to both turning demonstrators")
    apply = commands.add_parser("transfer", help="Apply learned yaw rows and the release lateral calibration")
    for sub in (collector, make_teachers, apply):
        sub.add_argument("policy", type=Path, help="Initial 234-input actor")
    collector.add_argument("out", type=Path, help="Rollout bank (.npz)")
    collector.add_argument(
        "--teacher", type=Path, default=Path("releases/zenbot_four_skills/teachers/motion_train_14300.npz")
    )
    collector.add_argument("--seeds", type=int, nargs="+", required=True)
    collector.add_argument("--trials", type=int, nargs="+", default=list(range(0, 22, 2)))
    collector.add_argument(
        "--share", type=float, default=0.3, help="Fraction of student action executed during collection"
    )
    collector.add_argument("--kp", type=float, default=1.7, help="Position gain on teacher translation requests")
    collector.add_argument("--kd", type=float, default=0.4, help="Velocity gain on teacher translation requests")
    collector.add_argument("--yaw-bias", type=float, default=1.35)
    collector.add_argument("--yaw-p", type=float, default=1.0)
    collector.add_argument("--yaw-i", type=float, default=1.0)
    collector.add_argument("--yaw-smoothing", type=float, default=0.12)
    collector.add_argument(
        "--feedback-student",
        action="store_true",
        help="Correct student demonstration commands with measured drift",
    )
    collector.add_argument(
        "--keep-success", action="store_true", help="Keep only complete trials passing the native pivot evaluator"
    )
    collector.add_argument(
        "--executed-labels", action="store_true", help="Store the action executed by the simulator as the label"
    )
    make_teachers.add_argument("out", type=Path, help="Teacher checkpoint directory")
    fitter.add_argument("left_policy", type=Path)
    fitter.add_argument("right_policy", type=Path)
    fitter.add_argument("out", type=Path, help="Fitted checkpoint directory")
    fitter.add_argument(
        "--data", nargs="+", type=Path, required=True, help="Physical state banks from the collect command"
    )
    fitter.add_argument("--onset", type=int, default=192, help="Command onset states per batch of 384")
    fitter.add_argument("--lr", default=0.0025, type=float)
    fitter.add_argument("--seed", default=8821, type=int)
    fitter.add_argument("--updates", default=800, type=int)
    fitter.add_argument("--save-every", default=800, type=int)
    fitter.add_argument("--device", default="cuda")
    apply.add_argument("source", type=Path, help="Base actor used to construct the turning teachers")
    apply.add_argument("fitted", type=Path, help="Checkpoint from the fit step")
    apply.add_argument("out", type=Path, help="Destination for pivot.npz and policy.npz")
    args = parser.parse_args()
    if args.command == "fit" and not (
        0 <= args.onset < 384 and 0 < args.save_every <= args.updates and args.lr > 0
    ):
        parser.error("Use a valid batch fraction, learning rate and checkpoint interval")
    if args.command == "collect" and not (0 <= args.share <= 1 and 0 < args.yaw_smoothing <= 1):
        parser.error("Student share and gyro smoothing must lie between zero and one")
    {"collect": collect, "teachers": teachers, "fit": fit, "transfer": transfer}[args.command](args)


if __name__ == "__main__":
    main()
