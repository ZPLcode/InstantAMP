#include <mujoco/mujoco.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdint>
extern "C" void batch(const mjModel* m, const uintptr_t* ptr, int n, const double* motor,
                      const int* delay,const int* kind,const double* nominal,const double* action,const double* prev,
                      const double* older,double* pos,double* vel,double* loads,int* illegal,double* maximum,int* flight) {
  for(int i=0;i<n;i++){
    mjData* d=reinterpret_cast<mjData*>(ptr[i]);
    loads[2*i]=loads[2*i+1]=0; illegal[i]=-1; maximum[i]=0.;
    for(int s=0;s<4;s++){
      for(int j=0;j<23;j++){
        int k=23*i+j, lag=delay[k]; double applied=s>=lag?action[k]:(s+4>=lag?prev[k]:older[k]);
        double speed=d->qvel[6+j], torque=std::clamp(motor[j]*(nominal[j]+.25*applied-d->qpos[7+j])-motor[23+j]*speed,-motor[46+j],motor[46+j]);
        d->ctrl[j]=std::abs(speed)>=motor[69+j] && torque*speed>0.?0.:torque;
      }
      mj_step(m,d);flight[4*i+s]=1;
      for(int j=0;j<d->ncon;j++){
        const auto& c=d->contact[j];
        int g=c.geom[0]==0?c.geom[1]:(c.geom[1]==0?c.geom[0]:-1);
        if(g<0)continue;
        double f[6];mj_contactForce(m,d,j,f);
        if(f[0]>1.)flight[4*i+s]=0;
        if(kind[g]>=0 && kind[g]<2)loads[2*i+kind[g]]+=f[0]*.25;
        if(kind[g]==2 && f[0]>1. && f[0]>maximum[i]){illegal[i]=g;maximum[i]=f[0];}
      }
    }
    std::memcpy(pos+30*i,d->qpos,30*sizeof(double));std::memcpy(vel+29*i,d->qvel,29*sizeof(double));
  }
}
