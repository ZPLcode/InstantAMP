"""Pack verified native recovery trajectories and their per-step physical feedback matrices."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from instantamp import zenbot
from tools.prepare_zenbot_scratch_pairs import NativeWorld


def pack(plans, gains_dir, floor_dir, output, selection=None, *, compute_missing=False):
    world = NativeWorld()
    folders = [plans] if isinstance(plans, Path) else plans
    gain_dirs = [gains_dir] if isinstance(gains_dir, Path) else gains_dir
    selected = json.loads(selection.read_text())["sources"] if selection else None
    entries = [
        (folder, entry)
        for folder in folders
        for entry in json.loads((folder / "manifest.json").read_text())["trajectories"].values()
    ]
    motions = {}
    h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    floor = sorted(floor_dir.glob("*.npz"))
    if not floor:
        raise ValueError("Missing source recovery motions")
    for folder, entry in entries:
        path = folder / entry["filename"]
        with np.load(path, allow_pickle=False) as a:
            seed, name = int(a["seed"]), str(a["source_clip"])
            if selected is None:
                if seed != 42:
                    continue
                opening_hold_ticks = 0
            else:
                choice = selected.get(name, {})
                if choice.get("seed") != seed or choice.get("plan_sha256") != entry["sha256"]:
                    continue
                opening_hold_ticks = int(choice["opening_hold_ticks"])
                if opening_hold_ticks < 0 or opening_hold_ticks >= len(a["raw_action"]):
                    raise ValueError(f"Invalid opening hold in {path}")
                if opening_hold_ticks:
                    with np.load(floor_dir / name, allow_pickle=False) as clip:
                        opening_q = clip["dof_pos"][0]
                    actual_q = zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * a["raw_action"][:opening_hold_ticks]
                    if not np.allclose(actual_q, opening_q, atol=2e-6, rtol=0.0):
                        raise ValueError(f"Declared opening hold differs from the raw joint posture in {path}")
            if name in motions or int(a["source_frame"]) != 0:
                raise ValueError(f"Expected exactly one selected frame-zero plan per clip: {name}")
            if (
                h(path) != entry["sha256"]
                or not bool(a["release_first_rise_held"] and a["hand_to_feet"])
                or float(a["external_assist_newtons"]) != 0.0
            ):
                raise ValueError(f"Unverified physical trajectory {path}")
            key = entry["sha256"][:16] + ".npy"
            gain_file = next((d / key for d in gain_dirs if (d / key).is_file()), None)
            if gain_file is None and compute_missing:
                from tools.zenbot_reference_feedback import local_gains
                cache = gain_dirs[0]
                cache.mkdir(exist_ok=True, parents=True)
                raw = a["raw_action"]
                requested = zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * raw
                delay = np.ascontiguousarray(a["delays"][zenbot.GROUP], np.int32)
                value = local_gains(world, a["qpos"], a["qvel"], requested, delay, cache_dir=cache)
                gain_file = cache / key
                candidate = gain_file.with_suffix(".pending.npy")
                np.save(candidate, value, allow_pickle=False)
                candidate.replace(gain_file)
            if gain_file is None:
                raise FileNotFoundError(f"Missing physical feedback matrix {key}")
            gain = np.load(gain_file, allow_pickle=False)
            steps = len(gain)
            if gain.shape != (len(a["raw_action"]), 23, 104) or not np.isfinite(gain).all():
                raise ValueError(f"Expected a full-trajectory 23-by-104 gain for every action in {gain_file}")
            loads = a["physical"]
            supported = (loads[:, 0] > 0.58) & (loads[:, 0] <= 0.78) & (loads[:, 1] > 0.866) & (loads[:, 2] > 0.5)
            first = np.flatnonzero(np.convolve(supported.astype(int), np.ones(10), "valid") >= 10)
            if not len(first) or steps < min(len(loads), int(first[0]) + 50):
                raise ValueError(f"Feedback cache does not cover the ground-to-standing transition for {name}")
            quiet = (
                supported
                & (loads[:, 4] < 0.1)
                & (np.linalg.norm(a["qvel"][1:, :2], axis=1) < 0.12)
                & (np.linalg.norm(a["qvel"][1:, 3:5], axis=1) < 0.5)
            )
            stable = np.flatnonzero(np.convolve(quiet.astype(int), np.ones(25), "valid") >= 25)
            if not len(stable):
                raise ValueError(f"No quiet supported stance in the selected physical trace {name}")
            use = steps
            motions[name] = (
                a["qpos"][:use],
                a["qvel"][:use],
                a["raw_action"][:use],
                gain[:use],
                a["delays"],
                str(a["source_sha256"]),
                entry["sha256"],
                h(gain_file),
                int(stable[0]),
                seed,
                opening_hold_ticks,
            )
    if set(motions) != {p.name for p in floor}:
        raise ValueError("Every training floor clip needs its seed-42 physical trajectory and feedback gain")
    rows = [motions[p.name] for p in floor]
    if [h(p) for p in floor] != [r[5] for r in rows]:
        raise ValueError("A raw recovery motion differs from the physical planning input")
    n = max(len(r[0]) for r in rows)
    table = {}
    for i, key in enumerate(("q", "v", "raw", "gain")):
        table[key] = np.stack(
            [np.pad(r[i], [(0, n - len(r[i]))] + [(0, 0)] * (r[i].ndim - 1), mode="edge") for r in rows]
        ).astype(np.float32)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        **table,
        delay_groups=np.asarray([r[4] for r in rows], np.int32),
        lengths=np.asarray([len(r[0]) for r in rows], np.int32),
        settled=np.asarray([r[8] for r in rows], np.int32),
        clip_names=[p.name for p in floor],
        selected_seed=np.array([r[9] for r in rows], np.int32),
        opening_hold=np.array([r[10] for r in rows], np.int32),
        source_sha256=[r[5] for r in rows],
        plan_sha256=[r[6] for r in rows],
        gain_sha256=[r[7] for r in rows],
        stance_quat=world.stance[3:7].astype(np.float32),
        stance_torque=world.feedforward.astype(np.float32),
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plans", type=Path, nargs="+", required=True)
    p.add_argument("--gains-dir", type=Path, nargs="+", required=True)
    p.add_argument("--compute-missing", action="store_true", help="Generate missing gains from native MuJoCo in the first cache directory")
    p.add_argument(
        "--selection", type=Path, help="Prevalidated source plan SHA and seed for each input recovery clip"
    )
    p.add_argument("--floor-dir", type=Path, default=Path("data/zenbot23_walk_run_recovery/recovery"))
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    pack(a.plans, a.gains_dir, a.floor_dir, a.out, a.selection, compute_missing=a.compute_missing)
