"""Rebuild Motion Train 234-observation pairs from the 46 native Zenbot gait reference windows."""
import argparse
import fcntl
import hashlib
import io
import json
import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

if __name__ == "__main__":
    os.environ["JAX_PLATFORMS"] = "cpu"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"
    if not __package__:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import jax
import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp import zenbot
from tools.evaluate_zenbot_directions import heading_kinematics
from tools.prepare_zenbot_scratch_pairs import NativeWorld
from tools.zenbot_reference_feedback import local_gains, with_training_sensors

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BANK = ROOT / "data/zenbot23_physical_gait"
SPLITS = (("train", 40, 910001), ("valid", 10, 610021))


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def advance(world, data, target, previous, older, delay):
    """Advance one control interval and return average foot load and all four physics flight flags."""
    forces = np.zeros(2)
    airborne = np.ones(4, dtype=bool)
    wrench = np.empty(6)
    for tick in range(4):
        applied = np.where(tick >= delay, target, np.where(tick + 4 >= delay, previous, older))
        velocity = data.qvel[6:]
        torque = np.clip(zenbot.KP * (applied - data.qpos[7:]) - zenbot.KD * velocity,
                         -zenbot.EFFORT, zenbot.EFFORT)
        data.ctrl[:] = np.where((abs(velocity) >= zenbot.SPEED) & (torque * velocity > 0), 0., torque)
        mujoco.mj_step(world.model, data)
        for i, contact in enumerate(data.contact):
            if world.floor not in contact.geom:
                continue
            mujoco.mj_contactForce(world.model, data, i, wrench)
            airborne[tick] &= wrench[0] <= 1.
            geom = contact.geom2 if contact.geom1 == world.floor else contact.geom1
            if geom in world.soles:
                forces[world.soles.index(geom)] += max(0., wrench[0])
    return forces / (4 * world.body_weight), airborne


def accepted(qpos, loads, airborne, cmd, start):
    up = 1. - 2. * np.square(qpos[:, 4:6]).sum(axis=1)
    steady = ((qpos[:, 2] >= .42) & (up >= .55)).all()
    upright_tail = ((qpos[start+1:, 2] > .58) & (up[start+1:] > .80)).all()
    speeds, _ = heading_kinematics(qpos)
    tail = speeds[start:]
    axis = int(np.argmax(abs(cmd)))
    tolerance = np.array([.36, .30, .65])
    tolerance[axis] = max(.23 if axis == 2 else .17, abs(cmd[axis]) * .5)
    aligned = (abs(tail.mean(axis=0) - cmd) <= tolerance).all()
    sign = np.sign(cmd[axis])
    aligned &= min(sign * tail[:10, axis].mean(), sign * tail[10:, axis].mean()) > .2 * abs(cmd[axis])
    if not (steady and upright_tail and aligned and np.any(loads[start:].sum(axis=1) > .45)):
        return False
    if cmd[0] <= 2:
        return True
    left, right = (loads > .08).T
    lead = left[left ^ right]
    flight_edges = np.flatnonzero(np.diff(airborne.ravel().astype(np.int8), prepend=0, append=0))
    return bool(np.any(lead[1:] != lead[:-1]) and np.any(flight_edges[1::2] - flight_edges[::2] >= 2))


def simulate(world, demo, gains, seed, exact):
    rng = np.random.default_rng(seed)
    q, v, raw = (demo[k] for k in ("qpos", "qvel", "raw_action"))
    data = mujoco.MjData(world.model)
    mujoco.mj_setState(world.model, data, demo["initial_mj_integration_state"], mujoco.mjtState.mjSTATE_INTEGRATION)
    if not exact:
        data.qpos[7:] += rng.uniform(-.018, .018, 23)
        tilt = Rotation.from_euler("xy", rng.uniform(-.7, .7, 2), degrees=True)
        data.qpos[3:7] = (Rotation.from_quat(data.qpos[3:7], scalar_first=True) * tilt).as_quat(scalar_first=True)
        data.qvel[:2] += rng.uniform(-.065, .065, 2)
        data.qvel[3:6] += rng.uniform(-.06, .06, 3)
    mujoco.mj_forward(world.model, data)
    history = np.concatenate((demo["initial_prev_raw"], raw))
    older, previous = history[:2]
    delays = demo["delays"].copy()
    if not exact and seed % 4 == 0:
        delays = np.clip(delays + rng.integers(-1, 2, len(delays)), 3, 7)
    err = np.empty(world.model.nv)
    frames, labels, poses, loads, flight = [], [], [data.qpos.copy()], [], []
    for t in range(len(raw)):
        observation, _ = world.measure(data, demo["command"], previous)
        mujoco.mj_differentiatePos(world.model, err, 1., q[t], data.qpos)
        difference = np.r_[err, data.qvel - v[t], .25 * (previous - history[t+1]), .25 * (older - history[t])]
        label = raw[t] + np.clip(gains[t] @ difference, -.55, .55) / .25
        behavior = label if exact else label + rng.normal(0., .045, 23)
        labels.append(label)
        frames.append(observation)
        targets = [zenbot.DEFAULT_Q + .25 * action for action in (behavior, previous, older)]
        load, air = advance(world, data, *targets, delays[zenbot.GROUP])
        older, previous = previous, behavior
        poses.append(data.qpos.copy())
        loads.append(load)
        flight.append(air)
    if accepted(np.asarray(poses), np.asarray(loads), np.asarray(flight), demo["command"], int(demo["score_from_step"])):
        return np.concatenate((demo["prefix_raw_frames"], frames)).astype(np.float32), np.asarray(labels, np.float32)
    return None


def read_demo(archive, row, clips, nstate):
    blob = archive.read(row["file"])
    if hashlib.sha256(blob).hexdigest() != row["sha256"]:
        raise ValueError(f"Window checksum failed for {row['file']}")
    with np.load(io.BytesIO(blob), allow_pickle=False) as entries:
        demo = dict(entries)
    t = row["steps"]
    shapes = dict(qpos=(t+1, 30), qvel=(t+1, 29), raw_action=(t, 23), pd_target=(t, 23),
                  prefix_raw_frames=(4, 78), initial_prev_raw=(2, 23), delays=(5,), command=(3,),
                  initial_mj_integration_state=(nstate,))
    if any(demo[k].shape != v or not np.isfinite(demo[k]).all() for k, v in shapes.items()):
        raise ValueError(f"Invalid state/action schema for {row['file']}")
    if (str(demo["source_clip"]) != row["clip"] or str(demo["source_sha256"]) != clips[row["clip"]]["converted_sha256"]
            or int(demo["seed"]) != row["seed"] or int(demo["source_frame"]) != row["start_frame"]
            or str(demo["mode"]) != row["mode"] or int(demo["score_from_step"]) != row["score_from_step"]
            or not np.array_equal(demo["command"], zenbot.DIRECTIONAL_COMMANDS[row["skill"] - 1].astype(float))):
        raise ValueError(f"Incorrect source or command for {row['file']}")
    np.testing.assert_allclose(demo["pd_target"], zenbot.DEFAULT_Q + .25 * demo["raw_action"], atol=1e-12)
    return demo


def prepare(bank, out, *, threads=2, verify_clips=None, require_canonical=False):
    bank, out = Path(bank), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with (out / ".gait_build").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return _build(bank, out, threads, verify_clips, require_canonical, lock)


def _build(bank, out, threads, verify_clips, require_canonical, lock):
    manifest = json.loads((bank / "manifest.json").read_text())
    if manifest["schema"] != 1 or len(manifest["windows"]) != 46:
        raise ValueError("Expected the 46-window Zenbot physical gait bank")
    if sha256(bank / "windows.zip") != manifest["windows_sha256"]:
        raise ValueError("Physical window archive checksum failed")
    if sha256(ROOT / "assets/zenbot_23dof_43kg.xml") != manifest["body_asset_sha256"]:
        raise ValueError("The physical gait bank requires the matching Zenbot MJCF")
    if verify_clips:
        motion = Path(verify_clips)
        checks = json.loads((motion / "sampling.json").read_text())["source_sha256"]
        for name, source in manifest["clips"].items():
            if sha256(motion / name) != source["converted_sha256"] or checks[Path(name).stem] != source["raw_sha256"]:
                raise ValueError(f"Motion source mismatch for {name}")
    manifest_digest = sha256(bank / "manifest.json")
    source_hashes = {name: sha256(Path(__file__).with_name(name)) for name in
                     ("prepare_zenbot_physical_gait.py", "zenbot_reference_feedback.py", "zenbot_reference_tangent.cc")}
    outputs = [out / (name + ".npz") for name, _, _ in SPLITS]
    report = out / "gait_pairs.json"
    lock.seek(0)
    previous_build = lock.read().strip()
    if previous_build and previous_build != manifest_digest:
        raise ValueError(f"Another gait bank owns the output directory {out}")
    if report.exists():
        info = json.loads(report.read_text())
        if info["manifest_sha256"] != manifest_digest:
            raise ValueError(f"Existing gait-pair report identifies another source bank in {out}")
        if (info.get("generator_sha256") == source_hashes
                and all(p.is_file() and sha256(p) == info["pairs"][p.stem]["sha256"] for p in outputs)
                and (not require_canonical or all(v["matches_canonical"] for v in info["pairs"].values()))):
            return info
    elif not previous_build and any(p.exists() for p in outputs):
        raise ValueError(f"Unidentified pair archives already exist in {out}")
    if not previous_build:
        lock.write(manifest_digest + "\n")
        lock.flush()
    world = NativeWorld()
    size = mujoco.mj_stateSize(world.model, mujoco.mjtState.mjSTATE_INTEGRATION)
    results = {name: [] for name, _, _ in SPLITS}
    checks = {}
    with ZipFile(bank / "windows.zip") as archive:
        for i, row in enumerate(manifest["windows"]):
            demo = read_demo(archive, row, manifest["clips"], size)
            gains = local_gains(world, demo["qpos"], demo["qvel"], demo["pd_target"],
                                demo["delays"][zenbot.GROUP], demo["initial_prev_raw"],
                                cache_dir=out / ".cache", threads=threads)
            checks[row["file"]] = {}
            for split, repeats, start in SPLITS:
                accepted_rows = []
                for j in range(repeats):
                    pair = simulate(world, demo, gains, start + 101 * i + j, exact=(split == "train" and j == 0))
                    if pair is not None:
                        accepted_rows.append(pair)
                checks[row["file"]][split] = len(accepted_rows)
                if not accepted_rows:
                    continue
                frames, targets = zip(*accepted_rows, strict=True)
                raw = jnp.asarray(np.stack(frames, axis=1))
                sensor = with_training_sensors(raw, jax.random.PRNGKey(start + i))
                obs = np.asarray(sensor)[len(demo["prefix_raw_frames"]):].transpose(1, 0, 2).reshape(-1, 234)
                actions = np.concatenate(targets)
                results[split].append((obs, actions, np.full(len(actions), row["skill"], np.uint8)))
            print(f"{i+1:2d}/46 {row['file']} {checks[row['file']]}", flush=True)
    info = dict(manifest_sha256=manifest_digest, windows_sha256=manifest["windows_sha256"],
                generator_sha256=source_hashes, versions=dict(numpy=np.__version__, jax=jax.__version__, mujoco=mujoco.__version__),
                per_window=checks, pairs={})
    with TemporaryDirectory(dir=out) as stage_name:
        stage = Path(stage_name)
        for split, _, _ in SPLITS:
            obs, raw, skill = (np.concatenate(x) for x in zip(*results[split], strict=True))
            if (not np.isfinite(obs).all() or not np.isfinite(raw).all()
                    or set(np.unique(skill)) != set(range(2, 9))):
                raise ValueError(f"Incomplete physical gait pairs in {split}")
            path = stage / (split + ".npz")
            np.savez_compressed(path, obs=obs, q_target_raw=raw, skill=skill)
            digest = sha256(path)
            matched = digest == manifest["canonical_pairs"][split]["sha256"]
            if require_canonical and not matched:
                raise ValueError(f"{split} differs from the canonical result: {digest}")
            info["pairs"][split] = dict(rows=len(skill), per_skill=np.bincount(skill, minlength=9).tolist(),
                                        sha256=digest, matches_canonical=matched)
        (stage / report.name).write_text(json.dumps(info, indent=2) + "\n")
        for path in [*outputs, report]:
            os.replace(stage / path.name, path)
    return info


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bank", type=Path, default=DEFAULT_BANK)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--verify-clips", type=Path, metavar="WALK_RUN_DIR")
    parser.add_argument("--require-canonical", action="store_true", help="Require the reference machine's exact array archives")
    args = parser.parse_args()
    result = prepare(args.bank, args.out, threads=args.threads, verify_clips=args.verify_clips,
                     require_canonical=args.require_canonical)
    print(json.dumps(result["pairs"], indent=2))
