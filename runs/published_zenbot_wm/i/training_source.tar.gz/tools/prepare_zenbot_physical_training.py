"""Build supervised motor examples from physical recovery traces, free standing and source gait windows."""

import argparse
import hashlib
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp import zenbot
from instantamp import zenbot_online_ground
from instantamp.zenbot_online_ground import labels, load_bank
from tools.prepare_zenbot_scratch_pairs import NativeWorld, STAND, read_motion
from tools.zenbot_reference_feedback import with_training_sensors


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def shifted_actions(actions, nominal_delay, actual_delay):
    """Align requests per joint with the delivery time in the current simulated world."""
    blend = ((actual_delay - nominal_delay) / 4.0)[zenbot.GROUP]
    t = np.arange(len(actions))[:, None] + np.sign(blend).astype(int)
    neighbor = actions[np.clip(t, 0, len(actions) - 1), np.arange(len(blend))]
    neighbor = np.where(t < 0, 0.0, neighbor)
    return actions + np.abs(blend) * (neighbor - actions)


def raw_frame(q, v, previous):
    gravity = -Rotation.from_quat(q[3:7], scalar_first=True).as_matrix()[2]
    return np.r_[v[3:6], gravity, np.zeros(3), q[7:], v[6:], previous].astype(np.float32)


def perturb(data, rng, amount):
    data.qpos[7:] += amount * rng.uniform(-0.035, 0.035, size=23)
    r = Rotation.from_quat(data.qpos[3:7], scalar_first=True)
    tilt = Rotation.from_euler("xy", amount * rng.uniform(-0.035, 0.035, size=2))
    data.qpos[3:7] = (r * tilt).as_quat(scalar_first=True)
    data.qvel[:2] += amount * rng.uniform(-0.07, 0.07, size=2)


def floor_randomization(count, nominal_delay, rng):
    """Sample delays, initial perturbations, and action noise independently within each start phase."""
    delays = rng.integers(3, 8, (count, 5), dtype=np.int32)
    amount = rng.uniform(0.4, 1.3, count)
    noise = np.full((count, 1), 0.035, np.float32)
    for phase in range(4):
        indices = np.arange(phase, count, 4)
        if not len(indices):
            continue
        n = max(1, round(len(indices) / 8)) if len(indices) >= 2 else 0
        delays[rng.choice(indices, n, replace=False)] = nominal_delay
        amount[rng.choice(indices, n, replace=False)] = 0.0
        noise[rng.choice(indices, n, replace=False)] = 0.0
    return delays, amount, noise


@jax.jit
def floor_targets(bank, clip, q, v, previous, older, start, elapsed, actual_delays):
    # A stationary floor episode always uses its tracked recovery path, including after standing.
    stationary = jnp.zeros((len(q), 3), q.dtype)
    ready = jnp.zeros(len(q), bool)
    lag = jnp.where(((start == 0) & (elapsed < 3))[:, None], 5, actual_delays)
    return labels(
        bank,
        q,
        v,
        previous,
        older,
        clip,
        start,
        elapsed,
        stationary,
        ready,
        jnp.zeros_like(stationary),
        lag,
        physical_reset_phase=True,
    )


def floor_episodes(world, bank, clip_index, seed, count, horizon, *, stop_after_phase=None, audit=None):
    q, v, raw, lag = (np.asarray(table[clip_index]) for table in (bank.q, bank.v, bank.raw, bank.delay_groups))
    settled = int(bank.settled[clip_index])
    length = int(bank.lengths[clip_index])
    windows = (
        (0, 1),
        (1, settled),
        (max(1, settled - 60), min(length - horizon, settled + 45)),
        (settled, min(length - horizon, settled + 215)),
    )
    rng = np.random.default_rng(seed)
    starts = np.empty(count, np.int32)
    delays, perturbation, noise = floor_randomization(count, lag, rng)
    previous = np.empty((count, 23), np.float32)
    older = np.empty_like(previous)
    frames = np.zeros((horizon + 4, count, 78), np.float32)
    target = np.zeros((horizon, count, 23), np.float32)
    valid = np.zeros((horizon, count), bool)
    matched = np.empty((horizon, count), np.int32) if audit is not None else None
    data = []
    zero = np.zeros(23, np.float32)
    for episode in range(count):
        low, high = windows[episode % 4]
        phase = min(int(rng.integers(low, max(low + 1, high))), length - horizon)
        starts[episode] = phase
        shifted = shifted_actions(raw, lag, delays[episode])
        previous[episode] = shifted[phase - 1] if phase >= 1 else zero
        older[episode] = shifted[phase - 2] if phase >= 2 else zero
        for j in range(4):
            k = max(0, phase - 4 + j)
            frames[j, episode] = raw_frame(q[k], v[k], shifted[k - 1] if k else zero)
        d = mujoco.MjData(world.model)
        d.qpos[:], d.qvel[:] = q[phase], v[phase]
        perturb(d, rng, perturbation[episode])
        mujoco.mj_forward(world.model, d)
        data.append(d)

    clips = np.full(count, clip_index, np.int32)
    active = np.ones(count, bool)
    for t in range(horizon):
        poses = np.asarray([d.qpos for d in data], np.float32)
        velocities = np.asarray([d.qvel for d in data], np.float32)
        action, kind, phase = floor_targets(
            bank, clips, poses, velocities, previous, older, starts, np.full(count, t, np.int32), delays
        )
        active &= np.asarray(kind) == 1
        target[t] = np.asarray(action)
        valid[t] = active if stop_after_phase is None else active & (np.asarray(phase) < stop_after_phase)
        if matched is not None:
            matched[t] = np.asarray(phase)
        applied = target[t] + (rng.normal(size=previous.shape) * noise).astype(np.float32)
        for i in np.flatnonzero(active):
            frames[t + 4, i] = raw_frame(data[i].qpos, data[i].qvel, previous[i])
            world.step(data[i], applied[i], previous[i], older[i], delays[i, zenbot.GROUP])
        older, previous = previous, applied
    observations = np.array(with_training_sensors(jnp.asarray(frames), jax.random.key(seed)))[4:]
    cold = starts == 0
    if np.any(cold):
        # A true floor reset refills all three slots with this same noisy, perturbed first observation.
        reset_key = jax.random.fold_in(jax.random.key(seed), 1)
        observations[:, cold] = np.asarray(with_training_sensors(jnp.asarray(frames[4:, cold]), reset_key))
    ticks = np.arange(horizon, dtype=np.int16)[:, None]
    opening_tick = np.where(cold[None, :] & (ticks < 3), ticks, -1).astype(np.int8)
    if audit is not None:
        kept = matched[valid]
        audit.update(
            cold_trials=int(cold.sum()), phase_reset_trials=int((~cold).sum()),
            cold_rows=int(valid[:, cold].sum()), phase_reset_rows=int(valid[:, ~cold].sum()),
            min_matched_phase=int(kept.min()) if kept.size else None,
            max_matched_phase=int(kept.max()) if kept.size else None,
        )
    return observations[valid], target[valid], opening_tick[valid]


def standing_episodes(world, standing_dir, seed, count, horizon):
    paths = sorted(standing_dir.glob("*.npz"))
    if not paths:
        raise ValueError(f"Empty standing bank: {standing_dir}")
    motions = [read_motion(path, STAND, i, world.model, world.soles) for i, path in enumerate(paths)]
    rng = np.random.default_rng(seed)
    frames = np.zeros((horizon, count, 78), np.float32)
    target = np.zeros((horizon, count, 23), np.float32)
    valid = np.zeros((horizon, count), bool)
    for i in range(count):
        motion = motions[i % len(motions)]
        t = rng.integers(len(motion.qpos))
        d = mujoco.MjData(world.model)
        d.qpos[:] = motion.qpos[t]
        d.qvel[:] = motion.recorded_velocity[t]
        perturb(d, rng, 0.0 if i % 4 == 0 else rng.uniform(0.4, 1.4))
        mujoco.mj_forward(world.model, d)
        older = previous = np.zeros(23, np.float32)
        delay = rng.integers(3, 8, 5)[zenbot.GROUP]
        error = np.empty(world.model.nv)
        for k in range(horizon):
            frame, measured = world.measure(d, (0.0, 0.0, 0.0), previous)
            if k in (12, 40, 65) and i % 4:
                d.qvel[:2] += rng.uniform(-0.10, 0.10, 2)
                d.qvel[3:5] += rng.uniform(-0.25, 0.25, 2)
                frame, measured = world.measure(d, (0.0, 0.0, 0.0), previous)
            mujoco.mj_differentiatePos(world.model, error, 1.0, world.stance, d.qpos)
            torque = world.feedforward.copy()
            torque[[4, 10]] += 100 * error[4] + 20 * d.qvel[4]
            torque[[5, 11]] += 100 * error[3] + 20 * d.qvel[3]
            label = (torque / (zenbot.KP * zenbot.ACTION_SCALE)).astype(np.float32)
            frames[k, i] = frame
            target[k, i] = label
            valid[k, i] = measured[1] > 0.95 and measured[2] > 0.60 and np.sum(measured[3:5]) >= 0.4
            action = label + rng.normal(0.0, 0.10 if i % 4 else 0.03, 23).astype(np.float32)
            world.step(d, action, previous, older, delay)
            older, previous = previous, action
    obs = np.asarray(with_training_sensors(jnp.asarray(frames), jax.random.key(seed)))
    return obs[valid], target[valid]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--floor-dir", type=Path, default=Path("data/zenbot23_walk_run_recovery/recovery"))
    parser.add_argument("--ground-bank", required=True, type=Path)
    parser.add_argument("--gait-pairs", required=True, type=Path)
    parser.add_argument("--standing-dir", type=Path, default=Path("data/zenbot23_walk_run_recovery/standing"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--train-trials", type=int, default=144)
    parser.add_argument("--valid-trials", type=int, default=32)
    args = parser.parse_args()
    if min(args.train_trials, args.valid_trials) < 1:
        parser.error("Each split needs at least one trial per clip")
    world = NativeWorld()
    args.out.mkdir(parents=True, exist_ok=True)
    bank = load_bank(args.ground_bank, args.floor_dir)
    with np.load(args.ground_bank, allow_pickle=False) as data:
        names = data["clip_names"].tolist()
    manifest = {
        "ground_bank_sha256": digest(args.ground_bank),
        "standing_sources": {p.name: digest(p) for p in sorted(args.standing_dir.glob("*.npz"))},
        "gait_pair_sha256": {s: digest(args.gait_pairs / (s + ".npz")) for s in ("train", "valid")},
        "generator_source_sha256": {
            "tools/prepare_zenbot_physical_training.py": digest(Path(__file__)),
            "instantamp/zenbot_online_ground.py": digest(Path(zenbot_online_ground.__file__)),
        },
        "bytes_sha256": {},
        "rows_per_skill": {},
        "opening_tick_counts": {},
        "source": "Reference motion and native MuJoCo only",
        "train_trials_per_clip": args.train_trials,
        "valid_trials_per_clip": args.valid_trials,
    }
    checks_path = args.out / "checks_v2.json"
    if checks_path.is_file():
        previous = json.loads(checks_path.read_text())
        inputs = [key for key in manifest if key not in ("bytes_sha256", "rows_per_skill", "opening_tick_counts")]
        if all(previous.get(key) == manifest[key] for key in inputs):
            outputs = [(split, args.out / (split + ".npz")) for split in ("train", "valid")]
            if all(path.is_file() and digest(path) == previous.get("bytes_sha256", {}).get(split) for split, path in outputs):
                print("Verified existing physical training and validation pairs.", flush=True)
                return
    for split, trials, seed in (("train", args.train_trials, 890051), ("valid", args.valid_trials, 940093)):
        chunks = []
        for i, name in enumerate(names):
            obs, action, opening_tick = floor_episodes(world, bank, i, seed + i * 421, trials, 100)
            chunks.append((obs, action, np.zeros(len(obs), np.uint8), opening_tick))
            print(split, name, len(obs), flush=True)
        obs, action = standing_episodes(world, args.standing_dir, seed + 507, trials * 2, 96)
        chunks.append((obs, action, np.ones(len(obs), np.uint8), np.full(len(obs), -1, np.int8)))
        gait_path = args.gait_pairs / (split + ".npz")
        with np.load(gait_path, allow_pickle=False) as d:
            use = (d["skill"] >= 2) & (d["skill"] <= 8)
            chunks.append(
                (
                    d["obs"][use],
                    d["q_target_raw"][use],
                    d["skill"][use].astype(np.uint8),
                    np.full(np.count_nonzero(use), -1, np.int8),
                )
            )
        obs, actions, skills, opening_tick = [np.concatenate(items) for items in zip(*chunks)]
        manifest["opening_tick_counts"][split] = {str(k): int(np.sum(opening_tick == k)) for k in (-1, 0, 1, 2)}
        if (
            obs.shape != (len(actions), 234)
            or actions.shape != (len(skills), 23)
            or not np.isfinite(obs).all()
            or not np.isfinite(actions).all()
        ):
            raise ValueError("Invalid reference observations or motor requests")
        counts = np.bincount(skills, minlength=9)
        if (counts == 0).any():
            raise ValueError(counts)
        path = args.out / (split + ".npz")
        tmp = path.with_suffix(".pending.npz")
        np.savez_compressed(tmp, obs=obs, q_target_raw=actions, skill=skills, opening_tick=opening_tick)
        tmp.replace(path)
        manifest["rows_per_skill"][split] = counts.tolist()
        manifest["bytes_sha256"][split] = digest(path)
    pending = checks_path.with_suffix(".pending.json")
    pending.write_text(json.dumps(manifest, indent=2) + "\n")
    pending.replace(checks_path)


if __name__ == "__main__":
    main()
