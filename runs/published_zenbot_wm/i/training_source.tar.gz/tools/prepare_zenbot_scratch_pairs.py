"""Prepare 234-input Zenbot PPO guidance pairs from AMP reference poses and native MuJoCo."""

import argparse
import hashlib
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory

if __name__ == "__main__":
    os.environ["JAX_PLATFORMS"] = "cpu"
    if not __package__:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import jax
import jax.numpy as jnp
import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

from instantamp import env, zenbot
from instantamp.sim import build_scene
from instantamp.zenbot_gait_demos import (
    directional_window_starts,
    gait_command_index,
    straight_window_starts,
)
from instantamp.zenbot_motion_train_obs import advance_sensors
from tools.prepare_zenbot_standing_amp import equilibrium

WINDOW, PREVIEW, PREFIX = 6, 2, 4
SKILLS = ("rise", "stand", "forward", "run", "back", "left", "right", "turn_left", "turn_right")
RISE, STAND, WALK, RUN = range(4)
COMMANDS = np.vstack((zenbot.DIRECTIONAL_COMMANDS[0], zenbot.DIRECTIONAL_COMMANDS))
MODES = ("phase", "official_floor", "supported_switch", "supported_cold", "walk_to_run")
PHASE, FLOOR, SWITCH, COLD, ACCELERATE = range(len(MODES))
SOURCES = ("reference", "recorded_onset", "closest_moving_phase", "walk_onset_for_run")
WALK_TO_RUN = "run__C5_-_walk_to_run_stageii"
PHYSICAL = (
    "pelvis_planar_mps",
    "pelvis_up",
    "pelvis_z_m",
    "left_foot_bw",
    "right_foot_bw",
    "joint_mae_default_rad",
    "vx_heading_mps",
    "vy_heading_mps",
    "yaw_radps",
)
ROOT = Path(zenbot.__file__).resolve().parents[1]


@dataclass(eq=False)
class Motion:
    index: int
    path: Path
    skill: int
    qpos: np.ndarray
    qvel: np.ndarray
    recorded_velocity: np.ndarray
    heading_velocity: np.ndarray
    feet: np.ndarray
    starts: np.ndarray
    allowed: dict = field(default_factory=dict)
    phases: dict = field(default_factory=dict)

    def target(self, frame):
        joint_target = self.qpos[frame, 7:] + zenbot.KD / zenbot.KP * self.qvel[frame, 6:]
        return (joint_target - zenbot.DEFAULT_Q) / zenbot.ACTION_SCALE

    def leading_foot(self, frame):
        distance = np.linalg.norm(self.feet[frame + 1 : frame + 18] - self.feet[frame], axis=-1).max(0)
        return int(np.argmax(distance))


def read_motion(path, skill, index, model, soles):
    with np.load(path, allow_pickle=False) as clip:
        if float(clip["fps"]) != 50.0:
            raise ValueError(f"Expected a 50 Hz reference in {path}")
        quat = clip["root_quat"]
        rotation = Rotation.from_quat(quat)
        qpos = np.c_[clip["root_pos"], quat[:, [3, 0, 1, 2]], clip["dof_pos"]].astype(float)
        recorded_velocity = np.c_[
            clip["root_lin_vel"], rotation.inv().apply(clip["root_ang_vel"]), clip["dof_vel"]
        ]
        if path.stem == WALK_TO_RUN:
            starts = np.arange(1, len(qpos) - WINDOW - PREVIEW)
        elif skill in (RISE, STAND):
            starts = np.arange(len(qpos) - WINDOW - PREVIEW + 1)
        elif skill in (WALK, RUN):
            starts = straight_window_starts(clip, WINDOW + PREVIEW, "walk" if skill == WALK else "run")
        else:
            starts = directional_window_starts(clip, WINDOW + PREVIEW, path.stem)
        if "key_body_pos" in clip:
            feet = clip["key_body_pos"][:, :2].astype(float)
        else:
            data = mujoco.MjData(model)
            feet = np.empty((len(qpos), 2, 3))
            for frame, pose in enumerate(qpos):
                data.qpos[:] = pose
                mujoco.mj_kinematics(model, data)
                feet[frame] = data.geom_xpos[soles]
    # The drive uses backward differences. Stored centered velocities are used only for official resets.
    qvel = np.zeros((len(qpos), model.nv))
    qvel[1:] = (
        np.c_[
            np.diff(qpos[:, :3], axis=0),
            (rotation[:-1].inv() * rotation[1:]).as_rotvec(),
            np.diff(qpos[:, 7:], axis=0),
        ]
        / env.DT
    )
    matrix = rotation.as_matrix()
    yaw = np.arctan2(matrix[:, 1, 0], matrix[:, 0, 0])
    cos, sin = np.cos(yaw), np.sin(yaw)
    heading_velocity = np.c_[
        cos * qvel[:, 0] + sin * qvel[:, 1],
        -sin * qvel[:, 0] + cos * qvel[:, 1],
        np.gradient(np.unwrap(yaw)) / env.DT,
    ]
    return Motion(
        index, path, skill, qpos, qvel, recorded_velocity, heading_velocity, feet, starts[starts >= 1]
    )


def split_motion(motion, rank, group_size):
    frames = np.arange(len(motion.qpos))
    height = motion.qpos[:, 2]
    up = (height > 0.58) & (height <= 0.78) & (1 - 2 * (motion.qpos[:, 4:6] ** 2).sum(1) > 0.8660254)
    sustained = np.flatnonzero(np.convolve(up, np.ones(10), "valid") >= 10)
    first_rise = int(sustained[0]) if len(sustained) else len(frames) - 1
    if motion.skill == RISE:
        # Retain every official opening for training. Hold out different contiguous rise phases.
        begin = int(np.clip(first_rise * (0.45, 0.62, 0.80)[motion.index % 3], 36, len(frames) - 25))
        validation = (frames >= begin) & (frames < begin + max(20, int(0.16 * first_rise)))
    elif motion.skill == STAND:
        validation = np.full(len(frames), rank % 5 == 0)
    elif motion.skill == WALK and group_size > 1:
        validation = np.full(len(frames), "Male2_" in motion.path.name)
    else:
        cut = (
            int(0.65 * len(frames))
            if motion.path.stem == WALK_TO_RUN
            else int(np.quantile(motion.starts, 0.7))
        )
        held_starts = motion.starts[motion.starts - 1 >= cut]
        if not len(held_starts):
            raise ValueError(f"No held-out starts in {motion.path}")
        validation = frames >= held_starts.min() - 1
    motion.allowed = {"train": ~validation, "valid": validation}
    for split, allowed in motion.allowed.items():
        # Include the preceding velocity frame, the input window, the preview and selector's velocity stencil.
        starts = np.array(
            [s for s in motion.starts if allowed[s - 1 : s + WINDOW + PREVIEW + 1].all()], dtype=int
        )
        if motion.skill == RISE:
            starts = starts[starts <= min(first_rise + 6, len(frames) - WINDOW - PREVIEW - 1)]
        motion.phases[split] = starts


def load_motions(bank, world):
    files = [
        (path, skill)
        for folder, skill in (("recovery", RISE), ("standing", STAND))
        for path in sorted((bank / folder).glob("*.npz"))
    ]
    for path in sorted((bank / "walk_run").glob("*.npz")):
        command = gait_command_index(path.stem)
        if command is not None and command > 0:
            files.append((path, command + 1))
    files.append((bank / "walk_run" / (WALK_TO_RUN + ".npz"), RUN))
    motions = [
        read_motion(path, skill, index, world.model, world.soles) for index, (path, skill) in enumerate(files)
    ]
    for skill, name in enumerate(SKILLS):
        group = [motion for motion in motions if motion.skill == skill]
        if not group:
            raise ValueError(f"No AMP references for {name} in {bank}")
        for rank, motion in enumerate(group):
            split_motion(motion, rank, len(group))
    return motions


class NativeWorld:
    def __init__(self):
        self.model = build_scene(robot_name="zenbot23_getup")
        self.soles = [self.model.geom(f"robot_{foot}_collision").id for foot in zenbot.FEET]
        self.stance, self.feedforward = equilibrium(self.model, self.soles)
        self.body_weight = self.model.body_mass.sum() * 9.81
        self.floor = self.model.geom("floor").id

    def step(self, data, action, previous, older, delays):
        for substep in range(env.DECIMATION):
            applied = np.where(
                substep >= delays, action, np.where(substep + env.DECIMATION >= delays, previous, older)
            )
            velocity = data.qvel[6:]
            torque = np.clip(
                zenbot.KP * (zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * applied - data.qpos[7:])
                - zenbot.KD * velocity,
                -zenbot.EFFORT,
                zenbot.EFFORT,
            )
            data.ctrl[:] = np.where((abs(velocity) >= zenbot.SPEED) & (torque * velocity > 0.0), 0.0, torque)
            mujoco.mj_step(self.model, data)

    def measure(self, data, command, previous):
        matrix = Rotation.from_quat(data.qpos[[4, 5, 6, 3]]).as_matrix()
        frame = np.r_[data.qvel[3:6], -matrix[2], command, data.qpos[7:], data.qvel[6:], previous].astype(
            np.float32
        )
        loads = np.zeros(2)
        wrench = np.empty(6)
        for index, contact in enumerate(data.contact):
            if self.floor not in contact.geom:
                continue
            geom = contact.geom1 if contact.geom2 == self.floor else contact.geom2
            if geom in self.soles:
                mujoco.mj_contactForce(self.model, data, index, wrench)
                loads[self.soles.index(geom)] += wrench[0] / self.body_weight
        yaw = np.arctan2(matrix[1, 0], matrix[0, 0])
        cos, sin = np.cos(yaw), np.sin(yaw)
        axis = matrix[:, 0]
        derivative = np.cross(matrix @ data.qvel[3:6], axis)
        yaw_rate = (axis[0] * derivative[1] - axis[1] * derivative[0]) / max(
            1e-8, axis[0] ** 2 + axis[1] ** 2
        )
        physical = np.r_[
            np.linalg.norm(data.qvel[:2]),
            matrix[2, 2],
            data.qpos[2],
            loads,
            np.mean(abs(data.qpos[7:] - zenbot.DEFAULT_Q)),
            cos * data.qvel[0] + sin * data.qvel[1],
            -sin * data.qvel[0] + cos * data.qvel[1],
            yaw_rate,
        ]
        return frame, physical

    def rollout(self, motion, start, skill, mode, delays, drive_age, standing, score_onset=False):
        data = mujoco.MjData(self.model)
        origin, frame = standing if standing is not None else (motion, start)
        data.qpos[:], data.qvel[:] = origin.qpos[frame], origin.qvel[frame]
        if mode == FLOOR:
            data.qpos[2] += zenbot.RESET_LIFT
            data.qpos[:2] = 0.0
            data.qvel[:] = origin.recorded_velocity[frame]
        mujoco.mj_forward(self.model, data)
        previous = older = np.zeros(self.model.nu)
        prefix = []
        if standing is not None:
            error = np.empty(self.model.nv)
            for tick in range(8):
                sensor, _ = self.measure(data, COMMANDS[STAND], previous)
                if tick >= 8 - PREFIX:
                    prefix.append(sensor)
                mujoco.mj_differentiatePos(self.model, error, 1.0, self.stance, data.qpos)
                torque = self.feedforward.copy()
                for joints, axis in (([4, 10], 4), ([5, 11], 3)):
                    torque[joints] += 100 * error[axis] + 20 * data.qvel[axis]
                action = torque / (zenbot.KP * zenbot.ACTION_SCALE)
                self.step(data, action, previous, older, delays)
                older, previous = previous, action
        if mode != SWITCH:
            previous = older = np.zeros(self.model.nu)
        frames, targets, measurements = [], [], []
        for tick in range(34 if score_onset else WINDOW):
            frame = min(start + tick, len(motion.qpos) - PREVIEW - 1)
            sensed, physical = self.measure(data, COMMANDS[skill], previous)
            if not prefix:
                prefix = [sensed] * PREFIX
            frames.append(sensed)
            measurements.append(physical)
            target = motion.target(frame + PREVIEW)
            targets.append(target)
            # The +2 target drives candidate selection only. Dataset observations see only causal motor inputs.
            action = target if score_onset else motion.target(max(start, frame - drive_age))
            self.step(data, action, previous, older, delays)
            older, previous = previous, action
        return (
            np.asarray(prefix + frames, np.float32),
            np.asarray(targets, np.float32),
            np.asarray(measurements, np.float32),
        )


def onset_candidates(motions, skill, split):
    reference_skill = WALK if skill == RUN else skill
    axis = int(np.argmax(abs(COMMANDS[reference_skill])))
    sign = np.sign(COMMANDS[reference_skill, axis])
    result = []
    for motion in motions:
        if motion.skill != reference_skill or motion.path.stem == WALK_TO_RUN:
            continue
        if reference_skill == WALK and "StandToWalk" not in motion.path.stem:
            continue
        allowed = motion.allowed[split]
        starts = np.array([i for i in range(3, len(allowed) - 26) if allowed[i - 3 : i + 26].all()], int)
        if not len(starts):
            continue
        velocity = motion.heading_velocity
        before = np.stack([velocity[i - 3 : i + 1].mean(0) for i in starts])
        after = np.array([sign * velocity[i + 8 : i + 23, axis].mean() for i in starts])
        slow = (np.linalg.norm(before[:, :2], axis=1) < 0.13) & (abs(before[:, 2]) < 0.25)
        onset = slow & (after > (0.32 if axis == 2 else 0.18)) & (after - sign * before[:, axis] > 0.08)
        candidates = starts[onset]
        recorded_onset = len(candidates) > 0
        if not recorded_onset:
            directed = starts[after > (0.25 if axis == 2 else 0.12)]
            candidates = directed if len(directed) else starts
        joint_error = abs(motion.qpos[candidates, 7:] - zenbot.DEFAULT_Q).mean(1)
        distance = (
            joint_error
            + 0.10 * np.linalg.norm(velocity[candidates, :2], axis=1)
            + 0.04 * abs(velocity[candidates, 2])
        )
        nearest = candidates[np.argsort(distance)[:10]]
        distributed = candidates[np.linspace(0, len(candidates) - 1, min(48, len(candidates))).astype(int)]
        kind = 3 if skill == RUN else (1 if recorded_onset else 2)
        result.extend((motion, int(t), kind) for t in np.unique(np.r_[nearest, distributed]))
    if not result:
        raise ValueError(f"No {SKILLS[skill]} reference onset in {split}")
    return result


def select_onsets(world, motions, phases, split):
    standing = phases[STAND][0]
    origin = standing, standing.phases[split][0]
    chosen = {}
    for skill in range(WALK, len(SKILLS)):
        axis = int(np.argmax(abs(COMMANDS[skill])))
        direction = np.sign(COMMANDS[skill, axis])
        options = onset_candidates(motions, skill, split)

        scores = []
        for motion, start, _ in options:
            _, _, measured = world.rollout(
                motion, start, skill, SWITCH, np.full(world.model.nu, 5), 0, origin, score_onset=True
            )
            upright = (measured[:, 1] > 0.8) & (measured[:, 2] > 0.58)
            speed = measured[12:30, 6 + axis].mean() * direction
            scores.append(
                (
                    bool(upright.all()),
                    float(speed),
                    -float(abs(motion.qpos[start, 7:] - zenbot.DEFAULT_Q).mean()),
                )
            )

        motion, start, _ = options[max(range(len(scores)), key=scores.__getitem__)]
        lead = motion.leading_foot(start)
        chosen[skill] = [
            option
            for option in options
            if option[0] is motion and abs(option[1] - start) <= 1 and motion.leading_foot(option[1]) == lead
        ]
    return chosen


def sample_start(rng, skill, index, split, phases, openings, onsets, acceleration):
    if skill == RISE and split == "train" and index % 3 == 0:
        motion, start = openings[(index // 3) % len(openings)]
        return motion, start, FLOOR, 0, None
    if skill >= WALK and index % 2 == 0:
        options = onsets[skill]
        motion, start, kind = options[rng.integers(len(options))]
        standing = phases[STAND][rng.integers(len(phases[STAND]))]
        origin = standing, rng.choice(standing.phases[split])
        return motion, start, SWITCH if index % 4 == 0 else COLD, kind, origin
    if skill == RUN and index % 4 == 1:
        return acceleration, int(rng.choice(acceleration.phases[split])), ACCELERATE, 0, None
    motion = phases[skill][rng.integers(len(phases[skill]))]
    return motion, int(rng.choice(motion.phases[split])), PHASE, 0, None


@jax.jit
def observations(frames, switches, key):
    sensors = None
    result = []
    for tick, noise_key in enumerate(jax.random.split(key, PREFIX + WINDOW)):
        frame = frames[:, tick]
        fresh = jnp.full(len(frame), tick == 0)
        if tick == PREFIX:
            fresh = ~switches
        sensors = advance_sensors(
            sensors,
            frame[:, :6],
            frame[:, 6:9],
            frame[:, 9:32],
            frame[:, 32:55],
            frame[:, 55:],
            fresh,
            noise_key,
            True,
        )
        if tick >= PREFIX:
            result.append(sensors.observation())
    return jnp.stack(result, axis=1)


def generate(world, motions, split, windows_per_command, seed):
    rng = np.random.default_rng(seed)
    acceleration = next(motion for motion in motions if motion.path.stem == WALK_TO_RUN)
    phases = [
        [
            motion
            for motion in motions
            if motion.skill == skill and motion is not acceleration and len(motion.phases[split])
        ]
        for skill in range(len(SKILLS))
    ]
    openings = [
        (motion, t)
        for motion in phases[RISE]
        for t in (0, 25)
        if motion.qpos[t, 2] + zenbot.RESET_LIFT <= 0.50
        and motion.allowed[split][max(0, t - 1) : t + WINDOW + PREVIEW + 1].all()
    ]
    onsets = select_onsets(world, motions, phases, split)
    metadata, frames, targets, telemetry = [], [], [], []
    for skill in range(len(SKILLS)):
        for index in range(windows_per_command * (8 if skill == RISE else 1)):
            motion, start, mode, kind, standing = sample_start(
                rng, skill, index, split, phases, openings, onsets, acceleration
            )
            delays = rng.integers(3, 8, 5)[zenbot.GROUP]
            sensed, target, measured = world.rollout(
                motion, start, skill, mode, delays, int(rng.integers(0, 3)), standing
            )
            if standing is not None and not (
                measured[0, 0] < 0.12
                and measured[0, 1] > 0.95
                and min(measured[0, 3:5]) >= 0.30
                and measured[0, 5] < 0.10
            ):
                raise ValueError(f"Unsupported standing start for {SKILLS[skill]}")
            metadata.append(
                (
                    skill,
                    motion.index,
                    start,
                    mode,
                    kind,
                    standing[0].index if standing else -1,
                    standing[1] if standing else -1,
                )
            )
            frames.append(sensed)
            targets.append(target)
            telemetry.append(measured)
    windows = np.asarray(frames)
    records = np.asarray(metadata, np.int32)
    modes = records[:, 3]
    batch_size = 128
    obs = []
    for start in range(0, len(windows), batch_size):
        batch = slice(start, start + batch_size)
        obs.append(
            np.asarray(
                observations(
                    windows[batch], jnp.asarray(modes[batch] == SWITCH), jax.random.PRNGKey(seed + start)
                )
            )
        )
    raw = np.concatenate(targets)
    skill, clip, frame, mode, kind, standing_clip, standing_frame = records.T

    def column(values, dtype):
        return np.repeat(values, WINDOW).astype(dtype)

    dataset = {
        "obs": np.concatenate(obs).reshape(-1, 234),
        "q_target_raw": raw,
        "target_q_rad": zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * raw,
        "skill": column(skill, "i1"),
        "clip": column(clip, "i2"),
        "time": (frame[:, None] + np.arange(WINDOW)).reshape(-1).astype("i4"),
        "mode": column(mode, "i1"),
        "source_kind": column(kind, "i1"),
        "standing_clip": column(standing_clip, "i2"),
        "standing_frame": column(standing_frame, "i2"),
        "episode_tick": np.tile(np.arange(WINDOW, dtype="i1"), len(records)),
        "physical": np.concatenate(telemetry),
    }
    return dataset, onsets


def coverage(dataset, onsets):
    skill, mode, tick = (dataset[key] for key in ("skill", "mode", "episode_tick"))
    beginnings = (tick == 0) & np.isin(mode, (COLD, SWITCH))
    result = {
        "rows": len(skill),
        "loaded_command_starts": int(beginnings.sum()),
        "cold_target_consistency": {},
    }
    for index, options in onsets.items():
        cold = (skill == index) & (mode == COLD)
        dispersion = []
        for step in range(3):
            legs = dataset["target_q_rad"][cold & (tick == step), :12]
            error = np.rad2deg(abs(legs - np.median(legs, axis=0)).mean(1))
            dispersion.append(float(error.max()))
        motion, start, _ = options[0]
        result["cold_target_consistency"][SKILLS[index]] = {
            "max_per_leg_joint_mae_degrees_first_3_ticks": dispersion,
            "unique_full_targets_at_tick0": len(
                np.unique(dataset["target_q_rad"][cold & (tick == 0)], axis=0)
            ),
            "lead": ("left", "right")[motion.leading_foot(start)],
        }
    return result


def source_frames(dataset):
    seen = set()
    reset = dataset["episode_tick"] == 0
    for clip, frame in zip(dataset["clip"][reset], dataset["time"][reset]):
        seen.update((int(clip), i) for i in range(max(0, frame - 1), frame + WINDOW + PREVIEW + 1))
    for clip, frame in zip(dataset["standing_clip"][reset], dataset["standing_frame"][reset]):
        if clip >= 0:
            seen.update(((int(clip), int(frame) - 1), (int(clip), int(frame))))
    return seen


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(bank, out, train_count=640, valid_count=96):
    world = NativeWorld()
    motions = load_motions(bank, world)
    sources = []
    for motion in motions:
        source = {"path": str(motion.path.relative_to(bank)), "sha256": sha256(motion.path)}
        for split, allowed in motion.allowed.items():
            boundaries = np.flatnonzero(np.diff(np.r_[False, allowed, False])).reshape(-1, 2)
            source[split] = [(int(lo), int(hi) - 1) for lo, hi in boundaries]
        sources.append(source)
    dependencies = [
        "instantamp/env.py",
        "instantamp/sim.py",
        "instantamp/zenbot.py",
        "instantamp/zenbot_gait_demos.py",
        "instantamp/zenbot_motion_train_obs.py",
        "tools/prepare_zenbot_standing_amp.py",
        "assets/zenbot_23dof_43kg.xml",
    ]
    hashes = {name: sha256(ROOT / name) for name in dependencies}
    hashes["tools/prepare_zenbot_scratch_pairs.py"] = sha256(Path(__file__))
    report = {
        "fps": 50,
        "preview_steps": PREVIEW,
        "horizon_steps": WINDOW,
        "history_prefix_frames": PREFIX,
        "skills": SKILLS,
        "modes": MODES,
        "source_kinds": SOURCES,
        "physical_columns": PHYSICAL,
        "action_order": list(zenbot.DOF),
        "command_targets": COMMANDS.tolist(),
        "source_ranges": sources,
        "q_target_raw_definition": "(q_ref[t+2]+KD/KP*backward_qdot_ref[t+2]-DEFAULT_Q)/.25",
        "generator_source_sha256": hashes,
        "bytes_sha256": {},
        "seeds": {"train": 82493, "valid": 89395},
    }
    validation, frame_sets = {}, {}
    out.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=out) as scratch:
        scratch = Path(scratch)
        for split, count in (("train", train_count), ("valid", valid_count)):
            dataset, onsets = generate(world, motions, split, count, report["seeds"][split])
            if not all(np.isfinite(value).all() for value in dataset.values()):
                raise ValueError(f"Nonfinite value in {split} data")
            validation[split] = coverage(dataset, onsets)
            if split == "train":
                official = (dataset["episode_tick"] == 0) & (dataset["mode"] == FLOOR)
                validation[split]["official_openings"] = len(
                    set(zip(dataset["clip"][official], dataset["time"][official]))
                )
            frame_sets[split] = source_frames(dataset)
            path = scratch / (split + ".npz")
            np.savez_compressed(path, **dataset)
            report["bytes_sha256"][split] = sha256(path)
            print(f"{split}: {len(dataset['obs']):,} observations", flush=True)
        if frame_sets["train"] & frame_sets["valid"]:
            raise ValueError("Train and validation windows share original reference frames")
        validation["train_validation_shared_observation_or_target_frames"] = 0
        for name, value in (("checks_v2.json", report), ("coverage.json", validation)):
            (scratch / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
        for name in ("train.npz", "valid.npz", "coverage.json", "checks_v2.json"):
            os.replace(scratch / name, out / name)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bank", type=Path, default=ROOT / "data/zenbot23_walk_run_recovery")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--train-per-command", type=int, default=640)
    parser.add_argument("--valid-per-command", type=int, default=96)
    args = parser.parse_args()
    if min(args.train_per_command, args.valid_per_command) < 3:
        parser.error("Provide at least three windows per command to include both standing-start modes")
    prepare(args.bank, args.out, args.train_per_command, args.valid_per_command)
