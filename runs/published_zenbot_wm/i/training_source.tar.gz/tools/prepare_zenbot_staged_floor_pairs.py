"""Prepare floor-only Motion Train observations with physical action labels up to the gait handoff."""

import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from instantamp import zenbot, zenbot_online_ground
from tools import prepare_zenbot_physical_training as physical
from tools import prepare_zenbot_scratch_pairs, zenbot_reference_feedback
from tools.prepare_zenbot_support_frames import sha256, support_frames

ROOT = Path(__file__).resolve().parents[1]
SPLITS = {"train": (144, 890051), "valid": (32, 940093)}


def inputs(bank_path, support_path, floor_dir, plans):
    support = json.loads(support_path.read_text())
    expected = support_frames(bank_path, plans)
    if support != expected:
        raise ValueError("Support indices, clip order or bank SHA differ from the original physical plans")
    source_files = [Path(__file__), Path(physical.__file__), Path(prepare_zenbot_scratch_pairs.__file__),
                    Path(zenbot_online_ground.__file__), Path(zenbot_reference_feedback.__file__), Path(zenbot.__file__),
                    ROOT / "tools/prepare_zenbot_support_frames.py", ROOT / "instantamp/zenbot_motion_train_obs.py",
                    ROOT / "instantamp/sim.py", ROOT / "assets/zenbot_23dof_43kg.xml"]
    return {
        **expected, "support_frames_sha256": sha256(support_path),
        "source": "Native MuJoCo recovery from the raw motion bank",
        "floor_source_sha256": {name: sha256(floor_dir / name) for name in expected["clip_names"]},
        "generator_source_sha256": {p.resolve().relative_to(ROOT).as_posix(): sha256(p) for p in source_files},
        "stop_before_phase": [k + 25 for k in expected["first_support"]], "horizon": 100,
        "splits": {s: {"trials_per_clip": n, "seed": seed, "clip_seed_stride": 421}
                   for s, (n, seed) in SPLITS.items()},
    }


def matches(out, identity):
    report = out / "checks_v2.json"
    if not report.is_file():
        return False
    try:
        manifest = json.loads(report.read_text())
        return all(manifest.get(k) == v for k, v in identity.items()) and all(
            (out / (s + ".npz")).is_file() and sha256(out / (s + ".npz")) == manifest["bytes_sha256"][s]
            for s in SPLITS)
    except (KeyError, ValueError):
        return False


def generate(directory, bank_path, floor_dir, identity):
    world = physical.NativeWorld()
    bank = zenbot_online_ground.load_bank(bank_path, floor_dir)
    report = {**identity, "bytes_sha256": {}, "rows_per_skill": {}, "opening_tick_counts": {}, "per_clip": {}}
    for split, (trials, seed) in SPLITS.items():
        chunks = []
        per_clip = {}
        for i, name in enumerate(identity["clip_names"]):
            audit = {}
            cutoff = identity["stop_before_phase"][i]
            obs, actions, ticks = physical.floor_episodes(
                world, bank, i, seed + i * 421, trials, identity["horizon"], stop_after_phase=cutoff, audit=audit)
            if not len(obs) or audit["max_matched_phase"] >= cutoff:
                raise ValueError(f"Invalid retained phase for {split} {name}")
            per_clip[name] = audit
            chunks.append((obs, actions, ticks))
            print(f"{split} {name} {len(obs)} rows", flush=True)
        obs, actions, opening = (np.concatenate(items) for items in zip(*chunks, strict=True))
        size = len(obs)
        if (obs.shape != (size, 234) or actions.shape != (size, 23) or opening.shape != (size,)
                or not np.isfinite(obs).all() or not np.isfinite(actions).all()):
            raise ValueError(f"Invalid observations or motor targets in {split}")
        path = directory / (split + ".npz")
        np.savez_compressed(path, obs=obs, q_target_raw=actions, skill=np.zeros(size, np.uint8), opening_tick=opening)
        report["per_clip"][split] = per_clip
        report["rows_per_skill"][split] = [size]
        report["opening_tick_counts"][split] = {str(k): int((opening == k).sum()) for k in (-1, 0, 1, 2)}
        report["bytes_sha256"][split] = sha256(path)
    (directory / "checks_v2.json").write_text(json.dumps(report, indent=2) + "\n")


def publish(new, out):
    if not out.exists():
        new.rename(out)
        return
    # Exchange directories in one filesystem operation so concurrent readers see a complete split and manifest.
    if out.is_symlink() or not out.is_dir() or any(p.name not in {"train.npz", "valid.npz", "checks_v2.json"} for p in out.iterdir()):
        raise ValueError(f"Output directory contains unrelated files: {out}")
    exchange = ctypes.CDLL(None, use_errno=True).renameat2
    if exchange(-100, os.fsencode(new), -100, os.fsencode(out), 2) != 0:
        errno = ctypes.get_errno()
        raise OSError(errno, os.strerror(errno))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ground-bank", required=True, type=Path)
    parser.add_argument("--support-frames", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--floor-dir", type=Path, default=ROOT / "data/zenbot23_walk_run_recovery/recovery")
    parser.add_argument("--plans", type=Path, default=ROOT / "data/zenbot23_physical_recovery")
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    directory_fd = os.open(args.out.parent, os.O_DIRECTORY | os.O_RDONLY)
    try:
        fcntl.flock(directory_fd, fcntl.LOCK_EX)
        identity = inputs(args.ground_bank, args.support_frames, args.floor_dir, args.plans)
        if matches(args.out, identity):
            print("Verified existing floor-only pair hashes.", flush=True)
            return
        with TemporaryDirectory(dir=args.out.parent, prefix=".staged-floor-") as temp:
            pending = Path(temp) / "pairs"
            pending.mkdir()
            generate(pending, args.ground_bank, args.floor_dir, identity)
            publish(pending, args.out)
    finally:
        os.close(directory_fd)


if __name__ == "__main__":
    main()
