#!/usr/bin/env bash
# Fit the released pivot from the completed native direction recipe.
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ $# != 2 ]]; then
    echo "Usage: $0 BASE_RECIPE_DIR OUTPUT_DIR" >&2
    exit 2
fi
base="$1"
out="$2"
sim="${SIM_PYTHON:-.venv/bin/python}"
fit="${FIT_PYTHON:-$sim}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu
mkdir -p "$out/banks"
collect=("$sim" -m tools.fit_zenbot_pivots collect --teacher "${GAIT_TEACHER:-releases/zenbot_four_skills/teachers/motion_train_14300.npz}")
"${collect[@]}" "$base/dual_commands/002400.npz" "$out/banks/dual.npz" \
    --seeds 445 999 7103 1567 --share .80 --kp 2.4 --kd .65 --yaw-bias 1.32 \
    --yaw-p .8 --yaw-i .65 --yaw-smoothing .09 --keep-success --executed-labels
"${collect[@]}" "$base/dual_commands/002400.npz" "$out/banks/feedback.npz" \
    --seeds 811 1553 9029 --share .85 --kp 1.5 --kd .40 --yaw-bias 1.34 \
    --yaw-p .6 --yaw-i .6 --yaw-smoothing .07 --keep-success --executed-labels --feedback-student
"${collect[@]}" "$base/both_models/002250.npz" "$out/banks/dagger.npz" \
    --seeds 371 585 --share .67 --kp 2.5 --kd .75
"$sim" -m tools.fit_zenbot_pivots teachers "$base/targeted/004500.npz" "$out/teachers"
"$fit" -m tools.fit_zenbot_pivots fit "$out/teachers/turn_left.npz" "$out/teachers/turn_right.npz" "$out/fit" \
    --data "$out/banks/dual.npz" "$out/banks/feedback.npz" "$out/banks/dagger.npz" --device "${FIT_DEVICE:-cuda}"
"$sim" -m tools.fit_zenbot_pivots transfer "$base/jitter_rescue/004000.npz" "$base/targeted/004500.npz" \
    "$out/fit/000800.npz" "$out"
