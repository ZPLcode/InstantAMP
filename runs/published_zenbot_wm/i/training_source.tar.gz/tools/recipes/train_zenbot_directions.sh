#!/usr/bin/env bash
# Rebuild the 234-input Zenbot actor and its Motion Train exports from the published teachers.
# Usage: FIT_PYTHON=/path/to/torch/python tools/recipes/train_zenbot_directions.sh OUTPUT
# SIM_PYTHON needs the simulator requirements. FIT_PYTHON needs PyTorch, ONNX and ONNX Runtime.
# Writes OUTPUT/release/{policy.npz,policy.pt,policy.onnx,export.json}.
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ $# != 1 ]]; then
    echo "Usage: $0 OUTPUT" >&2
    exit 2
fi
dest="$1"
sim="${SIM_PYTHON:-.venv/bin/python}"
fit="${FIT_PYTHON:-$sim}"
old="${FOUR_SKILL_TEACHER:-releases/zenbot_four_skills/policy.npz}"
ground="${GROUND_TEACHER:-runs/zenbot23_getup_standing_amp_pd/ckpt/002575.npz}"
gait="${GAIT_TEACHER:-releases/zenbot_four_skills/teachers/motion_train_14300.npz}"
robust="${ROBUST_FLOOR_TEACHER:-releases/zenbot_motion_train/teachers/recovery_ppo25.npz}"
device="${FIT_DEVICE:-cuda}"
for teacher in "$old" "$ground" "$gait" "$robust"; do
    if [[ ! -r "$teacher" ]]; then echo "Missing teacher checkpoint: $teacher" >&2; exit 1; fi
done
"$fit" -c 'import torch, onnx, onnxruntime'
mkdir -p "$dest"/{initial,corrections,noisy_corrections}
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
native=(env JAX_PLATFORMS=cpu "$sim" -m tools.distill_zenbot_directions collect --old "$old" --gait "$gait" --side-gain 1.25)
fitter=("$fit" -m tools.distill_zenbot_directions fit --device "$device" --old "$old" --gait "$gait"
        --ground-teacher "$ground" --side-gain 1.25 --ground-batch 224 --floor-batch 230)
normal=(0 4 6 8 10 12 16 20)
difficult=(2 14 18)
# The slowest three openings have palm-supported demonstrations from the 002575 actor.
# The four-skill teacher labels the remaining source openings, standing, forward walking and running.
for seed in 11 36; do
    "${native[@]}" --episodes 84 --seed "$seed" --floor-trials "${normal[@]}" \
        --out "$dest/initial/basic_$seed.npz"
    "${native[@]}" --floor-only --success-only --episodes 125 --steps 300 --seed "$seed" \
        --floor-trials "${normal[@]}" --out "$dest/initial/floor_$seed.npz"
    "${native[@]}" --ground-teacher "$ground" --floor-only --success-only --require-palm \
        --floor-trials "${difficult[@]}" --seed "$seed" --episodes 140 --steps 250 --out "$dest/initial/fast_$seed.npz"
    "${native[@]}" --after-rise --seed "$seed" --episodes 55 --steps 960 --out "$dest/initial/direction_$seed.npz"
done
initial_banks=("$dest"/initial/{basic,direction,fast,floor}_{11,36}.npz)
"${fitter[@]}" "${initial_banks[@]}" --init "$old" --lr .00015 --updates 18000 \
    --save-every 1500 --out "$dest/initial_fit"

initial="$dest/initial_fit/018000.npz"
for seed in 131 242; do
    "${native[@]}" --student "$initial" --share .82 --floor-only --floor-trials "${normal[@]}" \
        --seed "$seed" --episodes 100 --steps 345 --out "$dest/corrections/floor_$seed.npz"
    "${native[@]}" --ground-teacher "$ground" --student "$initial" --share .78 --floor-only \
        --floor-trials "${difficult[@]}" --seed "$seed" --episodes 120 --steps 300 --out "$dest/corrections/fast_$seed.npz"
    "${native[@]}" --after-rise --student "$initial" --share .77 --seed "$seed" --episodes 75 \
        --steps 975 --out "$dest/corrections/direction_$seed.npz"
done
correction_banks=("$dest"/corrections/{direction,fast,floor}_{131,242}.npz)
# These student-driven rollouts use Motion Train's per-episode IMU latency and
# per-frame uniform sensor noise. Only the demonstrator sees the speed error.
for seed in 91 292; do
    "${native[@]}" --student "$initial" --corrupt-student --share .85 --floor-only \
        --ground-teacher "$ground" --floor-trials "${difficult[@]}" --seed "$seed" --episodes 55 --steps 280 \
        --out "$dest/noisy_corrections/fast_$seed.npz"
done
for seed in 199 303 585; do
    "${native[@]}" --student "$initial" --corrupt-student --share .74 --after-rise --side-only \
        --side-gain 1.14 --side-feedback 1.1 --seed "$seed" --episodes 70 --steps 920 \
        --out "$dest/noisy_corrections/side_$seed.npz"
done
noisy_banks=("$dest"/noisy_corrections/fast_{292,91}.npz "$dest"/noisy_corrections/side_{199,303,585}.npz)
"${fitter[@]}" "${initial_banks[@]}" "${correction_banks[@]}" "${noisy_banks[@]}" --init "$initial" \
    --motion-train-noise --sensor-teacher --side-gain 1.14 --lr .000055 \
    --updates 3200 --save-every 800 --out "$dest/aligned"

# Keep floor demonstrations with early hand support followed by a controlled stand.
# 0.58 is the ground teacher's maximum fraction, reduced to zero as the pelvis rises.
for seed in 165 377; do
    "${native[@]}" --ground-teacher "$ground" --floor-only --require-palm --success-only \
        --ground-weight .58 --min-rise-seconds 1.38 --seed "$seed" --floor-trials 10 12 16 20 16 20 \
        --episodes 175 --steps 238 --out "$dest/noisy_corrections/support_$seed.npz"
done
"${fitter[@]}" "${initial_banks[@]}" "${correction_banks[@]}" "${noisy_banks[@]}" \
    "$dest"/noisy_corrections/support_{165,377}.npz --init "$dest/aligned/003200.npz" \
    --motion-train-noise --sensor-teacher --side-gain 1.14 --ground-batch 245 --floor-batch 205 \
    --lr .000023 --updates 6500 --save-every 500 --out "$dest/support"

# Add the second physical domain using the shipped source MJCF, its original contact
# masks and PGS solver, four physics steps per control tick and immediate PD targets.
mkdir -p "$dest/dual_physics"
best="$dest/support/003500.npz"
openings=(0 2 4 6 8 10 12 14 16 18 20 16 18 18 2 20)
for seed in 161 355; do
    "${native[@]}" --original-physics --ground-teacher "$ground" --floor-only --success-only \
        --seed "$seed" --floor-trials "${openings[@]}" --episodes 165 --steps 285 --out "$dest/dual_physics/model_$seed.npz"
    "${native[@]}" --original-physics --ground-teacher "$ground" --floor-only --corrupt-student \
        --student "$best" --share .82 --seed "$seed" --floor-trials "${openings[@]}" --episodes 150 \
        --steps 310 --out "$dest/dual_physics/mixed_$seed.npz"
    "${native[@]}" --original-physics --seed "$seed" --episodes 80 --side-gain 1.14 --side-feedback 1.1 \
        --out "$dest/dual_physics/basic_$seed.npz"
    "${native[@]}" --original-physics --after-rise --corrupt-student --student "$best" --share .69 \
        --seed "$seed" --side-gain 1.14 --side-feedback 1.1 --episodes 65 --steps 910 \
        --out "$dest/dual_physics/direction_$seed.npz"
done
dual_banks=("$dest"/dual_physics/{basic,direction,mixed,model}_{161,355}.npz)
"${fitter[@]}" "${initial_banks[@]}" "${correction_banks[@]}" "${noisy_banks[@]}" \
    "$dest"/noisy_corrections/support_{165,377}.npz "${dual_banks[@]}" --init "$best" \
    --motion-train-noise --sensor-teacher --side-gain 1.14 --ground-batch 245 --floor-batch 205 \
    --lr .000035 --updates 2250 --save-every 750 --out "$dest/both_models"

# Teach persistent operator intent from the floor. Only the student's velocity input
# changes in these ground examples. All later observations retain the teacher action.
"$fit" -m tools.distill_zenbot_directions fit --device "$device" --old "$old" --gait "$gait" "${initial_banks[@]}" "${correction_banks[@]}" "${noisy_banks[@]}" \
    "$dest"/noisy_corrections/support_{165,377}.npz "${dual_banks[@]}" --init "$dest/both_models/002250.npz" \
    --rehearse-init --motion-train-noise --ground-command-share .55 --ground-batch 245 --floor-batch 205 \
    --lr .00003 --updates 2400 --save-every 400 --out "$dest/dual_commands"

# Continue from the two contact models, retaining the reference recovery timing.
mkdir -p "$dest"/{dual_gentle_data,paired_floors,targeted_source}
sim_banks=("${initial_banks[@]}" "${correction_banks[@]}" "${noisy_banks[@]}" "$dest"/noisy_corrections/support_{165,377}.npz)
gait_banks=("$dest"/dual_physics/{basic,direction}_{161,355}.npz)
for seed in 509 621; do
    "${native[@]}" --original-physics --ground-teacher "$ground" --floor-only --success-only --require-palm \
        --ground-weight .58 --min-rise-seconds 1.4 --seed "$seed" --floor-trials 0 2 6 10 12 16 18 20 6 12 18 20 \
        --episodes 180 --steps 280 --out "$dest/dual_gentle_data/fast_$seed.npz"
    "${native[@]}" --original-physics --floor-only --student "$dest/support/006500.npz" --corrupt-student \
        --share .65 --seed "$seed" --floor-trials 0 2 4 8 10 12 14 16 18 20 --episodes 130 --steps 315 \
        --out "$dest/dual_gentle_data/normal_$seed.npz"
done
"${fitter[@]}" "${sim_banks[@]}" "${gait_banks[@]}" "$dest"/dual_gentle_data/{fast,normal}_{509,621}.npz \
    --init "$dest/support/006500.npz" --motion-train-noise --sensor-teacher --side-gain 1.14 \
    --ground-batch 235 --floor-batch 235 --lr .000023 --updates 1500 --save-every 500 --out "$dest/dual_gentle"
for seed in 179 379; do
    "${native[@]}" --original-physics --ground-teacher "$ground" --floor-only --corrupt-student \
        --student "$dest/dual_gentle/001500.npz" --share .90 --seed "$seed" --floor-trials 6 18 20 12 6 18 \
        --episodes 150 --steps 285 --out "$dest/paired_floors/correction_$seed.npz"
done
paired_banks=("$dest"/paired_floors/correction_{179,379}.npz)
pair_fit=("$fit" -m tools.distill_zenbot_directions fit --device "$device" --old "$old" --gait "$gait")
"${pair_fit[@]}" "${sim_banks[@]}" "${gait_banks[@]}" "${paired_banks[@]}" --init "$dest/support/006500.npz" \
    --correction-actor "$dest/dual_gentle/001500.npz" --correction-banks "${paired_banks[@]}" --motion-train-noise \
    --ground-batch 260 --floor-batch 180 --lr .000025 --updates 1000 --save-every 500 --out "$dest/domain_transfer"
"${pair_fit[@]}" "${sim_banks[@]}" "${gait_banks[@]}" "${paired_banks[@]}" --init "$dest/domain_transfer/001000.npz" \
    --correction-actor "$dest/dual_gentle/001500.npz" --correction-banks "${paired_banks[@]}" --motion-train-noise \
    --ground-command-share .55 --ground-batch 260 --floor-batch 180 --lr .000033 --updates 4000 --save-every 500 \
    --out "$dest/ground_commands"
for seed in 675 917; do
    source_floor=(--original-physics --ground-teacher "$ground" --floor-only --record-ground --source-jitter \
                  --success-only --student "$dest/dual_commands/002400.npz" --share 1. --seed "$seed")
    "${native[@]}" "${source_floor[@]}" --floor-trials 6 16 --episodes 130 --steps 290 \
        --out "$dest/targeted_source/zero_$seed.npz"
    "${native[@]}" "${source_floor[@]}" --floor-intent --corrupt-student --floor-trials 6 6 16 16 6 16 16 \
        --episodes 180 --steps 310 --out "$dest/targeted_source/held_$seed.npz"
done
targeted=("$dest"/targeted_source/{held,zero}_{675,917}.npz)
"${pair_fit[@]}" "${sim_banks[@]}" "${gait_banks[@]}" "${paired_banks[@]}" "${targeted[@]}" \
    --init "$dest/ground_commands/004000.npz" --correction-actor "$dest/dual_commands/002400.npz" \
    --correction-banks "${targeted[@]}" --motion-train-noise --ground-command-share .30 \
    --ground-batch 265 --floor-batch 200 --lr .000024 --updates 4500 --save-every 500 --out "$dest/targeted"

# Reference-velocity restores preserve the clip's incoming momentum. Random tilt and
# encoder offsets span ±2 degrees, plus an independent ±0.07 m/s horizontal perturbation.
mkdir -p "$dest"/{native_corrections,native_jitter_close}
stable_floor=("${native[@]}" --record-ground --reference-jitter --floor-only --success-only --quiet)
for seed in 7341 6847 15919 29117; do
    "${stable_floor[@]}" --ground-teacher "$ground" --student "$robust" --share 1. --seed "$seed" \
        --floor-trials 6 16 20 6 16 20 4 10 --episodes 165 --steps 320 --out "$dest/native_corrections/ppo_$seed.npz"
done
native_corrections=("$dest"/native_corrections/ppo_{15919,29117,6847,7341}.npz)
balanced=("${sim_banks[@]}" "${gait_banks[@]}" "${paired_banks[@]}" "${targeted[@]}" "${native_corrections[@]}")
"${pair_fit[@]}" "${balanced[@]}" --init "$dest/targeted/004500.npz" --correction-actor "$robust" \
    --correction-banks "${native_corrections[@]}" --motion-train-noise --ground-command-share .24 \
    --ground-batch 265 --floor-batch 210 --lr .000024 --updates 6500 --save-every 500 --out "$dest/jitter_refine"
for seed in 16123 31237 46457; do
    "${stable_floor[@]}" --old "$robust" --student "$dest/jitter_refine/006500.npz" --share .70 --seed "$seed" \
        --floor-trials 16 16 16 6 16 20 --episodes 165 --steps 350 --out "$dest/native_jitter_close/rescue_$seed.npz"
done
rescue=("$dest"/native_jitter_close/rescue_{16123,31237,46457}.npz)
"${pair_fit[@]}" "${balanced[@]}" "${rescue[@]}" --init "$dest/jitter_refine/006500.npz" --correction-actor "$robust" \
    --correction-banks "${rescue[@]}" --motion-train-noise --ground-command-share .22 \
    --ground-batch 180 --floor-batch 320 --lr .000018 --updates 4000 --save-every 500 --out "$dest/jitter_rescue"

# Fold the left/right turn update and the lateral command calibration
# into the first layer, then export the same actor in both Motion Train formats.
SIM_PYTHON="$sim" FIT_PYTHON="$fit" FIT_DEVICE="$device" \
    tools/recipes/fit_zenbot_pivot.sh "$dest" "$dest/pivot"
mkdir -p "$dest/release"
cp "$dest/pivot/policy.npz" "$dest/release/policy.npz"
# TorchScript serializes ELU constant declarations in Python hash order.
PYTHONHASHSEED=0 "$fit" -m tools.export_zenbot_motion_train "$dest/release/policy.npz" "$dest/release"
