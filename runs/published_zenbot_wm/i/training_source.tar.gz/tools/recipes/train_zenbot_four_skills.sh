#!/usr/bin/env bash
# Rebuild the single 495-input controller from the 001000 get-up and 14300 gait teachers.
# Native collection uses the repo's Python 3.11 environment (requirements.txt).
# CPU fitting used Python 3.11.15, torch 2.7.0+cu128 and numpy 1.26.0.
# Usage from the repository:
#   FIT_PYTHON=/path/to/torch/python tools/recipes/train_zenbot_four_skills.sh runs/four_skills_replay
set -euo pipefail
cd "$(dirname "$0")/../.."

dest="${1:-runs/zenbot_four_skills_replay}"
sim_python="${SIM_PYTHON:-.venv/bin/python}"
fit_python="${FIT_PYTHON:-$sim_python}"
rise="${RISE_TEACHER:-runs/zenbot23_getup_default_from1000/ckpt/001000.npz}"
gait="${GAIT_TEACHER:-releases/zenbot_four_skills/teachers/motion_train_14300.npz}"
bank="${MOTION_BANK:-data/zenbot23_walk_run_recovery}"
standing_recipe=tools/recipes/zenbot_standing_001000.json
export OPENBLAS_NUM_THREADS=1
if ! "$fit_python" -c 'import numpy, torch' >/dev/null 2>&1; then
    echo "Set FIT_PYTHON to the Python environment containing PyTorch and NumPy." >&2
    exit 1
fi
mkdir -p "$dest"

# The curated standing recipe checks both teacher SHA-256 hashes before collecting.
base=(--rise "$rise" --gait "$gait" --floor "$bank/recovery")
collector=(env JAX_PLATFORMS=cpu OMP_NUM_THREADS=1 "$sim_python" -m tools.collect_zenbot_recovery_gait)
"${collector[@]}" "${base[@]}" --replay-stands "$standing_recipe" --out "$dest/stand_labels"
for kind in walk run; do
    speed=1.
    if [[ "$kind" == run ]]; then speed=2.5; fi
    "${collector[@]}" "${base[@]}" --command "$speed" --hold-command --seed 43 --steps 750 \
        --delay 2 --blend 18 --warm 35 --max-speed 2.5 --min-height .5 --up-cos .8 --weak-load 0 \
        --out "$dest/${kind}43_labels"
    "${collector[@]}" "${base[@]}" --command "$speed" --hold-command --seed 181 --steps 750 \
        --delay 3 --blend 35 --warm 35 --max-speed 1.7 --min-height .5 --up-cos .77 --weak-load -.01 \
        --out "$dest/${kind}181_labels"
done
env JAX_PLATFORMS=cpu OMP_NUM_THREADS=1 "$sim_python" -m tools.train_zenbot_skill_actor collect \
    "${base[@]}" --episodes 198 --steps 520 --seed 31 --noise .07 --out "$dest/teachers.npz"

# Keep this bank order for the seeded minibatch sampler.
expert=("$dest/stand_labels/expert.npz" "$dest/walk43_labels/expert.npz" "$dest/walk181_labels/expert.npz"
        "$dest/run43_labels/expert.npz" "$dest/run181_labels/expert.npz")
env OMP_NUM_THREADS=2 "$fit_python" -m tools.train_zenbot_skill_actor fit "$dest/teachers.npz" "${expert[@]}" \
    --init "$gait" --rise "$rise" --gait "$gait" --perturb-handoff --seed 444 --threads 2 \
    --lr .00020 --updates 20400 --save-every 2400 --out "$dest/actor"

# Optional on-policy adaptation from the freshly fitted controller. Set PPO_UPDATES
# and prepare standing/ and walk_run/ alongside recovery/ to use the GPU trainer.
if [[ "${PPO_UPDATES:-0}" != 0 ]]; then
    "$sim_python" -m instantamp.train_zenbot_getup_stand_amp \
        --log_dir "$dest/ppo" --init_policy "$dest/actor/020400.npz" --floor_dir "$bank/recovery" \
        --stand_dir "$bank/standing" --gait_dir "$bank/walk_run" --rise_teacher "$rise" --gait_teacher "$gait" \
        --floor_reset_fraction .72 --policy_anchor 120 --stand_reference_weight 10 --gait_speed_weight 4 \
        --support_weight 8 --standing_amp 1 --num_envs 256 --rollout 64 --epochs 3 --minibatches 4 \
        --disc_batch 256 --init_std .10 --init_lr .00001 --critic_warmup 10 --save_every 50 \
        --log_every 10 --seed 42 --iterations "$PPO_UPDATES"
fi
