#!/usr/bin/env bash
# Train one random actor on floor recovery, standing and commanded AMP locomotion.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
if [[ $# -gt 1 || ${1:-} == --help ]]; then
    echo "Usage: $0 [FRESH_RUN_DIRECTORY]"
    exit 0
fi
run=${1:-runs/zenbot_joint_scratch_10k}
if [[ -e "$run/ckpt" ]]; then
    echo "Choose a fresh run directory. Checkpoints already exist at $run/ckpt." >&2
    exit 1
fi
python=${SIM_PYTHON:-.venv/bin/python}
export PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.86}"
floor=data/zenbot23_physical_recovery
gait=data/zenbot23_physical_gait
JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_online_ground --plans "$floor" \
    --selection "$floor/selection.json" --gains-dir "$run/feedback_cache" --compute-missing --out "$run/ground_bank.npz"
JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_physical_gait --bank "$gait" \
    --verify-clips data/zenbot23_walk_run_recovery/walk_run --out "$run/gait_pairs"
JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_physical_training --ground-bank "$run/ground_bank.npz" \
    --gait-pairs "$run/gait_pairs" --out "$run/reference_pairs"
"$python" -m instantamp.train_zenbot_scratch --source-gait --online-ground-bank "$run/ground_bank.npz" \
    --reference-pairs "$run/reference_pairs/train.npz" --seed 42 --iterations 10000 --num-envs 2048 --rollout 64 --log-dir "$run"
POLICY="$run/ckpt/010000.npz" SIM_PYTHON="$python" bash releases/zenbot_motion_train/evaluate.sh "$run/evaluation"
"$python" -m tools.compare_zenbot_scratch releases/zenbot_motion_train/evaluation "$run/evaluation" --out "$run/comparison.json"
