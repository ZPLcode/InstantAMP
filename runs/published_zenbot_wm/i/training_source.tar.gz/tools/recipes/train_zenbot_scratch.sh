#!/usr/bin/env bash
# Train from random weights and evaluate the resulting actor on the fixed release benchmark.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
plain=false
run=
for arg in "$@"; do
    case "$arg" in
        --pure-ppo) plain=true ;;
        --help|-h) echo "Usage: $0 [--pure-ppo] [RUN]"; exit 0 ;;
        -*) echo "Unknown option: $arg" >&2; exit 2 ;;
        *) if [[ -n $run ]]; then echo "Supply one run directory" >&2; exit 2; fi
           run=$arg ;;
    esac
done
if [[ -z $run ]]; then
    if [[ $plain == true ]]; then run=runs/zenbot_scratch_10k; else run=runs/zenbot_scratch_guided_10k; fi
fi
python=${SIM_PYTHON:-.venv/bin/python}
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONUNBUFFERED=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.8}"

# Check before preparing examples so a repeated invocation preserves the original run's training data.
if [[ -e "$run/ckpt" || -L "$run/ckpt" ]]; then
    echo "Checkpoints already exist in $run/ckpt. Choose a fresh run directory." >&2
    exit 1
fi
guide=(--pure-ppo)
if [[ $plain == false ]]; then
    JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_scratch_pairs --out "$run/reference_pairs"
    guide=(--reference-pairs "$run/reference_pairs/train.npz")
fi
"$python" -m instantamp.train_zenbot_scratch "${guide[@]}" --seed 42 --iterations 10000 --log-dir "$run"
policy="$run/ckpt/010000.npz"
if [[ ! -f "$policy" ]]; then
    echo "Training completed without the final checkpoint $policy" >&2
    exit 1
fi
POLICY="$policy" SIM_PYTHON="$python" bash releases/zenbot_motion_train/evaluate.sh "$run/evaluation"
