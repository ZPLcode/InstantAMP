#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
usage="Usage: $0 [FRESH_RUN_DIRECTORY] [--floor-reward-scale K]"
if [[ ${1:-} == --help || ${1:-} == -h ]]; then
    echo "$usage"
    exit 0
fi
run=runs/zenbot_staged_scratch_10k
if [[ $# -gt 0 && $1 != --* ]]; then
    run=$1
    shift
fi
export PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
python=${SIM_PYTHON:-.venv/bin/python}
reward_args=()
if [[ $# -eq 2 && $1 == --floor-reward-scale ]]; then
    # Validate the setting before building motion data.
    JAX_PLATFORMS=cpu "$python" -c 'import sys
from instantamp.zenbot_staged_recovery import RecoverySettings
RecoverySettings(floor_reward_scale=float(sys.argv[1]))' "$2"
    reward_args=(--floor-reward-scale "$2")
elif [[ $# -ne 0 ]]; then
    echo "$usage" >&2
    exit 2
fi
if [[ -e "$run/ckpt" || -L "$run/ckpt" ]]; then
    echo "Checkpoints already exist at $run/ckpt. Choose a fresh run directory." >&2
    exit 1
fi
mkdir -p "$run"
floor=data/zenbot23_physical_recovery
if [[ ! -f "$run/ground_bank.npz" ]]; then
    JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_online_ground --plans "$floor" \
        --selection "$floor/selection.json" --gains-dir "$run/feedback_cache" --compute-missing --out "$run/ground_bank.npz"
fi
JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_support_frames --ground-bank "$run/ground_bank.npz" \
    --out "$run/support_frames.json"
JAX_PLATFORMS=cpu "$python" -m tools.prepare_zenbot_staged_floor_pairs --ground-bank "$run/ground_bank.npz" \
    --support-frames "$run/support_frames.json" --out "$run/reference_pairs"
tar -czf "$run/training_source.tar.gz" instantamp/*.py tools/{prepare_zenbot_online_ground,prepare_zenbot_support_frames,prepare_zenbot_physical_training,prepare_zenbot_staged_floor_pairs,prepare_zenbot_scratch_pairs,collect_zenbot_staged_retention,zenbot_reference_feedback,compare_zenbot_scratch,evaluate_zenbot_motor_domains}.py \
    tools/fixtures/zenbot_motor_domains tools/zenbot_reference_tangent.cc tools/recipes/train_zenbot_staged_scratch.sh releases/zenbot_motion_train/evaluate.sh
"$python" -m instantamp.train_zenbot_staged --run-dir "$run" "${reward_args[@]}"
POLICY="$run/ckpt/010000.npz" SIM_PYTHON="$python" bash releases/zenbot_motion_train/evaluate.sh "$run/evaluation"
"$python" -m tools.compare_zenbot_scratch releases/zenbot_motion_train/evaluation "$run/evaluation" --out "$run/comparison.json"
JAX_PLATFORMS=cpu "$python" -m tools.evaluate_zenbot_motor_domains --run-dir "$run" --iterations 10000 --out "$run/evaluation/motor_domains"
