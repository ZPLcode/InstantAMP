#!/usr/bin/env bash
# First stage of a single 10,000-iteration run. Reserve the remaining iterations for locomotion.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
run=${1:?Usage: train_zenbot_wm_getup.sh RUN}
mkdir -p -- "$run"
if ! mkdir -- "$run/ckpt"; then
    echo "Choose a fresh run directory for the randomly initialized learner." >&2
    exit 1
fi
export PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
exec "${SIM_PYTHON:-.venv/bin/python}" -m instantamp.train \
    --robot zenbot23_walk_run_recovery --motion_train_wm 1 --wm_getup_only 1 \
    --wm_reference_training 1 --wm_motion_replay 1 --seed 42 --log_dir "$run" \
    --max_iterations 4000 --minutes 0 --ckpt_iterations 500 --log_every 50 \
    --num_envs 512 --env_steps 4 --warmup_steps 40 --pi_batch 512 --wm_batch 512 --amp_batch 512 \
    --wm_only_iters 200 --wm_window 8 --horizon 32 --amp_getup 1 --amp_w 2 \
    --ppo_frac .1 --ppo_w 1 --ode 0 --legged_real_ppo 0 --action_rate_l2_weight -.015
