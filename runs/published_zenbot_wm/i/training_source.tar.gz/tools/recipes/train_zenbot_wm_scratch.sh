#!/usr/bin/env bash
# Train one direct-action Zenbot actor through a learned world model and replay the fixed release benchmark.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
usage="Usage: $0 RUN [--reference-training] [--verify-deployment]"
run=
verify=
reference_args=()
for arg in "$@"; do
    case "$arg" in
        -h|--help) echo "$usage"; exit 0 ;;
        --reference-training)
            reference_args=(--wm_reference_training 1) ;;
        --verify-deployment) verify=1 ;;
        -*|'') echo "$usage" >&2; exit 2 ;;
        *)
            if [[ -n $run ]]; then echo "$usage" >&2; exit 2; fi
            run=$arg ;;
    esac
done
if [[ -z $run ]]; then
    echo "$usage" >&2
    exit 2
fi
sim_python=${SIM_PYTHON:-.venv/bin/python}
if [[ -n $verify ]]; then
    : "${MOTION_TRAIN_ROOT:?Set MOTION_TRAIN_ROOT to the Motion Train checkout}"
    : "${TORCH_PYTHON:?Set TORCH_PYTHON to the Torch/ONNX export interpreter}"
    : "${DEPLOY_PYTHON:?Set DEPLOY_PYTHON to the Motion Train deployment interpreter}"
fi

mkdir -p -- "$run"
if [[ -e "$run/policy.npz" || -L "$run/policy.npz" ]] || ! mkdir -- "$run/ckpt"; then
    echo "Choose a fresh run directory. Checkpoints or a final policy already exist in $run." >&2
    exit 1
fi

export PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.8}"
iterations=10000
# Bash parses this group before training so a later recipe edit cannot move the file offset for evaluation.
{
"$sim_python" -m instantamp.train --robot zenbot23_walk_run_recovery --motion_train_wm 1 \
    --log_dir "$run" --seed 42 --max_iterations "$iterations" --minutes 0 --ckpt_iterations 1000 \
    --num_envs 512 --env_steps 1 --pi_batch 512 --wm_batch 512 --amp_batch 512 \
    --warmup_steps 32 --wm_only_iters 200 --wm_window 8 --horizon 32 \
    --amp_w 2 --amp_getup 1 --ode 0 --legged_real_ppo 0 --ppo_frac 0 --action_rate_l2_weight -.015 \
    "${reference_args[@]}"

# The learner numbers files by save order. Its sidecar records the completed absolute iteration.
"$sim_python" - "$run" "$iterations" <<'PY'
from pathlib import Path
import sys

import numpy as np
from tools.monitor_zenbot_scratch import wm_checkpoint

run = Path(sys.argv[1])
final_iteration = int(sys.argv[2])
policy = wm_checkpoint(run, final_iteration)
if policy is None:
    raise SystemExit(f"Missing saved policy for iteration {final_iteration} in {run / 'ckpt'}")
with np.load(policy, allow_pickle=False) as arrays:
    if (arrays["obs_norm/mean"].shape != (234,) or arrays["avg/0/w"].shape[0] != 234
            or any(name.startswith(("ode/", "ground_base/", "gait/")) for name in arrays)):
        raise SystemExit(f"Unexpected observation or action format in {policy}")
    output_layer = max(int(name.split("/")[1]) for name in arrays if name.startswith("avg/") and name.endswith("/w"))
    if arrays[f"avg/{output_layer}/b"].shape != (23,):
        raise SystemExit(f"Expected 23 direct action outputs in {policy}")
(run / "policy.npz").symlink_to(policy.relative_to(run))
print(f"Iteration {final_iteration} policy: {policy}", flush=True)
PY

release=releases/zenbot_motion_train
POLICY="$run/policy.npz" SIM_PYTHON="$sim_python" bash "$release/evaluate.sh" "$run/evaluation"
JAX_PLATFORMS=cpu "$sim_python" -m tools.compare_zenbot_scratch "$release/evaluation" "$run/evaluation" \
    --out "$run/comparison.json"
if [[ -n $verify ]]; then
    "$TORCH_PYTHON" -m tools.export_zenbot_motion_train "$run/policy.npz" "$run"
    POLICY_DIR="$run" SIM_PYTHON="$sim_python" bash "$release/verify_deployment.sh" "$run"
fi
exit 0
}
