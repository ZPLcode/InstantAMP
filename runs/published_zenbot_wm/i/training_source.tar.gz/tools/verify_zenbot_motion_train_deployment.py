"""Check a deployed Zenbot policy in Motion Train's actual sim2sim_rpo_amp.run_mujoco loop."""

import argparse
import hashlib
import json
import os
import subprocess
import sys
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
STAGES = (
    ("stand", (0.0, 0.0, 0.0)),
    ("forward", (1.0, 0.0, 0.0)),
    ("run", (2.5, 0.0, 0.0)),
    ("stop", (0.0, 0.0, 0.0)),
    ("left", (0.0, 0.4, 0.0)),
    ("right", (0.0, -0.4, 0.0)),
    ("turn_left", (0.0, 0.0, 0.6)),
    ("turn_right", (0.0, 0.0, -0.6)),
    ("back", (-0.5, 0.0, 0.0)),
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command_stages(args):
    if not args.demo_dir:
        return [(name, command, round(args.stage_seconds / 0.02)) for name, command in STAGES]
    commands = dict(STAGES)
    return [(name, commands[key], count) for name, key, count in (
        ("get_up", "stand", 400), ("stand", "stand", 200), ("walk", "forward", 300),
        ("run", "run", 300), ("stop", "stop", 300), ("back", "back", 300), ("left", "left", 300),
        ("right", "right", 300), ("turn_left", "turn_left", 300), ("turn_right", "turn_right", 300),
        ("final_stop", "stop", 300),
    )]


def capture(args):
    import torch

    os.environ.setdefault("PYNPUT_BACKEND", "dummy")
    sys.path.insert(0, str(args.motion_train / "robolab/scripts/mujoco"))
    import sim2sim_rpo_amp as deploy

    cfg = deploy.get_robot_cfg("zenbot")
    scripted = torch.jit.load(str(args.torchscript), map_location="cpu").eval() if args.torchscript else None
    if args.onnx:
        import onnxruntime as ort

        options = ort.SessionOptions()
        options.intra_op_num_threads = options.inter_op_num_threads = 1
        session = ort.InferenceSession(str(args.onnx), options, providers=["CPUExecutionProvider"])
        input_name = session.get_inputs()[0].name
    stages = command_stages(args)
    commands = np.repeat([target for _, target, _ in stages], [count for _, _, count in stages], axis=0)
    frames = len(commands)
    observations, actions, poses, velocities, previous_base, targets = [], [], [], [], [], []
    format_error = 0.0
    pre_step = []
    state = []
    previous_count = 0
    foot_loads = []
    substep_loads = []
    foot_geoms = set()
    wrench = np.zeros(6)
    original_step, original_get, original_pd = deploy.mujoco.mj_step, deploy.get_obs, deploy.pd_control

    class Finished(Exception):
        pass

    def advance(model, data):
        # mj_step integrates qpos/qvel after it last updates sensordata. Save that IMU sample time.
        pre_step[:] = [np.r_[data.qpos[3:7], data.qvel[3:6]]]
        original_step(model, data)
        if foot_geoms:
            load = 0.
            for i, contact in enumerate(data.contact):
                if ground_geom in contact.geom and foot_geoms.intersection(contact.geom):
                    deploy.mujoco.mj_contactForce(model, data, i, wrench)
                    load += wrench[0]
            substep_loads.append(load / body_weight)

    def sense(data):
        deploy.cmd.vx, deploy.cmd.vy, deploy.cmd.dyaw = commands[min(len(observations), frames - 1)]
        state[:] = [data]
        return original_get(data)

    def policy(obs):
        nonlocal format_error
        if len(observations) == frames:
            raise Finished
        if args.onnx:
            onnx_action = torch.from_numpy(session.run(None, {input_name: obs.numpy()})[0])
        action = scripted(obs) if scripted is not None else onnx_action
        if scripted is not None and args.onnx:
            format_error = max(format_error, (onnx_action - action).abs().max().item())
        observations.append(obs.numpy().copy()[0])
        actions.append(action.detach().numpy().copy()[0])
        poses.append(state[0].qpos.copy())
        velocities.append(state[0].qvel.copy())
        previous_base.append(pre_step[0])
        if args.demo_dir:
            foot_loads.append(float(np.mean(substep_loads)) if substep_loads else 0.)
            substep_loads.clear()
        return action

    def pd(target, *other):
        nonlocal previous_count
        if len(actions) != previous_count:
            targets.append(target.copy())
            previous_count = len(actions)
        return original_pd(target, *other)

    ground_geom, body_weight = None, None

    def viewer(model, data, **_):
        nonlocal ground_geom, body_weight
        if args.demo_dir:
            feet = [model.body(name).id for name in ("left_ankle_roll_Link", "right_ankle_roll_Link")]
            foot_geoms.update(np.flatnonzero(np.isin(model.geom_bodyid, feet)))
            ground_geom = model.geom("ground").id
            body_weight = model.body_mass.sum() * abs(model.opt.gravity[2])
        if args.floor_clip:
            with np.load(args.floor_clip, allow_pickle=False) as clip:
                quat = clip["root_quat"][0]
                data.qpos[:] = np.r_[
                    [0.0, 0.0, clip["root_pos"][0, 2] + 0.02], quat[[3, 0, 1, 2]], clip["dof_pos"][0]
                ]
                data.qvel[:] = 0.0
            deploy.mujoco.mj_forward(model, data)
            pre_step[:] = [np.r_[data.qpos[3:7], data.qvel[3:6]]]
        return SimpleNamespace(is_alive=True, cam=SimpleNamespace(lookat=None), render=lambda: None)

    sim = SimpleNamespace(
        mujoco_model_path=cfg.mujoco_model_path,
        dt=0.005,
        decimation=4,
        sim_duration=(frames + 2) * 0.02,
        render_fps=50,
        busy_wait_margin=0,
    )
    with ExitStack() as stack:
        for module, name, value in (
            (deploy.mujoco, "mj_step", advance),
            (deploy, "get_obs", sense),
            (deploy, "pd_control", pd),
            (deploy, "start_keyboard_listener", lambda: None),
            (deploy, "open_interactive_viewer", viewer),
            (deploy, "sleep_until", lambda *args: None),
            (deploy, "tqdm", lambda it, **kwargs: it),
        ):
            stack.enter_context(patch.object(module, name, value))
        try:
            deploy.run_mujoco(policy, SimpleNamespace(robot_config=cfg, sim_config=sim))
        except Finished:
            pass
    assert len(actions) == len(targets) == frames
    np.savez(
        args.capture,
        obs=observations,
        actions=actions,
        q=poses,
        v=velocities,
        imu_state=previous_base,
        targets=targets,
        lab=cfg.usd2urdf,
        default=cfg.default_pos,
        kp=cfg.kps,
        kd=cfg.kds,
        scale=cfg.action_scale,
        torque_limit=cfg.tau_limit,
        format_error=format_error,
        foot_loads=foot_loads,
        script_sha256=digest(Path(deploy.__file__)),
        robot_xml_sha256=digest(Path(cfg.mujoco_model_path)),
    )


def verify(source, args):
    os.environ.setdefault("JAX_PLATFORMS", "cpu")
    import jax.numpy as jnp

    from instantamp import zenbot
    from instantamp.inference import load
    from instantamp.sim import Sim, unflatten
    from instantamp.zenbot_motion_train_obs import (
        LAB_ORDER,
        motion_train_actor_mean,
        motion_train_observation,
    )

    data = np.load(source, allow_pickle=False)
    np.testing.assert_array_equal(data["lab"], LAB_ORDER)
    for key, array in (
        ("default", zenbot.DEFAULT_Q),
        ("kp", zenbot.KP),
        ("kd", zenbot.KD),
        ("scale", zenbot.ACTION_SCALE),
        ("torque_limit", zenbot.EFFORT),
    ):
        np.testing.assert_allclose(data[key], array, rtol=1e-6, err_msg=key)
    sim = Sim(
        1,
        robot="zenbot23_getup",
        floor_dir=str(ROOT / "data/zenbot23_walk_run_recovery/recovery"),
        walk_dir=str(ROOT / "data/zenbot23_walk_run_recovery/standing"),
        physics=False,
        obs_noise=False,
        randomize_world=False,
        zenbot_getup_stand=True,
        zenbot_standing_amp=True,
        zenbot_support_weight=8.0,
        zenbot_command_gait=True,
    )
    actions = data["actions"][:, np.argsort(LAB_ORDER)]
    previous = np.concatenate((np.zeros_like(actions[:1]), actions[:-1]))
    stages = command_stages(args)
    lengths = [n for _, _, n in stages]
    commands = np.repeat([command for _, command, _ in stages], lengths, axis=0)
    offsets = np.maximum(0, np.arange(len(actions))[:, None] - np.arange(4, -1, -1))
    errors = {}
    for timing in ("current_state", "deployment_sensor_time"):
        q, v = data["q"].copy(), data["v"].copy()
        if timing == "deployment_sensor_time":
            q[:, 3:7] = data["imu_state"][:, :4]
            v[:, 3:6] = data["imu_state"][:, 4:]
        frame = sim.obs_frame(
            unflatten(jnp.asarray(q), jnp.asarray(v)), jnp.asarray(previous), jnp.asarray(commands), None
        )
        actual = np.asarray(motion_train_observation(frame[offsets]))
        chunks = np.split(np.abs(data["obs"] - actual), [9, 18, 27, 96, 165], axis=1)
        terms = ("gyro_radps", "projected_gravity", "command", "joint_rad", "joint_radps", "raw_action")
        errors[timing] = {k: float(d.max()) for k, d in zip(terms, chunks)}
    native_action_error = None
    if args.checkpoint:
        actor, norm, ode = load(args.checkpoint)
        if not isinstance(actor, list) or actor[0]["w"].shape[0] != 234 or ode is not None:
            raise ValueError("Expected a standalone 234-input direct-action checkpoint")
        pred = motion_train_actor_mean(actor, norm, actual)
        native_action_error = float(np.abs(np.asarray(pred) - actions).max())
    target_error = float(np.abs(data["targets"] - (zenbot.DEFAULT_Q + zenbot.ACTION_SCALE * actions)).max())
    q = data["q"]
    stage_results = []
    for (name, command, n), poses in zip(stages, np.split(q, np.cumsum(lengths)[:-1])):
        w, x, y, z = poses[:, 3:7].T
        yaw = np.unwrap(np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z)))
        mean_angle = 0.5 * (yaw[1:] + yaw[:-1])
        c, s = np.cos(mean_angle), np.sin(mean_angle)
        vx, vy = np.diff(poses[:, :2], axis=0).T / 0.02
        speed = np.column_stack((c * vx + s * vy, -s * vx + c * vy, np.diff(yaw) / 0.02))
        tail = slice(-round(2 / 0.02), None)
        up = 1 - 2 * (x * x + y * y)
        stage_results.append(
            {
                "name": name,
                "duration_s": n * .02,
                "target": command,
                "mean_last_2s": speed[tail].mean(axis=0).tolist(),
                "upright_last_2s": bool(((poses[tail, 2] > 0.58) & (up[tail] > 0.8)).all()),
                "min_height_m": float(poses[:, 2].min()),
                "fell": bool(((poses[:, 2] < .42) | (up < .55)).any()) if name != "get_up" else None,
            }
        )
    report = {
        "frames": len(q),
        "stage_seconds": None if args.demo_dir else args.stage_seconds,
        "start": args.floor_clip.name if args.floor_clip else "original standing reset",
        "script_sha256": str(data["script_sha256"]),
        "mjcf_sha256": str(data["robot_xml_sha256"]),
        "torchscript_sha256": digest(args.torchscript) if args.torchscript else None,
        "onnx_sha256": digest(args.onnx) if args.onnx else None,
        "observation_max_abs": errors,
        "checkpoint_sha256": digest(args.checkpoint) if args.checkpoint else None,
        "checkpoint_to_deployment_action_max_abs": native_action_error,
        "target_max_abs_rad": target_error,
        "torchscript_onnx_max_abs": float(data["format_error"]) if args.torchscript and args.onnx else None,
        "stages": stage_results,
    }
    if args.source_revision:
        report["source_revision"] = args.source_revision
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    if (
        max(errors["deployment_sensor_time"].values()) > 1e-4
        or target_error > 1e-5
        or max(data["format_error"], native_action_error or 0.0) > 2e-4
    ):
        raise ValueError(f"Deployment contract mismatch, details in {args.out}")
    if args.demo_dir:
        from tools.demo_zenbot_sequence import record_video
        from tools.evaluate_zenbot_source_getup import measure

        floor_steps = sum(lengths[:2])
        ground = measure(q[:floor_steps + 1], data["v"][:floor_steps + 1], data["foot_loads"][1:floor_steps + 1])
        ground.update(clip=args.floor_clip.name, offset_s=0.)
        summary = {"source": "Motion Train sim2sim_rpo_amp.run_mujoco", "sha256": report["checkpoint_sha256"],
                       "source_revision": report.get("source_revision"), "script_sha256": report["script_sha256"],
                       "mjcf_sha256": report["mjcf_sha256"], "continuous": True, "duration_s": len(q) * .02,
                       "simulation_hz": 50, "video_fps": 25, "ground": ground, "stages": stage_results}
        args.demo_dir.mkdir(parents=True, exist_ok=True)
        model_xml = args.motion_train / "robolab/data/robots/roboparty/zenbot/mjcf/zenbot.xml"
        if digest(model_xml) != report["mjcf_sha256"]:
            raise ValueError("The visual robot model must match the model used to simulate the trajectory")
        record_video(args.demo_dir / "sequence.mp4", q, commands, [s[0] for s in stages],
                     np.repeat(np.arange(len(stages)), lengths), model_xml=model_xml)
        (args.demo_dir / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(f"Verified {len(q)} × 234 inputs and {len(q)} × 23 motor targets: {args.out}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--motion-train", required=True, type=Path)
    parser.add_argument(
        "--deployment-python", type=Path, help="Interpreter with Motion Train deployment dependencies"
    )
    parser.add_argument("--torchscript", type=Path, help="TorchScript policy.pt loaded with the original API")
    parser.add_argument("--onnx", type=Path, help="Optional ONNX for comparison or ONNX-only source teacher")
    parser.add_argument(
        "--checkpoint", type=Path, help="Optional InstantAMP 234-input NPZ for native action parity"
    )
    parser.add_argument("--floor-clip", type=Path, help="Initialize the original simulation at clip frame 0")
    parser.add_argument("--stage-seconds", default=6.0, type=float)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--demo-dir", type=Path, help="Record the 66-second get-up and directional sequence in the source simulator")
    parser.add_argument("--source-revision", help="Motion Train commit used for this check")
    parser.add_argument("--capture", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.demo_dir and not (args.floor_clip and args.checkpoint and args.torchscript and args.onnx):
        parser.error("--demo-dir requires a floor clip and all three policy formats")
    if not (args.torchscript or args.onnx) or not np.isfinite(args.stage_seconds) or args.stage_seconds < 2.02:
        parser.error("Supply at least one policy and --stage-seconds of at least 2.02")
    if args.capture:
        capture(args)
    else:
        with TemporaryDirectory() as tmp:
            trace = Path(tmp) / "trace.npz"
            subprocess.run(
                [
                    str(args.deployment_python or sys.executable),
                    str(Path(__file__).resolve()),
                    *sys.argv[1:],
                    "--capture",
                    str(trace),
                ],
                check=True,
            )
            verify(trace, args)


if __name__ == "__main__":
    main()
