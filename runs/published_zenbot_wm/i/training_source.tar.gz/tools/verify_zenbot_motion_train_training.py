"""Compare training observations to Motion Train's original Isaac Lab 3 CPU observation group."""

import argparse
import hashlib
import importlib.util
import inspect
import json
import os
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np


def original(args):
    import torch
    import yaml
    from isaaclab.envs.mdp import observations as source_terms
    from isaaclab.managers import ObservationManager
    from isaaclab.utils.buffers import CircularBuffer
    from isaaclab.utils.noise import UniformNoiseCfg, uniform_noise

    repo = args.motion_train / "robolab"
    sys.path.insert(0, str(repo))
    path = repo / "robolab/tasks/manager_based/imu_observation.py"
    spec = importlib.util.spec_from_file_location("motion_train_imu", path)
    imu = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(imu)
    cfg = yaml.load(args.config.read_text(), Loader=yaml.BaseLoader)
    group = cfg["observations"]["policy"]
    assert group["enable_corruption"] == "true"
    terms = {name: term for name, term in group.items() if isinstance(term, dict)}
    robot = cfg["scene"]["robot"]
    lab_names = robot["joint_ordering"]
    trace = np.load(args.fixture)
    joint_order = [trace["mjcf_names"].tolist().index(n) for n in lab_names]
    defaults = torch.tensor([float(robot["init_state"]["joint_pos"].get(n, 0.0)) for n in lab_names])
    assert set(robot["init_state"]["joint_vel"].values()) == {"0.0"}
    steps, worlds = trace["fresh"].shape
    params = terms["base_ang_vel"]["params"]
    nominal = float(params["nominal_probability"])
    low = tuple(map(float, params["nominal_delay_range_s"]))
    high = tuple(map(float, params["tail_delay_range_s"]))
    dt = float(cfg["sim"]["dt"]) * int(cfg["decimation"])
    samples = torch.from_numpy(trace["delay_samples"])
    edge_delay = torch.from_numpy(trace["edge_delay"])
    edge_imu = torch.from_numpy(trace["edge_imu"])
    result = {
        "map": imu.map_mixed_uniform_samples(samples, nominal, low, high).numpy(),
        "interpolation": imu.interpolate_delayed_imu(*edge_imu, edge_delay, dt).numpy(),
    }
    for corrupt in (False, True):
        asset = SimpleNamespace()
        env = SimpleNamespace(
            num_envs=worlds,
            device="cpu",
            step_dt=dt,
            scene={"robot": SimpleNamespace(data=asset)},
            cfg=SimpleNamespace(observations=SimpleNamespace(policy=SimpleNamespace(enable_corruption=corrupt))),
            action_manager=SimpleNamespace(),
            command_manager=SimpleNamespace(),
        )
        # Inject tensors at the scene-read boundary. The production IMU term, other five term
        # calls, noise operation, CircularBuffers, and ObservationManager.compute_group run unmodified.
        manager = object.__new__(ObservationManager)
        manager._env, manager._term_output_specs = env, {}
        manager._resolve_terms_handle = None
        names = list(terms)
        manager._group_obs_term_names = {"policy": names}
        manager._group_obs_concatenate = {"policy": group["concatenate_terms"] == "true"}
        manager._group_obs_time_major = {"policy": group["history_order"] == "time"}
        manager._group_obs_concatenate_dim = {"policy": int(group["concatenate_dim"])}
        manager._group_obs_term_delay_buffer = {"policy": {}}
        manager._group_obs_term_history_buffer = {"policy": {}}
        histories = manager._group_obs_term_history_buffer["policy"]
        term_cfgs = []
        for name, node in terms.items():
            assert all(node[k] == "null" for k in ("modifiers", "clip", "scale"))
            assert int(node["delay_max_lag"]) == int(node["delay_min_lag"]) == 0
            impl = node["func"].split(":")[-1]
            kwargs = node["params"]
            config = SimpleNamespace(
                params=dict(kwargs),
                modifiers=None,
                scale=None,
                clip=None,
                noise=None,
                history_length=int(group["history_length"]),
                flatten_history_dim=group["flatten_history_dim"] == "true",
            )
            if impl == "RandomizedDelayedImuObservation":
                config.params.update(
                    nominal_probability=float(kwargs["nominal_probability"]),
                    nominal_delay_range_s=tuple(map(float, kwargs["nominal_delay_range_s"])),
                    tail_delay_range_s=tuple(map(float, kwargs["tail_delay_range_s"])),
                )
                config.func = imu.RandomizedDelayedImuObservation(config, env)
            else:
                config.func = getattr(source_terms, impl)
            if corrupt and node["noise"] != "null":
                n = node["noise"]
                assert n["func"].endswith(":uniform_noise")
                config.noise = UniformNoiseCfg(
                    n_min=float(n["n_min"]), n_max=float(n["n_max"]), operation=n["operation"]
                )
                config.noise.func = uniform_noise
            term_cfgs.append(config)
            histories[name] = CircularBuffer(config.history_length, worlds, "cpu", stack_dim=1)
        manager._group_obs_term_cfgs = {"policy": term_cfgs}
        outcomes = []
        for t in range(steps):
            env.common_step_counter = t
            fresh = np.flatnonzero(trace["fresh"][t])
            if len(fresh):
                ids = torch.from_numpy(fresh)
                for history in histories.values():
                    history.reset(ids)
                with patch.object(torch, "rand", return_value=samples[t, fresh]):
                    term_cfgs[0].func.reset(ids)
            raw = torch.from_numpy(trace["imu"][t])
            asset.root_ang_vel_b, asset.projected_gravity_b = raw[:, :3], raw[:, 3:]
            asset.default_joint_pos = SimpleNamespace(torch=defaults.expand(worlds, -1))
            asset.default_joint_vel = SimpleNamespace(torch=torch.zeros((worlds, 23)))
            asset.joint_pos = SimpleNamespace(torch=torch.from_numpy(trace["angle"][t][:, joint_order]))
            asset.joint_vel = SimpleNamespace(torch=torch.from_numpy(trace["speed"][t][:, joint_order]))
            env.action_manager.action = torch.from_numpy(trace["action"][t][:, joint_order])
            generated = torch.from_numpy(trace["cmd"][t])
            env.command_manager.get_command = lambda name, command=generated: command
            # Feed precisely the same per-coordinate quantiles to the two RNG implementations.
            n = (torch.from_numpy(trace["noise"][t]) + 1.0) / 2.0
            draws = iter([n[:, :3], n[:, 3:6], n[:, 9:32][:, joint_order], n[:, 32:55][:, joint_order]])
            with patch.object(torch, "rand_like", side_effect=lambda tensor, draws=draws: next(draws)):
                outcomes.append(manager.compute_group("policy", update_history=True).numpy().copy())
        result["corrupt" if corrupt else "clean"] = np.stack(outcomes)
    sources = {
        "motion_train_imu": path,
        "isaaclab_observation_manager": Path(inspect.getfile(ObservationManager)),
        "isaaclab_history": Path(inspect.getfile(CircularBuffer)),
        "isaaclab_terms": Path(source_terms.__file__),
    }
    result["source_sha256"] = json.dumps(
        {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in sources.items()}
    )
    np.savez(args.reference, **result)


def compare(args, directory):
    os.environ.setdefault("JAX_PLATFORMS", "cpu")
    import jax
    import jax.numpy as jnp
    from scipy.spatial.transform import Rotation

    from instantamp import zenbot
    from instantamp.sim import Sim, unflatten
    from instantamp.train_g1_getup_amp import GetUpAMP
    from instantamp.zenbot_motion_train_obs import (
        interpolate_delayed_imu,
        map_imu_delay,
    )

    rng = np.random.default_rng(33331)
    steps, worlds = 12, args.worlds
    shape = (steps, worlds)
    fresh = np.zeros(shape, bool)
    fresh[0], fresh[4, ::2], fresh[7, -1], fresh[9, 1::3] = True, True, True, True

    def normal(channels):
        return rng.normal(size=(*shape, channels)).astype("f")

    imu = normal(6)
    quat = normal(4)
    quat /= np.linalg.norm(quat, axis=-1, keepdims=True)
    world_rotation = Rotation.from_quat(quat.reshape(-1, 4), scalar_first=True).as_matrix()
    imu[..., 3:] = -world_rotation[:, 2].reshape(*shape, 3)
    edges = np.array([0.0, 0.002, 0.010, 0.0199999, 0.020, 0.0200001, 0.035, 0.040], dtype=np.float32)
    edge_imu = rng.normal(size=(3, len(edges), 6)).astype("f")
    keys = jax.random.split(jax.random.key(913), steps)
    delay_samples, noise = [], []
    for key in keys:
        k1, k2 = jax.random.split(jax.random.fold_in(key, 234))
        delay_samples.append(np.asarray(jax.random.uniform(k1, (worlds, 2))))
        noise.append(np.asarray(jax.random.uniform(k2, (worlds, 78), minval=-1.0, maxval=1.0)))
    inputs = {
        "imu": imu,
        "fresh": fresh,
        "cmd": normal(3),
        "angle": normal(23),
        "speed": normal(23),
        "action": normal(23),
        "mjcf_names": [f"{n}_joint" for n in zenbot.DOF],
        "edge_delay": edges,
        "edge_imu": edge_imu,
        "delay_samples": delay_samples,
        "noise": noise,
    }
    src, ref = directory / "data.npz", directory / "ref.npz"
    np.savez(src, **inputs)
    subprocess.run(
        [
            str(args.isaaclab_python),
            str(Path(__file__).resolve()),
            *sys.argv[1:],
            "--fixture",
            str(src),
            "--reference",
            str(ref),
        ],
        check=True,
    )
    reference = np.load(ref)
    errors = {
        "delay_map_s": float(abs(reference["map"] - map_imu_delay(jnp.asarray(delay_samples))).max()),
        "delayed_imu_edges": float(
            abs(
                reference["interpolation"] - interpolate_delayed_imu(*jnp.asarray(edge_imu), jnp.asarray(edges))
            ).max()
        ),
    }
    for corrupt in (False, True):
        state = SimpleNamespace(motion_train_sensors=None)
        sim = SimpleNamespace(noisy_obs=corrupt)
        obs = []
        for t, key in enumerate(keys):
            zeros = np.zeros((worlds, 3), np.float32)
            q = jnp.asarray(np.column_stack((zeros, quat[t], inputs["angle"][t])))
            v = jnp.asarray(np.column_stack((zeros, imu[t, :, :3], inputs["speed"][t])))
            state.data = SimpleNamespace(qpos=q, qvel=v)
            state.a_last = jnp.asarray(inputs["action"][t])
            rotation = unflatten(q, v)[1]
            state.motion_train_sensors = Sim.motion_train_sensors(
                sim, state, rotation, jnp.asarray(inputs["cmd"][t]), jnp.asarray(fresh[t]), key
            )
            obs.append(np.asarray(GetUpAMP.actor_input(None, state)))
        mode = "corrupt" if corrupt else "clean"
        errors[mode] = float(np.abs(np.stack(obs) - reference[mode]).max())
    config_path, source_root = args.config.resolve(), args.motion_train.resolve()
    report = {
        "env_yaml": str(config_path.relative_to(source_root) if config_path.is_relative_to(source_root) else config_path.name),
        "sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
        "source_group": "observations.policy",
        "target": "Sim.motion_train_sensors -> GetUpAMP.actor_input",
        "shape": [*shape, 234],
        "reset_worlds_per_step": fresh.sum(1).tolist(),
        "identical_draws": True,
        "source_sha256": json.loads(str(reference["source_sha256"])),
        "error_max_abs": errors,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    if max(errors.values()) > 2e-5:
        raise ValueError(f"Training observation mismatch: {errors}")
    print(report)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--motion-train", required=True, type=Path)
    p.add_argument("--config", required=True, type=Path, help="Original training run params/env.yaml")
    p.add_argument("--isaaclab-python", required=True, type=Path, help="Motion Train's Isaac Lab 3 interpreter")
    p.add_argument("--worlds", type=int, default=32, help="Number of parallel environments; use 1 to test a single world")
    p.add_argument("--out", required=True, type=Path)
    p.add_argument("--fixture", type=Path, help=argparse.SUPPRESS)
    p.add_argument("--reference", type=Path, help=argparse.SUPPRESS)
    args = p.parse_args()
    if args.worlds < 1:
        p.error("--worlds must be positive")
    if args.fixture:
        original(args)
    else:
        with TemporaryDirectory() as tmp:
            compare(args, Path(tmp))
