"""Recreate the released 46 physical windows directly from the seven Zenbot AMP motions."""
import argparse
import ctypes
import hashlib
import io
import json
import os
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZipInfo, ZIP_STORED

if __name__ == "__main__":
    os.environ["JAX_PLATFORMS"] = "cpu"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"

import mujoco as mj
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from instantamp import zenbot
from tools.prepare_zenbot_physical_gait import DEFAULT_BANK, accepted, advance, sha256
from tools.prepare_zenbot_scratch_pairs import NativeWorld, read_motion

HERE = Path(__file__).resolve().parent
H = 18
DT = .02
INTEGRATION = mj.mjtState.mjSTATE_INTEGRATION
NAMES = ("forward", "run", "back", "left", "right", "turn_left", "turn_right")
COMMAND = dict(zip(NAMES, zenbot.DIRECTIONAL_COMMANDS[1:].astype(float), strict=True))


def build_kernel(kernel, cache):
    mode = ("window", "window_tracking", "window_footpath").index(kernel)
    source = HERE / "shoot.cc"
    pkg = Path(mj.__file__).parent
    lib = next(pkg.glob("libmujoco.so.*"))
    cache.mkdir(exist_ok=True, parents=True)
    stamp = hashlib.sha256(source.read_bytes() + str(lib).encode()).hexdigest()[:16]
    binary = cache / f"gait_shoot_{mode}_{stamp}.so"
    if not binary.is_file():
        with TemporaryDirectory(dir=cache) as td:
            output = Path(td) / "shoot.so"
            subprocess.run([os.getenv("CXX","c++"), "-O3", "-fPIC", "-std=c++17", "-shared", f"-DOBJECTIVE={mode}",
                            "-I"+str(pkg/"include"), str(source), str(lib), "-Wl,-rpath,"+str(pkg), "-o",str(output)],
                           check=True)
            os.replace(output, binary)
    native = ctypes.CDLL(str(binary.resolve()))
    buf = np.ctypeslib.ndpointer(dtype=np.float64,flags="C_CONTIGUOUS")
    ints = np.ctypeslib.ndpointer(dtype=np.int32,flags="C_CONTIGUOUS")
    ptr = ctypes.c_void_p
    native.gait_batch.argtypes = [ptr, ptr, ctypes.c_int, ctypes.c_int, buf, buf, buf, buf, buf, ints, buf, buf]
    native.gait_batch.restype = None
    native.first_step.argtypes = [ptr, ptr, buf, buf]
    native.first_step.restype = None
    return native


def sample(motion, frames, scale):
    """Retarget the time-scaled AMP pose and both velocity tracks at fractional source frames."""
    rr = Rotation.from_quat(motion.qpos[:, [4, 5, 6, 3]])
    q = np.empty((len(frames), motion.qpos.shape[1]))
    v = np.empty((len(frames), motion.recorded_velocity.shape[1]))
    dv = np.empty((len(frames), motion.qvel.shape[1]))
    x = np.arange(len(motion.qpos))
    for j in range(q.shape[1]):
        q[:, j] = np.interp(frames, x, motion.qpos[:, j])
    for j in range(v.shape[1]):
        v[:, j] = scale * np.interp(frames, x, motion.recorded_velocity[:, j])
        dv[:, j] = scale * np.interp(frames, x, motion.qvel[:, j])
    rot = Slerp(x, rr)(frames)
    direction = np.arctan2(rot.as_matrix()[0, 1, 0], rot.as_matrix()[0, 0, 0])
    reorient = Rotation.from_rotvec([0, 0, -direction])
    q[:, 3:7] = (reorient * rot).as_quat(scalar_first=True)
    q[:, :2] = 0.0
    v[:, :3] = reorient.apply(v[:, :3])
    dv[:, :3] = reorient.apply(dv[:, :3])
    return q, v, dv


def bias_at(initial, plan, t, h):
    """Interpolate the two target offsets with a bounded, continuous cubic step."""
    middle = h // 3
    if t < middle:
        left, right, u = (initial, plan[0], (t + 1) / middle)
    else:
        left, right, u = (plan[0], plan[1], min(1.0, (t + 1 - middle) / (h - middle)))
    u = u * u * (3.0 - 2.0 * u)
    return left + (right - left) * u


def solve(native, m, d, pd, prior, mean, nominal, reference, feet, foot_ids, rng, pop, elites):
    """Shoot antithetic target-offset samples and refit their distribution to the best eighth."""
    h = len(reference)
    best = mean.copy()
    loss = np.inf
    motor_std = np.r_[np.tile([.32, .18, .15, .36, .28, .17], 2), .1,
                      np.tile([.18, .15, .1, .17, .08], 2)]
    std = np.broadcast_to(motor_std, mean.shape).copy()
    for _ in range(elites):
        e = rng.normal(size=(pop // 2, 2, m.nu))
        e[:, 1] = 0.45 * e[:, 0] + np.sqrt(1 - 0.45 ** 2) * e[:, 1]
        pool = np.clip(mean + std * np.r_[e, -e], -0.95, 0.95)
        pool[:4] = [best, np.zeros_like(best), np.broadcast_to(prior, best.shape), mean]
        costs = np.empty(pop)
        native.gait_batch(m._address, d._address, pop, h, pd, prior, nominal, reference, feet, foot_ids, pool, costs)
        order = np.argsort(costs)
        if costs[order[0]] < loss:
            loss = float(costs[order[0]])
            best = pool[order[0]].copy()
        good = pool[order[:max(4, pop // 8)]]
        mean = 0.8 * good.mean(0) + 0.2 * mean
        std = np.maximum(0.04, 0.75 * good.std(0) + 0.25 * std)
    return best


def frames(world, motion, start, rate, cmd, mode, T):
    rel = np.arange(-7, T + H + 5)
    ix = start + rel * rate
    q, v, dv = sample(motion, ix, rate)
    nominal = np.ascontiguousarray(q[:, 7:] + zenbot.KD / zenbot.KP * dv[:, 6:])
    speed = np.broadcast_to(cmd, (len(q), 3)).copy()
    if mode == 'standing_start':
        speed *= np.clip((rel[:, None] + 0.5) * DT / 0.55, 0, 1)
    xy = np.cumsum(speed[:, :2] * DT, axis=0)
    xy -= xy[7].copy()
    ref = np.ascontiguousarray(np.c_[q[:, 2:7], speed, xy])
    ids = np.asarray([world.model.body('robot_' + f).id for f in zenbot.FEET], np.int32)
    d = mj.MjData(world.model)
    feet = np.empty((len(q), 6))
    for t, pose in enumerate(q):
        d.qpos[:] = pose
        mj.mj_kinematics(world.model, d)
        feet[t] = (d.xpos[ids] - pose[:3]).ravel()
    return (q, v, nominal, ref, feet, ids, ix)


def generate(world, lib, motion, name, start, rate, kind, source_tag, seed, phase, budget, refits, plan_prefix, T):
    """Replay a selected planning job and record every physical tick and causal motor input."""
    TAIL = T - 20
    cmd = COMMAND[name]
    mode = 'standing_start' if kind in ('run_onset', 'walk_onset', 'cold') else 'moving'
    q, v, nominal, ref, feet, ids, ix = frames(world, motion, start, rate, cmd, mode, T)
    m = world.model
    d = mj.MjData(m)
    rng = np.random.default_rng([seed, NAMES.index(name), phase, mode == 'standing_start', kind == 'accelerate'])
    delays = rng.integers(3, 8, 5, dtype=np.int32)
    lags = delays[zenbot.GROUP]
    zero = zenbot.DEFAULT_Q.astype(float)
    prev = older = zero.copy()
    d.qpos[:] = world.stance if mode == 'standing_start' else q[3]
    d.qvel[:] = 0.0 if mode == 'standing_start' else v[3]
    if mode == 'moving':
        prev, older = (nominal[4].copy(), nominal[3].copy())
    d.qpos[7:] += np.deg2rad(rng.uniform(-1.5, 1.5, m.nu))
    rot = Rotation.from_quat(d.qpos[3:7], scalar_first=True) * Rotation.from_euler('xy', rng.uniform(-1.0, 1.0, 2), degrees=True)
    d.qpos[3:7] = rot.as_quat(scalar_first=True)
    d.qvel[:2] += rng.uniform(-0.035, 0.035, 2)
    mj.mj_forward(m, d)
    if mode == 'standing_start':
        eq = zero + world.feedforward / zenbot.KP
        for _ in range(22):
            advance(world, d, eq, prev, older, lags)
            older, prev = (prev, eq)
    before_bias = np.zeros(23)
    preceding_plan = None
    if plan_prefix and mode == 'moving':
        pd = np.ascontiguousarray(np.r_[zenbot.KP, zenbot.KD, zenbot.EFFORT, zenbot.SPEED, prev, older, lags], dtype=float)
        preceding_plan = solve(lib, m, d, pd, before_bias, np.zeros((2, 23)),
                              nominal[5:5 + H], ref[4:4 + H], feet[4:4 + H], ids, rng, budget, refits)
    pre_pos = []
    pre_vel = []
    pre_act = []
    pre_cmd = []
    pre_frame = []
    prior_load = np.zeros(2)
    for j in range(-4, 0):
        c = np.zeros(3) if mode == 'standing_start' else cmd
        last = (prev - zero) / zenbot.ACTION_SCALE
        sensed, _ = world.measure(d, c, last)
        pre_pos.append(d.qpos.copy())
        pre_vel.append(d.qvel.copy())
        pre_frame.append(sensed)
        pre_act.append(last)
        pre_cmd.append(c)
        applied = (eq if j < -2 else zero) if mode == 'standing_start' else nominal[7 + j + 2]
        if preceding_plan is not None:
            before_bias = bias_at(np.zeros(23), preceding_plan, j + 4, H)
            applied = applied + before_bias
        prior_load, _ = advance(world, d, applied, prev, older, lags)
        older, prev = (prev, applied)
    pre_standing = bool(prior_load.min() > 0.2 and np.linalg.norm(d.qvel[:2]) < 0.15) if mode == 'standing_start' else True
    initial = np.empty(mj.mj_stateSize(m, INTEGRATION))
    mj.mj_getState(m, d, initial, INTEGRATION)
    init_raw = np.stack(((older - zero) / zenbot.ACTION_SCALE, (prev - zero) / zenbot.ACTION_SCALE))
    bias = before_bias
    center = np.zeros((2, 23))
    if preceding_plan is not None:
        center[0] = bias_at(np.zeros(23), preceding_plan, H // 3 - 1 + 4, H)
        center[1] = preceding_plan[1]
    requested = []
    real_goals = []
    loads = []
    flights = []
    physical = []
    rawframes = []
    pos = [d.qpos.copy()]
    vel = [d.qvel.copy()]
    for t in range(0, T, 4):
        k = t + 7
        pd = np.ascontiguousarray(np.r_[zenbot.KP, zenbot.KD, zenbot.EFFORT, zenbot.SPEED, prev, older, lags], dtype=float)
        goals = nominal[k + 2:k + 2 + H]
        plan = solve(lib, m, d, pd, bias, center, goals, ref[k + 1:k + 1 + H], feet[k + 1:k + 1 + H], ids, rng, budget, refits)
        initial_bias = bias.copy()
        count = min(4, T - t)
        for j in range(count):
            last = (prev - zero) / zenbot.ACTION_SCALE
            row, measured = world.measure(d, cmd, last)
            rawframes.append(row)
            physical.append(measured)
            bias = bias_at(initial_bias, plan, j, H)
            applied = np.ascontiguousarray(goals[j] + bias)
            requested.append((applied - zero) / zenbot.ACTION_SCALE)
            real_goals.append(applied)
            load, air = advance(world, d, applied, prev, older, lags)
            older, prev = (prev, applied)
            loads.append(load)
            flights.append(air)
            pos.append(d.qpos.copy())
            vel.append(d.qvel.copy())
        center[0] = bias_at(initial_bias, plan, H // 3 - 1 + count, H)
        center[1] = plan[1]
    pos = np.asarray(pos)
    vel = np.asarray(vel)
    loads = np.asarray(loads)
    flights = np.asarray(flights)
    raw = np.asarray(requested)
    if not (pre_standing and accepted(pos, loads, flights, cmd, TAIL)):
        raise ValueError(f'Replanned window failed its measured physical gate: {name} {seed}')
    verify = mj.MjData(m)
    mj.mj_setState(m, verify, initial, INTEGRATION)
    mj.mj_forward(m, verify)
    older, prev = zero + zenbot.ACTION_SCALE * init_raw
    worst = 0.0
    for t, action in enumerate(raw):
        pd = np.ascontiguousarray(np.r_[zenbot.KP, zenbot.KD, zenbot.EFFORT, zenbot.SPEED, prev, older, lags], dtype=float)
        applied = np.ascontiguousarray(zero + zenbot.ACTION_SCALE * action)
        lib.first_step(m._address, verify._address, pd, applied)
        worst = max(worst, abs(verify.qpos - pos[t + 1]).max(), abs(verify.qvel - vel[t + 1]).max())
        older, prev = (prev, applied)
    assert worst < 1e-08, worst
    assert np.allclose(np.asarray(rawframes)[:, 55:], np.vstack((init_raw[-1], raw[:-1])), atol=4e-06)
    artifact = dict(
        qpos=pos,
        qvel=vel,
        raw_action=raw,
        pd_target=np.asarray(real_goals),
        command=cmd,
        initial_prev_raw=init_raw,
        delays=delays,
        source_clip=motion.path.name,
        source_sha256=hashlib.sha256(motion.path.read_bytes()).hexdigest(),
        source_frame=start,
        source_frames=ix[7:7 + T + 1],
        source_type=source_tag,
        seed=seed,
        planner_seed=seed,
        source_phase=phase,
        playback_rate=rate,
        mode=mode,
        score_from_step=TAIL,
        score_to_step=T,
        prefix_qpos=np.asarray(pre_pos),
        prefix_qvel=np.asarray(pre_vel),
        prefix_previous_raw=np.asarray(pre_act),
        prefix_command=np.asarray(pre_cmd),
        prefix_raw_frames=np.asarray(pre_frame),
        raw_frames=np.asarray(rawframes),
        initial_mj_integration_state=initial,
        foot_load_bw=loads,
        flight_per_substep=flights,
        physical=np.asarray(physical),
        initial_foot_load_bw=prior_load,
    )
    return artifact



def rebuild(clips, manifest, out):
    info = json.loads(Path(manifest).read_text())
    jobs = json.loads((HERE / "shooting_settings.json").read_text())
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    target = out / "windows.zip"
    if target.is_file():
        if sha256(target) == info["windows_sha256"]:
            return target
        raise ValueError(f"An existing archive in {out} differs from the released windows")
    world = NativeWorld()
    motions, kernels = {}, {}
    with TemporaryDirectory(dir=out) as td:
        partial = Path(td) / "windows.zip"
        with ZipFile(partial, "w") as archive:
            for i, row in enumerate(info["windows"], start=1):
                settings = jobs[row["file"]]
                clip, skill = row["clip"], row["skill"]
                if clip not in motions:
                    path = Path(clips) / clip
                    if sha256(path) != info["clips"][clip]["converted_sha256"]:
                        raise ValueError(f"Converted AMP motion checksum failed for {clip}")
                    motions[clip] = read_motion(path, skill, 0, world.model, world.soles)
                name = info["names"][skill - 2]
                kind = "cold" if row["mode"] == "standing_start" else "moving"
                kernel = settings["kernel"]
                if kernel not in kernels:
                    kernels[kernel] = build_kernel(kernel, out / ".cache")
                arrays = generate(world, kernels[kernel], motions[clip], name, row["start_frame"], settings["rate"],
                                  kind, settings["source_type"], row["seed"], settings["phase"],
                                  settings["budget"], settings["refits"], settings["plan_prefix"], row["steps"])
                buf = io.BytesIO()
                np.savez_compressed(buf, **arrays)
                data = buf.getvalue()
                if hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ValueError(f"Replanned {row['file']} differs from its released window")
                member = ZipInfo(row["file"], (1980,1,1,0,0,0))
                member.compress_type, member.external_attr = ZIP_STORED, 0o100644 << 16
                archive.writestr(member, data)
                print(f"{i}/46 {row['file']} verified", flush=True)
        if sha256(partial) != info["windows_sha256"]:
            raise ValueError("Final physical window archive checksum differs")
        os.replace(partial, target)
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clips", type=Path, required=True, help="Prepared 50 Hz AMP walk_run directory")
    parser.add_argument("--manifest", type=Path, default=DEFAULT_BANK / "manifest.json")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(rebuild(args.clips, args.manifest, args.out))
