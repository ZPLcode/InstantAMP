#include <mujoco/mujoco.h>
#include <algorithm>
#include <cmath>

// These are the original three short-window shooting objectives used for the accepted windows.
constexpr bool foot_path = OBJECTIVE == 2;
constexpr double height_scale = foot_path ? .048 : .08;
constexpr double vx_scale = OBJECTIVE == 0 ? .55 : (foot_path ? .45 : .30);
constexpr double vy_scale = OBJECTIVE == 0 ? .4 : (foot_path ? .28 : .23);
constexpr double yaw_scale = OBJECTIVE == 0 ? .60 : (foot_path ? .48 : .35);
constexpr double tilt_scale = foot_path ? .30 : .4;
constexpr double foot_scale = foot_path ? .11 : .12;
static double smooth(double t) {
    t=std::clamp(t,0.0,1.0);
    return t*t*(3.0-2.0*t);
}

// PD arrays are kp, kd, effort, speed, previous target, older target, delay.
static void forward(const mjModel* m, mjData* d, const double* pd, const double* goal,
                    const double* previous, const double* older) {
    const int n=m->nu;
    for (int s=0;s<4;s++) {
        for (int j=0;j<n;j++) {
            const int delay=static_cast<int>(pd[6*n+j]);
            const double target = s>=delay ? goal[j] : s+4>=delay ? previous[j] : older[j];
            const double v=d->qvel[6+j];
            double torque=std::clamp(pd[j]*(target-d->qpos[7+j])-pd[n+j]*v,-pd[2*n+j],pd[2*n+j]);
            d->ctrl[j]=std::abs(v)>=pd[3*n+j] && v*torque>0. ? 0. : torque;
        }
        mj_step(m,d);
    }
}

extern "C" void first_step(const mjModel* m,mjData* d,const double* pd,const double* goal) {
    forward(m,d,pd,goal,pd+4*m->nu,pd+5*m->nu);
}

extern "C" void gait_batch(const mjModel* m, const mjData* initial, int pop, int h,
                           const double* pd, const double* bias, const double* nominal,
                           const double* reference, const double* feet, const int* links,
                           const double* knots, double* losses) {
    const int n=m->nu, mid=std::max(2,h/3);
    mjData* d=mj_makeData(m);
    for (int i=0;i<pop;i++) {
        mj_copyData(d,m,initial);
        const double *k=knots+i*2*n;
        double goal[23], prev[23], older[23], total=0., last=0.;
        std::copy(pd+4*n,pd+5*n,prev);std::copy(pd+5*n,pd+6*n,older);
        for (int t=0;t<h;t++) {
            const bool early=t<mid;
            const double a=early?smooth((t+1.)/mid):smooth((t+1.-mid)/(h-mid));
            for (int j=0;j<n;j++) {
                goal[j]=nominal[t*n+j]+(1.-a)*(early?bias[j]:k[j])+a*(early?k[j]:k[n+j]);
            }
            forward(m,d,pd,goal,prev,older);
            std::copy(prev,prev+n,older);std::copy(goal,goal+n,prev);
            mj_kinematics(m,d);
            const double* ref=reference+t*10; // height, quaternion, horizontal velocity, yaw rate, reference x/y
            double dot=0.,feet_error=0.;
            for(int j=0;j<4;j++) dot+=d->qpos[3+j]*ref[1+j];
            for(int f=0;f<2;f++) for(int ax=0;ax<3;ax++) {
                const double origin = foot_path ? (ax == 2 ? ref[0] : ref[8+ax]) : d->qpos[ax];
                const double e=d->xpos[3*links[f]+ax]-origin-feet[6*t+3*f+ax];
                feet_error+=e*e;
            }
            const double z=(d->qpos[2]-ref[0])/height_scale;
            const double vx=(d->qvel[0]-ref[5])/vx_scale, vy=(d->qvel[1]-ref[6])/vy_scale;
            const double speed=std::hypot(ref[5],ref[6]);
            const double x=d->qpos[0]-ref[8], y=d->qpos[1]-ref[9];
            const double track=speed>.03 ? std::abs(x*ref[6]-y*ref[5])/speed : std::hypot(x,y);
            const double* quat=d->qpos+3;
            const double w=quat[0],qx=quat[1],qy=quat[2],qz=quat[3];
            const double world_wz=2*(qx*qz-w*qy)*d->qvel[3]+2*(qy*qz+w*qx)*d->qvel[4]+(1-2*(qx*qx+qy*qy))*d->qvel[5];
            const double yaw_rate=(world_wz-ref[7])/yaw_scale;
            last=track*track/(.18*.18)+yaw_rate*yaw_rate+z*z+4.*std::max(0.,1.-dot*dot)/(tilt_scale*tilt_scale)+feet_error/(2*foot_scale*foot_scale)+vx*vx+vy*vy;
            total+=last;
            if(!std::isfinite(total)||d->warning[mjWARN_BADQACC].number) {total=1.e20; break;}
        }
        losses[i]=total/h+.6*last;
    }
    mj_deleteData(d);
}
