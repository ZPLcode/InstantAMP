"""Finite-horizon local feedback about a physical Zenbot trajectory and training sensor replay."""
import ctypes
import hashlib
import os
import platform
import subprocess
from functools import lru_cache
from pathlib import Path
from tempfile import TemporaryDirectory

import jax
import jax.numpy as jnp
import mujoco
import numpy as np

from instantamp import zenbot
from instantamp.zenbot_motion_train_obs import advance_sensors


@lru_cache(maxsize=8)
def _tangent(cache_dir):
    source = Path(__file__).with_name("zenbot_reference_tangent.cc")
    pkg = Path(mujoco.__file__).parent
    library = next(pkg.glob("libmujoco.so.*"))
    fingerprint = hashlib.sha256(source.read_bytes() + str((mujoco.__version__, platform.machine(), library)).encode()).hexdigest()[:20]
    cache = Path(cache_dir)
    cache.mkdir(parents=True, exist_ok=True)
    binary = cache / f"zenbot_tangent_{fingerprint}.so"
    if not binary.is_file():
        with TemporaryDirectory(dir=cache) as td:
            target = Path(td) / "tangent.so"
            subprocess.run([os.getenv("CXX", "c++"), "-O3", "-fopenmp", "-std=c++17", "-shared", "-fPIC",
                            "-I" + str(pkg / "include"), str(source), str(library),
                            "-Wl,-rpath," + str(pkg), "-o", str(target)], check=True)
            os.replace(target, binary)
    tangent = ctypes.CDLL(str(binary.resolve())).tangent
    double = np.ctypeslib.ndpointer(dtype=np.float64, flags="C_CONTIGUOUS")
    integers = np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS")
    tangent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, double, double, double, double, integers, double]
    tangent.restype = None
    return tangent


def local_gains(world, q, v, target, delay, initial_raw=None, *, cache_dir, threads=2):
    """Linearize four delayed PD ticks and compute finite-horizon state feedback in target radians."""
    if not isinstance(threads, int) or threads < 1:
        raise ValueError("threads must be a positive integer")
    tangent = _tangent(str(Path(cache_dir).resolve()))
    initial = np.zeros((2, 23)) if initial_raw is None else np.asarray(initial_raw)
    if initial.shape != (2, 23):
        raise ValueError("Expected two previous requested actions, oldest first")
    if (np.shape(q) != (len(target) + 1, 30) or np.shape(v) != (len(target) + 1, 29)
            or np.shape(target) != (len(target), 23) or world.model.nq != 30 or world.model.nv != 29):
        raise ValueError("Expected T+1 Zenbot states and T joint targets")
    delay = np.ascontiguousarray(delay, dtype=np.int32)
    if delay.shape != (23,) or not np.all((delay >= 3) & (delay <= 7)):
        raise ValueError("Expected the per-motor MJCF delay in physics ticks")
    history = np.ascontiguousarray(np.vstack((zenbot.DEFAULT_Q + .25 * initial, target)), dtype=float)
    motor = np.ascontiguousarray((zenbot.KP, zenbot.KD, zenbot.EFFORT, zenbot.SPEED), dtype=float)
    linear = np.empty((len(target), 58, 127))
    tangent(world.model._address, len(target), threads, np.ascontiguousarray(q[:-1], dtype=float),
            np.ascontiguousarray(v[:-1], dtype=float), history, motor, delay, linear)
    weights = np.r_[[7, 7, 155, 70, 70, 20], np.full(23, 2.5), [.5, .5, .8, .18, .18, .15],
                    np.full(23, .012), np.full(46, .18)]
    scale = np.sqrt(weights)
    gains = np.empty((len(target), 23, 104), np.float32)
    eye = np.eye(104)
    control_cost = 2.8 * np.eye(23)
    value = eye.copy()
    matrix = np.zeros((104, 127))
    matrix[58:81, 104:] = matrix[81:, 58:81] = np.eye(23)
    for i in range(len(target) - 1, -1, -1):
        matrix[:58] = linear[i]
        a = matrix[:, :104] * scale[:, None] / scale
        b = matrix[:, 104:] * scale[:, None]
        u, s, vh = np.linalg.svd(a, full_matrices=False)
        a = (u * np.minimum(s, 5.5)) @ vh
        v_next = .984 * value
        g = -np.linalg.solve(control_cost + b.T @ v_next @ b, b.T @ v_next @ a)
        closed = a + b @ g
        value = eye + closed.T @ v_next @ closed + g.T @ control_cost @ g
        value = (value + value.T) / 2
        gains[i] = g * scale
    return gains


def with_training_sensors(raw, key):
    """Convert chronological [T, N, 78] noiseless frames into the training actor's [T, N, 234]."""
    def add_sensor(previous, data):
        tick, frames, noise_key = data
        fresh = jnp.full(len(frames), tick == 0)
        sensors = advance_sensors(previous, frames[:, :6], frames[:, 6:9], frames[:, 9:32],
                                  frames[:, 32:55], frames[:, 55:], fresh, noise_key, True)
        return sensors, sensors.observation()

    first = raw[0]
    init_key, series_key = jax.random.split(key)
    initial = advance_sensors(None, first[:, :6], first[:, 6:9], first[:, 9:32], first[:, 32:55],
                              first[:, 55:], jnp.ones(len(first), bool), init_key, True)
    _, obs = jax.lax.scan(add_sensor, initial, (jnp.arange(len(raw)), raw, jax.random.split(series_key, len(raw))))
    return obs
