#include <mujoco/mujoco.h>
#include <omp.h>

#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
constexpr int kPositions = 30;
constexpr int kVelocities = 29;
constexpr int kMotors = 23;
constexpr int kPhysicalState = 2 * kVelocities;
constexpr int kInputs = kPhysicalState + 3 * kMotors;

double perturbation_size(int column) {
  if (column < 3) return .002;
  if (column < kVelocities) return .009;
  if (column < kVelocities + 6) return .04;
  if (column < kPhysicalState) return .09;
  return .035;
}
}  // namespace

// Central differences for one 50 Hz transition. Input columns are tangent position,
// velocity, previous target, older target, and current target, all in MJCF order.
extern "C" void tangent(const mjModel* model, int steps, int threads,
                        const double* positions, const double* velocities,
                        const double* targets, const double* motor,
                        const int* delay, double* output) {
  #pragma omp parallel num_threads(threads)
  {
    mjData* data = mj_makeData(model);
    #pragma omp for schedule(dynamic)
    for (int t = 0; t < steps; ++t) {
      for (int column = 0; column < kInputs; ++column) {
        const double h = perturbation_size(column);
        double minus_pos[kPositions], minus_vel[kVelocities], delta[kVelocities];
        for (int sign : {-1, 1}) {
          mj_resetData(model, data);
          std::memcpy(data->qpos, positions + t * kPositions, sizeof(minus_pos));
          std::memcpy(data->qvel, velocities + t * kVelocities, sizeof(minus_vel));
          // The caller prepends the two real actuator requests in chronological order.
          double u[3][kMotors];
          std::memcpy(u[0], targets + (t + 1) * kMotors, sizeof(u[0]));
          std::memcpy(u[1], targets + t * kMotors, sizeof(u[1]));
          std::memcpy(u[2], targets + (t + 2) * kMotors, sizeof(u[2]));
          if (column < kVelocities) {
            double displacement[kVelocities] = {};
            displacement[column] = sign * h;
            mj_integratePos(model, data->qpos, displacement, 1.);
          } else if (column < kPhysicalState) {
            data->qvel[column - kVelocities] += sign * h;
          } else {
            const int index = column - kPhysicalState;
            u[index / kMotors][index % kMotors] += sign * h;
          }
          mj_forward(model, data);
          for (int substep = 0; substep < 4; ++substep) {
            for (int j = 0; j < kMotors; ++j) {
              const int applied = substep >= delay[j] ? 2 : (substep + 4 >= delay[j] ? 0 : 1);
              const double speed = data->qvel[6 + j];
              const double requested = motor[j] * (u[applied][j] - data->qpos[7 + j]) - motor[kMotors + j] * speed;
              const double effort = motor[2 * kMotors + j];
              const double torque = std::clamp(requested, -effort, effort);
              data->ctrl[j] = std::abs(speed) >= motor[3 * kMotors + j] && torque * speed > 0. ? 0. : torque;
            }
            mj_step(model, data);
          }
          if (sign < 0) {
            std::memcpy(minus_pos, data->qpos, sizeof(minus_pos));
            std::memcpy(minus_vel, data->qvel, sizeof(minus_vel));
          } else {
            mj_differentiatePos(model, delta, 2 * h, minus_pos, data->qpos);
            for (int row = 0; row < kVelocities; ++row) {
              output[(t * kPhysicalState + row) * kInputs + column] = delta[row];
              output[(t * kPhysicalState + row + kVelocities) * kInputs + column] =
                  (data->qvel[row] - minus_vel[row]) / (2 * h);
            }
          }
        }
      }
    }
    mj_deleteData(data);
  }
}
